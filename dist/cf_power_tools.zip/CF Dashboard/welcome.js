document.addEventListener('DOMContentLoaded', () => {
  // ─── Theme Toggle Logic ───
  const themeToggle = document.getElementById('welcome-theme-toggle');
  
  // Set initial theme based on system preference
  if (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) {
    document.body.classList.remove('dark-theme');
  }

  themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-theme');
  });

  // ─── Dashboard Showcase Tab Switcher ───
  const tabs = ['overview', 'radar', 'shadow', 'recs'];
  
  tabs.forEach(tabName => {
    const btn = document.getElementById(`tab-btn-${tabName}`);
    const content = document.getElementById(`showcase-${tabName}`);
    
    if (btn && content) {
      btn.addEventListener('click', () => {
        // Deactivate all
        tabs.forEach(t => {
          document.getElementById(`tab-btn-${t}`).classList.remove('active');
          document.getElementById(`showcase-${t}`).classList.remove('active');
        });
        
        // Activate current
        btn.classList.add('active');
        content.classList.add('active');
        
        // Trigger specific tab animations
        if (tabName === 'overview') {
          animateGauges();
        }
      });
    }
  });

  // Animate Gauge Progress Rings
  function animateGauges() {
    const gauges = [
      { id: 'solved', value: 78 },
      { id: 'velocity', value: 85 },
      { id: 'accuracy', value: 91 }
    ];

    gauges.forEach(g => {
      const progressCircle = document.getElementById(`gauge-${g.id}-progress`);
      const textVal = document.getElementById(`gauge-${g.id}-text`);
      
      if (progressCircle && textVal) {
        // Reset first
        progressCircle.style.strokeDashoffset = 282.7;
        textVal.textContent = '0%';
        
        // Animate
        setTimeout(() => {
          const radius = 45;
          const circumference = 2 * Math.PI * radius; // ~282.7
          const offset = circumference - (g.value / 100) * circumference;
          progressCircle.style.strokeDashoffset = offset;
          
          // Animate text counter
          let count = 0;
          const duration = 1000; // ms
          const interval = 20; // ms
          const step = g.value / (duration / interval);
          
          const counterId = setInterval(() => {
            count += step;
            if (count >= g.value) {
              textVal.textContent = `${g.value}%`;
              clearInterval(counterId);
            } else {
              textVal.textContent = `${Math.floor(count)}%`;
            }
          }, interval);
        }, 100);
      }
    });
  }

  // Trigger gauges animation on load
  animateGauges();

  // Radar Interactive Hover
  const radarDots = document.querySelectorAll('.radar-data-dot');
  const radarTitle = document.getElementById('radar-stat-title');
  const radarDesc = document.getElementById('radar-stat-desc');

  const radarMetrics = {
    Math: { title: 'Math Skill Index: 85%', desc: 'Excellent. You solve Math tasks 15% faster than your rank tier. Your strengths lie in number theory and prime-factorization tasks.' },
    Greedy: { title: 'Greedy Skill Index: 90%', desc: 'Outstanding. Almost all greedy heuristics in Div. 2 rounds are solved on first submission. Keep up the high efficiency!' },
    Graphs: { title: 'Graphs Skill Index: 60%', desc: 'Moderate. You struggle with tree traversals and dynamic programming on trees. Focus on Div. 2 C/D level problems.' },
    DP: { title: 'DP Skill Index: 67%', desc: 'Strong. You have solid DP state definition skills, but suffer from state reduction and space optimization deficits.' },
    Strings: { title: 'Strings Skill Index: 50%', desc: 'Needs Improvement. You frequently skip string hashing and suffix-array tasks. Try practicing basic string parsing.' }
  };

  radarDots.forEach(dot => {
    dot.addEventListener('mouseenter', (e) => {
      const name = e.target.getAttribute('data-name');
      if (radarMetrics[name]) {
        radarTitle.textContent = radarMetrics[name].title;
        radarDesc.textContent = radarMetrics[name].desc;
      }
    });

    dot.addEventListener('mouseleave', () => {
      radarTitle.textContent = 'Interactive Skill Radar';
      radarDesc.textContent = 'Hover over any data point on the radar web to query your specific strength index in that domain. Calculated by comparing your solve ratings with average competitor benchmarks.';
    });
  });

  // Recommender Solve Buttons
  const solveBtn = document.getElementById('rec-solve-btn');
  const contestBtn = document.getElementById('rec-contest-btn');

  if (solveBtn) {
    solveBtn.addEventListener('click', () => {
      alert('Mock Launch: In the extension, clicking this will take you straight to Codeforces Problem 1901C with Zen Mode ready!');
    });
  }

  if (contestBtn) {
    contestBtn.addEventListener('click', () => {
      alert('Mock Launch: In the extension, this loads a virtual contest environment with pacing indicators customized for tourist\'s pace!');
    });
  }


  // ─── Practice Stopwatch Simulator ───
  let stopwatchTime = 0; // in tenths of a second
  let stopwatchInterval = null;
  let isStopwatchRunning = false;

  const stopwatchDisplay = document.getElementById('sim-stopwatch-display');
  const stopwatchToggleBtn = document.getElementById('stopwatch-btn-toggle');
  const stopwatchFreezeBtn = document.getElementById('stopwatch-btn-freeze');
  const stopwatchResetBtn = document.getElementById('stopwatch-btn-reset');

  function updateStopwatchDisplay() {
    const totalSeconds = Math.floor(stopwatchTime / 10);
    const min = Math.floor(totalSeconds / 60).toString().padStart(2, '0');
    const sec = (totalSeconds % 60).toString().padStart(2, '0');
    const tenths = (stopwatchTime % 10).toString();
    stopwatchDisplay.textContent = `${min}:${sec}.${tenths}`;
  }

  stopwatchToggleBtn.addEventListener('click', () => {
    if (stopwatchDisplay.classList.contains('ac-frozen')) return;

    if (isStopwatchRunning) {
      clearInterval(stopwatchInterval);
      stopwatchToggleBtn.textContent = 'Resume';
      isStopwatchRunning = false;
    } else {
      stopwatchToggleBtn.textContent = 'Pause';
      isStopwatchRunning = true;
      stopwatchInterval = setInterval(() => {
        stopwatchTime++;
        updateStopwatchDisplay();
      }, 100);
    }
  });

  stopwatchFreezeBtn.addEventListener('click', () => {
    if (stopwatchTime === 0) return;
    
    clearInterval(stopwatchInterval);
    isStopwatchRunning = false;
    stopwatchToggleBtn.textContent = 'Start';
    stopwatchDisplay.classList.add('ac-frozen');
    
    const min = Math.floor((stopwatchTime / 10) / 60).toString().padStart(2, '0');
    const sec = Math.floor((stopwatchTime / 10) % 60).toString().padStart(2, '0');
    stopwatchDisplay.innerHTML = `🎉 AC (${min}:${sec})`;
  });

  stopwatchResetBtn.addEventListener('click', () => {
    clearInterval(stopwatchInterval);
    isStopwatchRunning = false;
    stopwatchTime = 0;
    updateStopwatchDisplay();
    stopwatchToggleBtn.textContent = 'Start';
    stopwatchDisplay.classList.remove('ac-frozen');
  });


  // ─── Zen Practice Mode Simulator ───
  const zenToggle = document.getElementById('sim-zen-toggle');
  const zenToggleSlider = document.getElementById('sim-zen-toggle-slider');
  const zenToggleKnob = document.getElementById('sim-zen-toggle-knob');
  
  const zenDiff = document.getElementById('sim-zen-diff');
  const zenTag1 = document.getElementById('sim-zen-tag-1');
  const zenTag2 = document.getElementById('sim-zen-tag-2');

  function updateZenState(isActive) {
    if (isActive) {
      zenDiff.classList.add('masked');
      zenTag1.classList.add('masked');
      zenTag2.classList.add('masked');
      zenToggleSlider.style.backgroundColor = 'var(--accent)';
      zenToggleKnob.style.left = '17px';
    } else {
      zenDiff.classList.remove('masked');
      zenTag1.classList.remove('masked');
      zenTag2.classList.remove('masked');
      zenToggleSlider.style.backgroundColor = '#ccc';
      zenToggleKnob.style.left = '3px';
    }
  }

  zenToggle.addEventListener('change', () => {
    updateZenState(zenToggle.checked);
  });


  // ─── Live Strategy Optimizer Simulator ───
  const strategyFeed = document.getElementById('sim-strategy-feed');
  const strategyTrigger = document.getElementById('sim-strategy-trigger');
  let strategySimStep = 0;

  strategyTrigger.addEventListener('click', () => {
    if (strategySimStep === 0) {
      const entry = document.createElement('div');
      entry.className = 'feed-entry alert';
      entry.textContent = '🚨 Pivot Alert! Problem C solve rate is rising fast (24% solves in 12m). Highly recommend switching to Problem C!';
      strategyFeed.appendChild(entry);
      strategyFeed.scrollTop = strategyFeed.scrollHeight;
      
      strategyTrigger.textContent = 'Resume Solving Pacing';
      strategySimStep = 1;
    } else {
      const entry = document.createElement('div');
      entry.className = 'feed-entry system';
      entry.textContent = '[00:18] Switched to Problem C. Pacing normalized.';
      strategyFeed.appendChild(entry);
      strategyFeed.scrollTop = strategyFeed.scrollHeight;
      
      strategyTrigger.textContent = 'Simulate Stuck on Problem C';
      strategyTrigger.disabled = true;
      strategyTrigger.style.opacity = '0.5';
    }
  });


  // ─── Friends\' Solutions Simulator ───
  const codeOverlay = document.getElementById('friend-code-overlay');
  const overlayFriendName = document.getElementById('overlay-friend-name');
  const overlayCodeBlock = document.getElementById('overlay-code-block');
  
  const viewTouristBtn = document.getElementById('friend-view-tourist');
  const viewBenqBtn = document.getElementById('friend-view-benq');
  
  const closeCodeOverlayBtn = document.getElementById('overlay-btn-close');
  const copyCodeOverlayBtn = document.getElementById('overlay-btn-copy');

  const friendCodes = {
    tourist: `#include <iostream>
using namespace std;

void solve() {
    int n, x;
    cin >> n >> x;
    vector<int> a(n);
    for(int &v : a) cin >> v;
    
    // Check initial gap, intermediate gaps, and final return
    int ans = max(a[0], 2 * (x - a.back()));
    for(int i = 1; i < n; i++) {
        ans = max(ans, a[i] - a[i-1]);
    }
    cout << ans << "\\n";
}

int main() {
    int t; cin >> t;
    while(t--) solve();
    return 0;
}`,
    Benq: `#include <bits/stdc++.h>
using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    int t; cin >> t;
    while (t--) {
        int n, x; cin >> n >> x;
        vector<int> a(n);
        for (int i = 0; i < n; ++i) cin >> a[i];
        
        int diff = a[0];
        for (int i = 1; i < n; ++i) {
            diff = max(diff, a[i] - a[i - 1]);
        }
        diff = max(diff, 2 * (x - a[n - 1]));
        cout << diff << "\\n";
    }
}`
  };

  function openCodeDrawer(friendName) {
    overlayFriendName.textContent = friendName;
    overlayCodeBlock.textContent = friendCodes[friendName];
    codeOverlay.classList.add('active');
  }

  viewTouristBtn.addEventListener('click', () => openCodeDrawer('tourist'));
  viewBenqBtn.addEventListener('click', () => openCodeDrawer('Benq'));
  
  closeCodeOverlayBtn.addEventListener('click', () => {
    codeOverlay.classList.remove('active');
  });

  copyCodeOverlayBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(overlayCodeBlock.textContent).then(() => {
      copyCodeOverlayBtn.textContent = 'Copied!';
      setTimeout(() => {
        copyCodeOverlayBtn.textContent = 'Copy';
      }, 1500);
    });
  });


  // ─── Socratic AI Coach Simulator ───
  const coachOutput = document.getElementById('sim-coach-output');
  const coachBtn = document.getElementById('sim-coach-btn');
  let coachStep = 0;

  const coachHints = [
    `<strong>Coach:</strong> 💡 <strong>Hint 1:</strong> Think about the spacing between gas stations. Let <span class="math-expr">d<sub>i</sub> = a<sub>i</sub> - a<sub>i-1</sub></span>. What is the minimum tank size needed just to travel between consecutive stations on the one-way route?`,
    `<strong>Coach:</strong> 💡 <strong>Hint 2:</strong> Good! Now, what happens at the destination? The car must drive from the last station <span class="math-expr">a<sub>n</sub></span> to destination <span class="math-expr">x</span>, and then back. The distance traveled between visits to <span class="math-expr">a<sub>n</sub></span> is <span class="math-expr">2 · (x - a<sub>n</sub>)</span>.`,
    `<strong>Coach:</strong> 💡 <strong>Hint 3:</strong> Excellent. So, the minimum capacity is simply the maximum of all these segment distances: <span class="math-expr">max(a<sub>1</sub>, d<sub>2</sub>, ..., d<sub>n</sub>, 2 · (x - a<sub>n</sub>))</span>.`
  ];

  coachBtn.addEventListener('click', () => {
    if (coachStep < coachHints.length) {
      coachOutput.innerHTML = coachHints[coachStep];
      coachStep++;
      if (coachStep === coachHints.length) {
        coachBtn.textContent = 'All Hints Unlocked';
        coachBtn.disabled = true;
        coachBtn.style.opacity = '0.5';
      }
    }
  });


  // ─── AI Edge Case Generator Simulator ───
  const casesOutput = document.getElementById('sim-cases-output');
  const casesGenerateBtn = document.getElementById('sim-cases-generate');
  const casesCopyBtn = document.getElementById('sim-cases-copy');

  const mockCases = `[Edge Case 1: Minimum Boundaries]
Input:
1
1 10
5
Output:
10

[Edge Case 2: Coincident Gas Stations (Clustered)]
Input:
1
3 100
97 98 99
Output:
97

[Edge Case 3: N = 5, Destination is next to last station]
Input:
1
5 5
1 2 3 4 4
Output:
2`;

  casesGenerateBtn.addEventListener('click', () => {
    casesOutput.textContent = mockCases;
    casesOutput.scrollTop = 0;
  });

  casesCopyBtn.addEventListener('click', () => {
    const textToCopy = casesOutput.textContent;
    if (textToCopy === 'Select problem context and hit generate to check.') return;
    
    navigator.clipboard.writeText(textToCopy).then(() => {
      casesCopyBtn.textContent = 'Copied!';
      setTimeout(() => {
        casesCopyBtn.textContent = 'Copy Cases';
      }, 1500);
    });
  });
});

document.addEventListener('DOMContentLoaded', () => {
  const toggles = {
    stopwatch: document.getElementById('stopwatch-toggle'),
    strategy: document.getElementById('strategy-toggle'),
    friends: document.getElementById('friends-toggle'),
    zen: document.getElementById('zen-toggle'),
    ai: document.getElementById('ai-toggle')
  };

  const aiSettingsContainer = document.getElementById('ai-settings-container');
  const openaiInput = document.getElementById('openai-key');
  const googleInput = document.getElementById('google-key');
  const testOpenaiBtn = document.getElementById('test-openai-btn');
  const testGoogleBtn = document.getElementById('test-google-btn');
  const openaiStatus = document.getElementById('openai-status');
  const googleStatus = document.getElementById('google-status');

  const dashboardBtn = document.getElementById('dashboard-btn');
  const themeToggleBtn = document.getElementById('theme-toggle-btn');

  // Load saved settings from chrome.storage.local
  chrome.storage.local.get({
    stopwatchEnabled: true,
    strategyEnabled: true,
    friendsEnabled: true,
    zenEnabled: true,
    aiEnabled: false,
    openaiKey: '',
    googleKey: '',
    themeLight: true
  }, (items) => {
    toggles.stopwatch.checked = items.stopwatchEnabled;
    toggles.strategy.checked = items.strategyEnabled;
    toggles.friends.checked = items.friendsEnabled;
    toggles.zen.checked = items.zenEnabled;
    toggles.ai.checked = items.aiEnabled;

    openaiInput.value = items.openaiKey || '';
    googleInput.value = items.googleKey || '';

    if (items.aiEnabled) {
      aiSettingsContainer.style.display = 'block';
    } else {
      aiSettingsContainer.style.display = 'none';
    }

    if (items.themeLight) {
      document.body.classList.add('light-theme');
    } else {
      document.body.classList.remove('light-theme');
    }
  });

  function broadcastSettings() {
    const stopwatchEnabled = toggles.stopwatch.checked;
    const strategyEnabled = toggles.strategy.checked;
    const friendsEnabled = toggles.friends.checked;
    const zenEnabled = toggles.zen.checked;
    const aiEnabled = toggles.ai.checked;
    const openaiKey = openaiInput.value || '';
    const googleKey = googleInput.value || '';

    chrome.storage.local.set({
      stopwatchEnabled,
      strategyEnabled,
      friendsEnabled,
      zenEnabled,
      aiEnabled,
      openaiKey,
      googleKey
    }, () => {
      // Broadcast the updated settings state to all active Codeforces tabs
      chrome.runtime.sendMessage({
        type: 'CF_SYNC_STATE',
        payload: {
          action: 'SETTINGS_SYNC',
          settings: { 
            stopwatchEnabled, 
            strategyEnabled, 
            friendsEnabled, 
            zenEnabled, 
            aiEnabled,
            openaiKey,
            googleKey
          }
        }
      }).catch(() => {});
    });
  }

  // Bind change listeners to save settings and broadcast updates
  Object.keys(toggles).forEach(key => {
    toggles[key].addEventListener('change', () => {
      if (toggles.ai.checked) {
        aiSettingsContainer.style.display = 'block';
      } else {
        aiSettingsContainer.style.display = 'none';
        openaiStatus.innerHTML = '';
        googleStatus.innerHTML = '';
      }
      broadcastSettings();
    });
  });

  // Handle saving credentials
  openaiInput.addEventListener('input', () => {
    openaiStatus.innerHTML = '';
    broadcastSettings();
  });

  googleInput.addEventListener('input', () => {
    googleStatus.innerHTML = '';
    broadcastSettings();
  });

  // Test OpenAI connection
  testOpenaiBtn.addEventListener('click', () => {
    const key = openaiInput.value.trim();
    if (!key) {
      openaiStatus.className = 'test-status status-error';
      openaiStatus.textContent = '❌ Key cannot be empty';
      return;
    }

    openaiStatus.className = 'test-status status-loading';
    openaiStatus.textContent = '⏳ Testing connection...';
    testOpenaiBtn.disabled = true;

    chrome.runtime.sendMessage({ type: 'CF_TEST_OPENAI', key }, (response) => {
      testOpenaiBtn.disabled = false;
      if (response && response.ok) {
        openaiStatus.className = 'test-status status-success';
        openaiStatus.textContent = '✔ Connection successful!';
      } else {
        openaiStatus.className = 'test-status status-error';
        openaiStatus.textContent = `❌ Failed: ${response?.error || 'Unknown error'}`;
      }
    });
  });

  // Test Google connection
  testGoogleBtn.addEventListener('click', () => {
    const key = googleInput.value.trim();
    if (!key) {
      googleStatus.className = 'test-status status-error';
      googleStatus.textContent = '❌ Key cannot be empty';
      return;
    }

    googleStatus.className = 'test-status status-loading';
    googleStatus.textContent = '⏳ Testing connection...';
    testGoogleBtn.disabled = true;

    chrome.runtime.sendMessage({ type: 'CF_TEST_GOOGLE', key }, (response) => {
      testGoogleBtn.disabled = false;
      if (response && response.ok) {
        googleStatus.className = 'test-status status-success';
        googleStatus.textContent = '✔ Connection successful!';
      } else {
        googleStatus.className = 'test-status status-error';
        googleStatus.textContent = `❌ Failed: ${response?.error || 'Unknown error'}`;
      }
    });
  });

  // Theme Toggle click handler
  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      const isLight = document.body.classList.toggle('light-theme');
      chrome.storage.local.set({ themeLight: isLight });
    });
  }

  dashboardBtn.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://codeforces.com/profile#dashboard' });
  });
});

/**
 * CF Dashboard – Content Script (Next-Gen CP Intelligence Edition)
 * =================================================================
 * Injects a powerful analytics dashboard into any Codeforces profile page
 * and bootstrap a real-time live strategy optimizer on active contests.
 * Processes timing pacing, rival gap grids, and mock coaching off-thread
 * using a compiled Blob Web Worker to keep main browser thread lag-free.
 */

(function () {
  'use strict';

  // Safety wrapper to prevent 'Extension context invalidated' errors when extension reloads
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
    const originalSendMessage = chrome.runtime.sendMessage;
    chrome.runtime.sendMessage = function (message, callback) {
      if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.id) {
        if (callback) callback({ ok: false, error: 'Extension context invalidated. Please refresh the page.' });
        return;
      }
      try {
        originalSendMessage.call(chrome.runtime, message, (response) => {
          if (chrome.runtime.lastError) {
            if (callback) callback({ ok: false, error: chrome.runtime.lastError.message });
            return;
          }
          if (callback) callback(response);
        });
      } catch (e) {
        if (callback) callback({ ok: false, error: 'Extension context invalidated. Please refresh the page.' });
      }
    };
  }

  // ─── Selectors ─────────────────────────────────────────────────────────────
  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

  let currentSettings = {
    stopwatchEnabled: true,
    strategyEnabled: true,
    friendsEnabled: true,
    zenEnabled: true
  };
  let currentContestId = null;
  let currentProblemIndex = null;
  let currentSubmissions = null;
  let currentProblemset = null;

  let stopwatchIntervalId = null;
  let liveStrategyIntervalId = null;
  let stopwatchState = null;
  let stopwatchStateKey = null;

  // ─── Extract handle from URL ──────────────────────────────────────────────
  function getHandle() {
    const m = window.location.pathname.match(/^\/profile\/([^/?#]+)/);
    return m ? m[1] : null;
  }

  // ─── Dark mode detection (computed bg lightness + explicit classes) ───────
  function isDark() {
    const b = document.body;
    const h = document.documentElement;
    if (!b) return false;

    // Explicit dark theme classes/attributes commonly used by extensions
    if (b.classList.contains('dark') || 
        b.classList.contains('cf-dark') || 
        b.classList.contains('night-mode') ||
        h.getAttribute('data-theme') === 'dark' ||
        h.getAttribute('data-color-scheme') === 'dark') {
      return true;
    }

    // Check computed background color of body (average brightness < 100)
    try {
      const bg = window.getComputedStyle(b).backgroundColor;
      if (bg) {
        const rgb = bg.match(/\d+/g);
        if (rgb && rgb.length >= 3) {
          const r = parseInt(rgb[0], 10);
          const g = parseInt(rgb[1], 10);
          const bVal = parseInt(rgb[2], 10);
          if ((r + g + bVal) / 3 < 100) {
            return true;
          }
        }
      }
    } catch (e) {}

    return false;
  }

  function applyTheme() {
    if (themeObserver) {
      themeObserver.disconnect();
    }
    
    try {
      const dark = isDark();
      const hasClass = document.body.classList.contains('cfd-dark');
      if (dark && !hasClass) {
        document.body.classList.add('cfd-dark');
      } else if (!dark && hasClass) {
        document.body.classList.remove('cfd-dark');
      }
    } catch (e) {
      console.warn('[CF Dashboard] applyTheme error:', e);
    } finally {
      if (themeObserver) {
        themeObserver.observe(document.documentElement, {
          attributes: true,
          attributeFilter: ['data-theme', 'data-color-scheme', 'style']
        });

        themeObserver.observe(document.body || document.documentElement, {
          attributes: true,
          attributeFilter: ['class', 'style']
        });

        themeObserver.observe(document.head || document.documentElement, {
          childList: true,
          subtree: true
        });
      }
    }
  }

  // ─── Rating helpers (exact CF rating colours) ─────────────────────────────
  function ratingColor(r) {
    if (!r || r < 1200) return '#808080';
    if (r < 1400) return '#008000';
    if (r < 1600) return '#03a89e';
    if (r < 1900) return '#0000ff';
    if (r < 2100) return '#aa00aa';
    if (r < 2400) return '#ff8c00';
    if (r < 3000) return '#ff3333';
    return '#aa0000';
  }

  function ratingLabel(r) {
    if (!r || r < 1200) return 'Newbie';
    if (r < 1400) return 'Pupil';
    if (r < 1600) return 'Specialist';
    if (r < 1900) return 'Expert';
    if (r < 2100) return 'Candidate Master';
    if (r < 2400) return 'Master';
    if (r < 2600) return 'International Master';
    if (r < 3000) return 'Grandmaster';
    return 'Legendary Grandmaster';
  }

  // ─── Extract official stats from Codeforces Profile DOM ─────────────────────
  function parseProfileSolvedCount() {
    let count = null;
    try {
      const listItems = document.querySelectorAll('.info li');
      for (const li of listItems) {
        if (li.textContent.includes('Solved:')) {
          const a = li.querySelector('a');
          if (a) {
            const match = a.textContent.match(/(\d+)/);
            if (match) {
              const val = parseInt(match[1], 10);
              if (!isNaN(val) && val > 0) {
                count = val;
                break;
              }
            }
          }
        }
      }
    } catch (e) {
      console.warn('[CF Dashboard] Failed parsing solved count from .info li:', e);
    }

    if (!count) {
      try {
        const footers = document.querySelectorAll('._UserActivityFrame_footer');
        for (const footer of footers) {
          const valEl = footer.querySelector('._UserActivityFrame_counterValue');
          const lblEl = footer.querySelector('._UserActivityFrame_counterLabel');
          if (valEl && lblEl) {
            const lblText = lblEl.textContent.trim().toLowerCase();
            if (lblText === 'solved' || lblText === 'solved problems') {
              const match = valEl.textContent.match(/(\d+)/);
              if (match) {
                const val = parseInt(match[1], 10);
                if (!isNaN(val) && val > 0) {
                  count = val;
                  break;
                }
              }
            }
          }
        }
      } catch (e) {
        console.warn('[CF Dashboard] Failed parsing solved count from UserActivityFrame:', e);
      }
    }
    return count;
  }

  function parseProfileStreaks() {
    let maxStreak = null;
    let currentStreak = null;
    try {
      const footers = document.querySelectorAll('._UserActivityFrame_footer');
      for (const footer of footers) {
        const valEl = footer.querySelector('._UserActivityFrame_counterValue');
        const lblEl = footer.querySelector('._UserActivityFrame_counterLabel');
        if (valEl && lblEl) {
          const lblText = lblEl.textContent.trim().toLowerCase();
          const valText = valEl.textContent.trim();
          const match = valText.match(/(\d+)/);
          if (match) {
            const val = parseInt(match[1], 10);
            if (!isNaN(val)) {
              if (lblText.includes('in a row max') || lblText.includes('max streak') || lblText.includes('row max')) {
                maxStreak = val;
              } else if (lblText.includes('in a row current') || lblText.includes('current streak') || lblText.includes('row current')) {
                currentStreak = val;
              }
            }
          }
        }
      }
    } catch (e) {
      console.warn('[CF Dashboard] Failed parsing streaks from UserActivityFrame:', e);
    }
    return { maxStreak, currentStreak };
  }

  // ─── Tooltip ───────────────────────────────────────────────────────────────
  let _tip = null;

  function initTooltip() {
    if (_tip) return;
    _tip = document.createElement('div');
    _tip.className = 'cfd-tooltip';
    _tip.id = 'cfd-tip';
    document.body.appendChild(_tip);
  }

  function showTip(e, html) {
    if (!_tip) return;
    _tip.innerHTML = html;
    _tip.classList.add('cfd-tt-visible');
    moveTip(e);
  }

  function moveTip(e) {
    if (!_tip) return;
    const x = Math.min(e.clientX + 14, window.innerWidth - _tip.offsetWidth - 8);
    const y = Math.max(e.clientY - 42, 4);
    _tip.style.left = x + 'px';
    _tip.style.top  = y + 'px';
  }

  function hideTip() {
    _tip && _tip.classList.remove('cfd-tt-visible');
  }

  // ─── SVG helper ────────────────────────────────────────────────────────────
  function svgNS(tag, attrs = {}) {
    const el = document.createElementNS('http://www.w3.org/2000/svg', tag);
    for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
    return el;
  }

  // ─── Section card builder ──────────────────────────────────────────────────
  function makeCard(titleHtml, bodyHtml, extraClass = '') {
    return `
      <div class="cfd-card ${extraClass}">
        <div class="cfd-section-header">${titleHtml}</div>
        <div class="cfd-card-body">${bodyHtml}</div>
      </div>`;
  }

  // ─── Helper for Activity Heatmap date formatting ───────────────────────────
  function fmtDate(d) {
    const yyyy = d.getFullYear();
    const mm   = String(d.getMonth() + 1).padStart(2, '0');
    const dd   = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }

  const today = new Date(); // define today at global module-level for ease of access

  // ═══════════════════════════════════════════════════════════════════════════
  //  DATA PROCESSING (LIGHT MERGE PIPELINE)
  // ═══════════════════════════════════════════════════════════════════════════
  function processData(submissions, userInfo, ratingHistory, rivalSubmissions = null) {
    const rHistory = ratingHistory || [];
    const probMap = new Map();
    let uniqueSolved = 0;

    for (const sub of submissions) {
      if (!sub.problem) continue;
      const key = `${sub.problem.contestId}_${sub.problem.index}`;
      if (!probMap.has(key)) {
        probMap.set(key, { problem: sub.problem, submissions: [], solved: false, solvedSub: null });
      }
      const entry = probMap.get(key);
      entry.submissions.push(sub);
      if (sub.verdict === 'OK' && !entry.solved) {
        entry.solved = true;
        entry.solvedSub = sub;
        uniqueSolved++;
      }
    }

    // ── 1. Efficiency buckets ──
    const buckets = [
      { label: '≤1099',    min: 0,    max: 1099 },
      { label: '1100-1299',min: 1100, max: 1299 },
      { label: '1300-1499',min: 1300, max: 1499 },
      { label: '1500-1799',min: 1500, max: 1799 },
      { label: '1800-1999',min: 1800, max: 1999 },
      { label: '2000-2199',min: 2000, max: 2199 },
      { label: '2200-2499',min: 2200, max: 2499 },
      { label: '2500-2999',min: 2500, max: 2999 },
      { label: '3000+',   min: 3000, max: 9999 }
    ];

    const effData = buckets.map(b => ({
      label: b.label, solved: 0, attempted: 0, totalSubs: 0, efficiency: 0,
      _solvedSet: new Set(), _attSet: new Set()
    }));

    for (const [key, entry] of probMap) {
      const r    = entry.problem.rating || 0;
      const bIdx = buckets.findIndex(b => r >= b.min && r <= b.max);
      if (bIdx < 0) continue;
      const bd = effData[bIdx];
      bd._attSet.add(key);
      if (entry.solved) bd._solvedSet.add(key);
      bd.totalSubs += entry.submissions.length;
    }

    effData.forEach(d => {
      d.solved    = d._solvedSet.size;
      d.attempted = d._attSet.size;
      d.efficiency = d.totalSubs > 0 ? Math.round((d.solved / d.totalSubs) * 100) : 0;
    });

    // ── Optional: Process Rival solved overlay counts ──
    let rivalEffData = null;
    if (rivalSubmissions && rivalSubmissions.length > 0) {
      const rivalProbMap = new Map();
      for (const sub of rivalSubmissions) {
        if (!sub.problem) continue;
        const key = `${sub.problem.contestId}_${sub.problem.index}`;
        if (!rivalProbMap.has(key)) {
          rivalProbMap.set(key, { problem: sub.problem, submissions: [], solved: false });
        }
        const entry = rivalProbMap.get(key);
        entry.submissions.push(sub);
        if (sub.verdict === 'OK') {
          entry.solved = true;
        }
      }

      rivalEffData = buckets.map(b => ({
        label: b.label, solved: 0, _solvedSet: new Set()
      }));

      for (const [key, entry] of rivalProbMap) {
        const r    = entry.problem.rating || 0;
        const bIdx = buckets.findIndex(b => r >= b.min && r <= b.max);
        if (bIdx < 0) continue;
        const bd = rivalEffData[bIdx];
        if (entry.solved) bd._solvedSet.add(key);
      }

      rivalEffData.forEach(d => {
        d.solved = d._solvedSet.size;
      });
    }

    // ── 2. Tag Power ──
    const tagAcc = {};
    for (const [, entry] of probMap) {
      if (!entry.solved) continue;
      const r = entry.problem.rating || 0;
      for (const tag of (entry.problem.tags || [])) {
        if (!tagAcc[tag]) tagAcc[tag] = { total: 0, count: 0 };
        tagAcc[tag].total += r;
        tagAcc[tag].count++;
      }
    }

    const RADAR_TAGS = [
      { key: 'dp',                      label: 'DP' },
      { key: 'greedy',                  label: 'Greedy' },
      { key: 'math',                    label: 'Math' },
      { key: 'graphs',                  label: 'Graphs' },
      { key: 'strings',                 label: 'Strings' },
      { key: 'bitmasks',                label: 'Bitmasks' },
      { key: 'implementation',          label: 'Impl.' },
      { key: 'data structures',         label: 'Data Structs' },
      { key: 'constructive algorithms', label: 'Constructive' },
      { key: 'number theory',           label: 'Num Theory' }
    ];

    const tagPower = RADAR_TAGS.map(t => ({
      tag:   t.key,
      label: t.label,
      avg:   tagAcc[t.key] ? Math.round(tagAcc[t.key].total / tagAcc[t.key].count) : 0,
      count: tagAcc[t.key] ? tagAcc[t.key].count : 0
    }));

    // ── 3. Upsolving categories ──
    const upsolve = { closeCalls: [], edgeCases: [], crashes: [] };
    for (const [, entry] of probMap) {
      if (entry.solved) continue;
      const bestSub = entry.submissions.reduce((best, s) => {
        if (!best) return s;
        if ((s.passedTestCount || 0) > (best.passedTestCount || 0)) return s;
        return best;
      }, null);

      if (!bestSub) continue;

      const item = {
        problem:     entry.problem,
        verdict:     bestSub.verdict,
        passedTests: bestSub.passedTestCount || 0,
        url: `https://codeforces.com/problemset/problem/${entry.problem.contestId}/${entry.problem.index}`
      };

      const v = bestSub.verdict;
      if (v === 'RUNTIME_ERROR' || v === 'COMPILATION_ERROR') {
        upsolve.crashes.push(item);
      } else if ((v === 'WRONG_ANSWER' || v === 'TIME_LIMIT_EXCEEDED') && item.passedTests <= 1) {
        upsolve.edgeCases.push(item);
      } else if (v === 'WRONG_ANSWER' || v === 'TIME_LIMIT_EXCEEDED' || v === 'MEMORY_LIMIT_EXCEEDED') {
        upsolve.closeCalls.push(item);
      }
    }

    const byRating = (a, b) => (a.problem.rating || 0) - (b.problem.rating || 0);
    upsolve.closeCalls.sort(byRating);
    upsolve.edgeCases.sort(byRating);
    upsolve.crashes.sort(byRating);

    // ── 4. Heatmap ──
    const heatDays = {};
    const MS_DAY   = 86_400_000;
    const cutoff   = Date.now() - 366 * MS_DAY;

    submissions.forEach(s => {
      const ms = s.creationTimeSeconds * 1000;
      if (ms < cutoff) return;
      const key = fmtDate(new Date(ms));
      heatDays[key] = (heatDays[key] || 0) + 1;
    });

    // Calc streaks
    let maxStreak = 0, currentStreak = 0;
    const todayLocal = new Date();
    let iter = new Date(todayLocal);
    iter.setHours(0,0,0,0);
    const dayLimit = new Date(cutoff);
    dayLimit.setHours(0,0,0,0);

    let streakActive = true;
    while (iter >= dayLimit) {
      const k = fmtDate(iter);
      if (heatDays[k]) {
        currentStreak++;
        if (currentStreak > maxStreak) maxStreak = currentStreak;
      } else {
        if (iter.getTime() === todayLocal.setHours(0,0,0,0) && !heatDays[fmtDate(todayLocal)]) {
          // preserve streak tail
        } else {
          if (streakActive) {
            streakActive = false;
            var liveStreak = currentStreak;
          }
          currentStreak = 0;
        }
      }
      iter.setDate(iter.getDate() - 1);
    }

    const todayStr = fmtDate(todayLocal);
    const yest = new Date(todayLocal);
    yest.setDate(yest.getDate() - 1);
    const yestStr = fmtDate(yest);

    const hasTodayOrYest = heatDays[todayStr] || heatDays[yestStr];
    const liveStreakFinal = hasTodayOrYest ? (liveStreak ?? currentStreak) : 0;

    const heatmapStats = {
      maxStreak,
      currentStreak: liveStreakFinal
    };

    // ── 5. Virtual vs Live Rating timeline calculations ──
    const virtualPoints = [];
    const contestSet = new Set(rHistory.map(r => r.contestId));
    submissions.forEach(s => {
      if (s.author && s.author.participantType === 'VIRTUAL' && s.contestId && !contestSet.has(s.contestId)) {
        if (s.verdict === 'OK') {
          const timestamp = s.creationTimeSeconds * 1000;
          if (!virtualPoints.some(v => v.contestId === s.contestId)) {
            virtualPoints.push({
              contestId: s.contestId,
              timestamp,
              estimatedRating: s.problem.rating ? Math.max(s.problem.rating - 100, 800) : 1200
            });
          }
        }
      }
    });
    virtualPoints.sort((a,b) => a.timestamp - b.timestamp);

    return {
      submissions,
      effData,
      tagPower,
      upsolve,
      heatDays,
      heatmapStats,
      ratingHistory: rHistory,
      userInfo,
      uniqueSolved,
      totalProblems: probMap.size,
      totalSubmissions: submissions.length,
      virtualPoints,
      rivalEffData
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  OFF-THREAD WEB WORKER ANALYTICS MATH
  // ═══════════════════════════════════════════════════════════════════════════
  const ANALYTICS_WORKER_CODE = `
    self.onmessage = function(e) {
      const { type, payload } = e.data;
      if (type === 'CRUNCH') {
        try {
          const result = crunchAnalytics(payload);
          self.postMessage({ type: 'SUCCESS', result });
        } catch (err) {
          self.postMessage({ type: 'ERROR', error: err.message });
        }
      }
    };

    function crunchAnalytics(payload) {
      const { submissions, ratingHistory, contestMap, rivalSubmissions, userRating } = payload;
      
      // 1. Time & Velocity Pacing Analytics
      const contestSubs = submissions.filter(s => s.author && s.author.participantType === 'CONTESTANT' && s.contestId);
      
      const subsByContest = {};
      contestSubs.forEach(s => {
        if (!subsByContest[s.contestId]) subsByContest[s.contestId] = [];
        subsByContest[s.contestId].push(s);
      });

      const scatterPoints = [];
      let totalAgonyTime = 0;
      let agonyCount = 0;
      let maxAgony = { minutes: 0, problem: '', contestName: '' };
      
      Object.keys(subsByContest).forEach(cId => {
        const cStartTime = contestMap[cId];
        if (!cStartTime) return;
        
        const contestName = subsByContest[cId][0].author.contestName || \`Contest #\${cId}\`;
        const problemGroups = {};
        
        subsByContest[cId].forEach(s => {
          const pIdx = s.problem.index;
          if (!problemGroups[pIdx]) problemGroups[pIdx] = [];
          problemGroups[pIdx].push(s);
        });
        
        Object.keys(problemGroups).forEach(pIdx => {
          const group = problemGroups[pIdx].sort((a, b) => a.creationTimeSeconds - b.creationTimeSeconds);
          const firstSub = group[0];
          const acSub = group.find(s => s.verdict === 'OK');
          const normIdx = pIdx.charAt(0);
          
          group.forEach(s => {
            const elapsedMins = Math.round((s.creationTimeSeconds - cStartTime) / 60);
            if (elapsedMins >= 0 && elapsedMins <= 300) {
              scatterPoints.push({
                problem: normIdx,
                minutes: elapsedMins,
                isAC: s.verdict === 'OK',
                contestName: contestName,
                problemName: s.problem.name
              });
            }
          });
          
          if (acSub && firstSub.verdict !== 'OK') {
            const agonyMins = Math.round((acSub.creationTimeSeconds - firstSub.creationTimeSeconds) / 60);
            if (agonyMins > 0) {
              totalAgonyTime += agonyMins;
              agonyCount++;
              if (agonyMins > maxAgony.minutes) {
                maxAgony = { minutes: agonyMins, problem: pIdx, contestName: contestName };
              }
            }
          }
        });
      });

      const avgAgony = agonyCount > 0 ? Math.round(totalAgonyTime / agonyCount) : 0;

      // 2. Contest Strategy Retrospective (The Mock Coach)
      const coachCards = [];
      const recentContests = Object.keys(subsByContest).sort((a, b) => b - a).slice(0, 5);
      
      recentContests.forEach(cId => {
        const cStartTime = contestMap[cId];
        if (!cStartTime) return;
        
        const contestName = subsByContest[cId][0].author.contestName || \`Contest #\${cId}\`;
        const list = subsByContest[cId];
        const problemsMap = {};
        list.forEach(s => {
          const pIdx = s.problem.index;
          if (!problemsMap[pIdx]) problemsMap[pIdx] = [];
          problemsMap[pIdx].push(s);
        });
        
        let isOverSubmitter = false;
        let rabbitHoleProblem = null;
        let rabbitHoleMins = 0;
        let weakFinishProblems = [];
        
        Object.keys(problemsMap).forEach(pIdx => {
          const pSubs = problemsMap[pIdx].sort((a, b) => a.creationTimeSeconds - b.creationTimeSeconds);
          
          if (pSubs.length >= 5) {
            isOverSubmitter = true;
          }
          
          if (pSubs.length >= 2) {
            const start = pSubs[0].creationTimeSeconds;
            const end = pSubs[pSubs.length - 1].creationTimeSeconds;
            const deltaMins = Math.round((end - start) / 60);
            if (deltaMins > 60 && deltaMins > rabbitHoleMins) {
              rabbitHoleMins = deltaMins;
              rabbitHoleProblem = pIdx;
            }
          }
        });
        
        Object.keys(problemsMap).forEach(pIdx => {
          const pSubs = problemsMap[pIdx];
          const isSolvedLive = pSubs.some(s => s.verdict === 'OK');
          if (!isSolvedLive) {
            const isUpsolvedLater = submissions.some(s => s.problem.contestId == cId && s.problem.index === pIdx && s.verdict === 'OK');
            if (!isUpsolvedLater) {
              const prob = pSubs[0].problem;
              if (prob.rating) {
                weakFinishProblems.push(prob);
              }
            }
          }
        });

        if (isOverSubmitter || rabbitHoleProblem || weakFinishProblems.length > 0) {
          coachCards.push({
            contestId: cId,
            contestName: contestName,
            overSubmitter: isOverSubmitter,
            rabbitHole: rabbitHoleProblem ? { problem: rabbitHoleProblem, minutes: rabbitHoleMins } : null,
            weakFinish: weakFinishProblems.slice(0, 2).map(p => ({ index: p.index, rating: p.rating, name: p.name }))
          });
        }
      });

      // 3. Language & System Diagnostic (resource TLE threshold warnings)
      let tleCount = 0;
      let nearLimitCount = 0;
      const dangerousRuns = [];
      
      submissions.slice(0, 500).forEach(s => {
        if (!s.problem || !s.problem.timeLimit) return;
        
        if (s.verdict === 'TIME_LIMIT_EXCEEDED') {
          tleCount++;
        } else if (s.verdict === 'OK') {
          const tLimit = s.problem.timeLimit;
          const ratio = s.timeConsumedMillis / tLimit;
          if (ratio > 0.8) {
            nearLimitCount++;
            dangerousRuns.push({
              problem: \`\${s.problem.contestId}\${s.problem.index}\`,
              name: s.problem.name,
              lang: s.programmingLanguage,
              ratio: Math.round(ratio * 100),
              time: s.timeConsumedMillis,
              limit: tLimit
            });
          }
        }
      });

      const isHighOverhead = (tleCount + nearLimitCount) > 5;
      const mostUsedLang = submissions.length > 0 ? submissions[0].programmingLanguage : 'C++';

      // 4. Practice Deficit Gap Analysis (Shadow Mode comparison)
      const gapAnalysis = [];
      if (rivalSubmissions && rivalSubmissions.length > 0) {
        const userSolved = {};
        const rivalSolved = {};
        
        submissions.forEach(s => {
          if (s.verdict === 'OK' && s.problem && s.problem.tags) {
            const r = s.problem.rating || 1200;
            const bucket = Math.floor(r / 200) * 200;
            s.problem.tags.forEach(tag => {
              const key = \`\${tag}_\\text{\${bucket}}\`;
              userSolved[key] = (userSolved[key] || 0) + 1;
            });
          }
        });
        
        rivalSubmissions.forEach(s => {
          if (s.verdict === 'OK' && s.problem && s.problem.tags) {
            const r = s.problem.rating || 1200;
            const bucket = Math.floor(r / 200) * 200;
            s.problem.tags.forEach(tag => {
              const key = \`\${tag}_\\text{\${bucket}}\`;
              rivalSolved[key] = (rivalSolved[key] || 0) + 1;
            });
          }
        });

        Object.keys(rivalSolved).forEach(key => {
          const rivalVal = rivalSolved[key];
          const userVal = userSolved[key] || 0;
          const deficit = rivalVal - userVal;
          
          if (deficit > 2) {
            const parts = key.split('_');
            const tag = parts[0];
            const levelStr = parts[1].replace(/\\\\text\{|\\text\{|\}/g, '');
            gapAnalysis.push({
              tag,
              level: parseInt(levelStr) || 1200,
              userSolved: userVal,
              rivalSolved: rivalVal,
              deficit: deficit
            });
          }
        });
        
        gapAnalysis.sort((a, b) => b.deficit - a.deficit);
      }

      return {
        scatterPoints,
        avgAgony,
        maxAgony,
        coachCards: coachCards.slice(0, 3),
        diagnostics: {
          tleCount,
          nearLimitCount,
          isHighOverhead,
          mostUsedLang,
          dangerousRuns: dangerousRuns.slice(0, 3)
        },
        gapAnalysis: gapAnalysis.slice(0, 5)
      };
    }
  `;

  function crunchAnalyticsAsync(payload) {
    return new Promise((resolve, reject) => {
      try {
        const blob = new Blob([ANALYTICS_WORKER_CODE], { type: 'application/javascript' });
        const worker = new Worker(URL.createObjectURL(blob));
        
        worker.onmessage = function(e) {
          const { type, result, error } = e.data;
          worker.terminate();
          if (type === 'SUCCESS') {
            resolve(result);
          } else {
            reject(new Error(error || 'Worker execution failed'));
          }
        };
        
        worker.onerror = function(err) {
          worker.terminate();
          reject(err);
        };
        
        worker.postMessage({ type: 'CRUNCH', payload });
      } catch (err) {
        reject(err);
      }
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  UI COMPONENT WIDGETS
  // ═══════════════════════════════════════════════════════════════════════════

  // ─── WIDGET 1 — Upgraded Performance Efficiency ────────────────────────────
  function buildEfficiency(data) {
    const D = data.effData;
    const W = 950, H = 260;
    const pad = { t: 20, r: 16, b: 40, l: 44 };
    const cW  = W - pad.l - pad.r;
    const cH  = H - pad.t - pad.b;

    const maxV  = Math.max(...D.map(d => Math.max(d.solved, d.attempted, 1))) * 1.12;
    const scY   = v => cH - (v / maxV) * cH;
    const bGrp  = cW / D.length;
    const bW    = bGrp * 0.28;

    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
    svg.setAttribute('class', 'cfd-chart-svg');
    svg.style.maxHeight = H + 'px';

    for (let i = 0; i <= 4; i++) {
      const y   = pad.t + (i / 4) * cH;
      const val = Math.round(maxV * (1 - i / 4));
      const l   = svgNS('line', { class: 'cfd-grid-line', x1: pad.l, y1: y, x2: pad.l + cW, y2: y });
      const t   = svgNS('text', { class: 'cfd-axis-text', x: pad.l - 5, y: y + 3.5, 'text-anchor': 'end' });
      t.textContent = val;
      svg.appendChild(l);
      svg.appendChild(t);
    }

    const axV = svgNS('line', { class: 'cfd-grid-line', x1: pad.l, y1: pad.t, x2: pad.l, y2: pad.t + cH, 'stroke-width': 1.5 });
    const axH = svgNS('line', { class: 'cfd-grid-line', x1: pad.l, y1: pad.t + cH, x2: pad.l + cW, y2: pad.t + cH, 'stroke-width': 1.5 });
    svg.appendChild(axV);
    svg.appendChild(axH);

    D.forEach((d, i) => {
      const gx  = pad.l + i * bGrp + bGrp * 0.16;
      const aH  = d.attempted > 0 ? (d.attempted / maxV) * cH : 0;
      const sH  = d.solved    > 0 ? (d.solved    / maxV) * cH : 0;

      const hasRival = data.rivalEffData && data.rivalEffData.length > i;
      const rS = hasRival ? data.rivalEffData[i].solved : 0;
      const rH = rS > 0 ? (rS / maxV) * cH : 0;

      const activeBarW = hasRival ? bW * 0.75 : bW;
      const gap = hasRival ? 2 : 4;

      const bA = svgNS('rect', {
        class: 'cfd-bar-a',
        x: gx, y: pad.t + scY(d.attempted), width: activeBarW, height: aH, rx: 2,
        'data-lbl': d.label, 'data-att': d.attempted, 'data-slv': d.solved, 'data-eff': d.efficiency
      });

      const bS = svgNS('rect', {
        class: 'cfd-bar-s',
        x: gx + activeBarW + gap, y: pad.t + scY(d.solved), width: activeBarW, height: sH, rx: 2,
        'data-lbl': d.label, 'data-att': d.attempted, 'data-slv': d.solved, 'data-eff': d.efficiency
      });

      let bR = null;
      if (hasRival) {
        bR = svgNS('rect', {
          class: 'cfd-bar-r',
          fill: '#3b5998',
          'fill-opacity': 0.6,
          x: gx + 2 * (activeBarW + gap), y: pad.t + scY(rS), width: activeBarW, height: rH, rx: 2,
          'data-lbl': d.label, 'data-att': d.attempted, 'data-slv': d.solved, 'data-riv': rS
        });
      }

      const lbl = svgNS('text', {
        class: 'cfd-axis-text',
        x: gx + activeBarW + gap,
        y: pad.t + cH + 16,
        'text-anchor': 'middle', 'font-size': '10'
      });
      lbl.textContent = d.label;

      [bA, bS].forEach(b => {
        b.addEventListener('mouseenter', e => {
          const ds = e.target.dataset;
          showTip(e, `<b>${ds.lbl}</b><br>Attempted: ${ds.att} · Solved: <b>${ds.slv}</b><br>Efficiency: <b>${ds.eff}%</b>`);
        });
        b.addEventListener('mousemove', moveTip);
        b.addEventListener('mouseleave', hideTip);
      });

      if (bR) {
        bR.addEventListener('mouseenter', e => {
          const ds = e.target.dataset;
          showTip(e, `<b>${ds.lbl} (Rival comparison Overlay)</b><br>Rival Solved: <b>${ds.riv}</b>`);
        });
        bR.addEventListener('mousemove', moveTip);
        bR.addEventListener('mouseleave', hideTip);
      }

      svg.appendChild(bA);
      svg.appendChild(bS);
      if (bR) svg.appendChild(bR);
      svg.appendChild(lbl);
    });

    const legendHtml = `
       <div class="cfd-legend">
         <span style="display:flex;align-items:center;gap:5px"><span class="cfd-legend-dot" style="background:var(--cfd-bar-attempt)"></span>Attempted</span>
         <span style="display:flex;align-items:center;gap:5px"><span class="cfd-legend-dot" style="background:var(--cfd-bar-solved)"></span>Solved</span>
         ${data.rivalEffData ? `<span style="display:flex;align-items:center;gap:5px"><span class="cfd-legend-dot" style="background:#3b5998;opacity:0.6"></span>Rival Overlay Solves</span>` : ''}
       </div>`;

    const wrap = document.createElement('div');
    wrap.innerHTML = makeCard(
      `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="1" y="9" width="3" height="6"/><rect x="6" y="6" width="3" height="9"/><rect x="11" y="3" width="3" height="12"/></svg>
       Performance Efficiency`,
      `<div id="cfd-eff-svg"></div>${legendHtml}`
    );
    wrap.querySelector('#cfd-eff-svg').appendChild(svg);
    return wrap;
  }

  // ─── WIDGET 2 — Tag Power Radar ────────────────────────────────────────────
  function buildTagPower(data) {
    const tags   = data.tagPower;
    const SZ     = 270;
    const cx     = SZ / 2, cy = SZ / 2, R = 96;
    const n      = tags.length;
    const maxPow = Math.max(...tags.map(t => t.avg), 2200);

    function pt(i, val) {
      const ang = (i / n) * 2 * Math.PI - Math.PI / 2;
      const rr  = (val / maxPow) * R;
      return { x: cx + rr * Math.cos(ang), y: cy + rr * Math.sin(ang) };
    }

    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', `0 0 ${SZ} ${SZ}`);
    svg.style.cssText = `width:100%;max-height:${SZ}px;display:block`;

    for (let l = 1; l <= 4; l++) {
      const pts = tags.map((_, i) => { const p = pt(i, l / 4 * maxPow); return `${p.x},${p.y}`; }).join(' ');
      svg.appendChild(svgNS('polygon', { class: 'cfd-radar-web', points: pts }));
    }

    tags.forEach((_, i) => {
      const p = pt(i, maxPow);
      svg.appendChild(svgNS('line', { class: 'cfd-radar-spoke', x1: cx, y1: cy, x2: p.x, y2: p.y }));
    });

    const defs  = svgNS('defs');
    const grad  = svgNS('linearGradient', { id: 'cfdRG', x1: '0', y1: '0', x2: '1', y2: '1' });
    const s1    = svgNS('stop', { offset: '0%',   'stop-color': 'var(--cfd-accent)' });
    const s2    = svgNS('stop', { offset: '100%', 'stop-color': 'var(--cfd-accent)', 'stop-opacity': '0.4' });
    grad.appendChild(s1); grad.appendChild(s2); defs.appendChild(grad);
    svg.appendChild(defs);

    const fillPts = tags.map((t, i) => { const p = pt(i, t.avg); return `${p.x},${p.y}`; }).join(' ');
    svg.appendChild(svgNS('polygon', { class: 'cfd-radar-fill', points: fillPts }));

    tags.forEach((t, i) => {
      const p     = pt(i, t.avg);
      const labelP = pt(i, maxPow * 1.24);

      const dot = svgNS('circle', { class: 'cfd-radar-dot', cx: p.x, cy: p.y, r: 4 });
      dot.addEventListener('mouseenter', e => showTip(e, `<b>${t.tag}</b><br>Avg: <b style="color:${ratingColor(t.avg)}">${t.avg || '—'}</b> · ${t.count} solved`));
      dot.addEventListener('mousemove', moveTip);
      dot.addEventListener('mouseleave', hideTip);

      const lbl = svgNS('text', { class: 'cfd-radar-label', x: labelP.x, y: labelP.y + 3.5 });
      lbl.textContent = t.label;
      svg.appendChild(dot);
      svg.appendChild(lbl);
    });

    const wrap = document.createElement('div');
    wrap.innerHTML = makeCard(
      `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8"><polygon points="8,1 15,6 12,15 4,15 1,6"/></svg>
       Tag Power Radar`,
      `<div id="cfd-radar-svg" style="display:flex;justify-content:center"></div>`
    );
    wrap.querySelector('#cfd-radar-svg').appendChild(svg);
    return wrap;
  }

  // ─── WIDGET 3 — Upsolving Tracker ──────────────────────────────────────────
  function buildUpsolving(data) {
    const { upsolve } = data;

    const categories = [
      { key: 'closeCalls', label: `Close Calls (${upsolve.closeCalls.length})`, cls: 'close', verdictColor: 'var(--cfd-wa)' },
      { key: 'edgeCases',  label: `Edge Cases (${upsolve.edgeCases.length})`,   cls: 'edge',  verdictColor: 'var(--cfd-tle)' },
      { key: 'crashes',    label: `Crashes (${upsolve.crashes.length})`,         cls: 'crash', verdictColor: 'var(--cfd-re)' }
    ];

    let activeKey = 'closeCalls';

    function buildRows(key) {
      const items = upsolve[key];
      if (!items.length) {
        return `<div class="cfd-empty"><div class="cfd-empty-icon">✅</div>No problems in this category — keep it up!</div>`;
      }
      return `<div class="cfd-prob-list">${items.slice(0, 60).map(item => {
        const rc = ratingColor(item.problem.rating);
        const vshort = item.verdict.replace('_', ' ').replace('WRONG ANSWER', 'WA').replace('TIME LIMIT EXCEEDED', 'TLE').replace('RUNTIME ERROR', 'RE').replace('COMPILATION ERROR', 'CE').replace('MEMORY LIMIT EXCEEDED', 'MLE');
        return `
          <a href="${item.url}" target="_blank" class="cfd-prob-row" rel="noopener">
            <span class="cfd-prob-rating-badge" style="color:${rc}">${item.problem.rating || '?'}</span>
            <span class="cfd-prob-name">${item.problem.name || item.problem.index}</span>
            <span class="cfd-prob-verdict" style="color:${rc};background:${rc}18">${vshort}</span>
          </a>`;
      }).join('')}</div>`;
    }

    function buildTabs() {
      return categories.map(c =>
        `<button class="cfd-cat-tab${c.key === activeKey ? ' cfd-tab-on' : ''}" data-key="${c.key}">${c.label}</button>`
      ).join('');
    }

    const wrap = document.createElement('div');
    function render() {
      wrap.innerHTML = makeCard(
        `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="8" cy="8" r="7"/><line x1="8" y1="4" x2="8" y2="9"/><circle cx="8" cy="11.5" r=".7" fill="currentColor" stroke="none"/></svg>
         Close Calls · Upsolving Tracker`,
        `<div class="cfd-cat-tabs" id="cfd-cat-tabs">${buildTabs()}</div>
         <div id="cfd-cat-body">${buildRows(activeKey)}</div>`
      );
      wrap.querySelectorAll('.cfd-cat-tab').forEach(btn => {
        btn.addEventListener('click', () => {
          activeKey = btn.dataset.key;
          render();
        });
      });
    }

    render();
    return wrap;
  }

  // ─── WIDGET 4 — Activity Heatmap ───────────────────────────────────────────
  function buildHeatmap(data) {
    const { heatDays, heatmapStats } = data;
    const CELL = 11, GAP = 2.5, STEP = 11 + 2.5;
    const WEEKS = 53, DAYS = 7;
    const PL = 26, PT = 18;
    const W  = PL + WEEKS * STEP + 4;
    const H  = PT + DAYS  * STEP + 22;

    const maxCount = Math.max(...Object.values(heatDays), 1);
    const heatVars = ['var(--cfd-heat-0)', 'var(--cfd-heat-1)', 'var(--cfd-heat-2)', 'var(--cfd-heat-3)', 'var(--cfd-heat-4)'];

    function heatFill(count) {
      if (!count) return heatVars[0];
      const p = count / maxCount;
      if (p < 0.25) return heatVars[1];
      if (p < 0.50) return heatVars[2];
      if (p < 0.75) return heatVars[3];
      return heatVars[4];
    }

    const todayLocal = new Date();
    todayLocal.setHours(23, 59, 59, 999);
    const start = new Date(todayLocal);
    start.setDate(start.getDate() - todayLocal.getDay() - 52 * 7);
    start.setHours(0, 0, 0, 0);

    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
    svg.style.cssText = `width:100%;max-height:${H}px;display:block`;

    const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const WDAYS  = ['','Mon','','Wed','','Fri',''];
    let prevMonth = -1;

    WDAYS.forEach((name, d) => {
      if (!name) return;
      const t = svgNS('text', { class: 'cfd-hmap-day-lbl', x: PL - 4, y: PT + d * STEP + CELL - 1, 'text-anchor': 'end' });
      t.textContent = name;
      svg.appendChild(t);
    });

    for (let w = 0; w < WEEKS; w++) {
      for (let d = 0; d < DAYS; d++) {
        const date = new Date(start.getTime() + (w * 7 + d) * 86_400_000);
        if (date > todayLocal) continue;

        const key   = fmtDate(date);
        const count = heatDays[key] || 0;
        const x     = PL + w * STEP;
        const y     = PT + d * STEP;

        const cell = svgNS('rect', {
          class: 'cfd-hmap-cell', x, y,
          width: CELL, height: CELL, rx: 2,
          fill: heatFill(count),
          'data-date': key, 'data-count': count
        });

        cell.addEventListener('mouseenter', e => {
          const { date: dt, count: ct } = e.target.dataset;
          showTip(e, `<b>${dt}</b><br>${ct} submission${ct == 1 ? '' : 's'}`);
        });
        cell.addEventListener('mousemove', moveTip);
        cell.addEventListener('mouseleave', hideTip);
        svg.appendChild(cell);

        if (d === 0) {
          const month = date.getMonth();
          if (month !== prevMonth) {
            prevMonth = month;
            const mt = svgNS('text', { class: 'cfd-hmap-month-lbl', x: x, y: PT - 4 });
            mt.textContent = MONTHS[month];
            svg.appendChild(mt);
          }
        }
      }
    }

    const legendHtml = `
      <div class="cfd-legend" style="margin-top:8px">
        <span style="font-size:10px;color:var(--cfd-text-muted)">Less</span>
        ${heatVars.map(v => `<span style="width:11px;height:11px;background:${v};border-radius:2px;display:inline-block"></span>`).join('')}
        <span style="font-size:10px;color:var(--cfd-text-muted)">More</span>
        <span style="margin-left:auto;font-size:11px;color:var(--cfd-text-muted)">Current streak: <b style="color:var(--cfd-text)">${heatmapStats.currentStreak}</b> · Max: <b style="color:var(--cfd-text)">${heatmapStats.maxStreak}</b></span>
      </div>`;

    const wrap = document.createElement('div');
    wrap.innerHTML = makeCard(
      `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="1" y="4" width="14" height="11" rx="2"/><line x1="5" y1="1" x2="5" y2="6"/><line x1="11" y1="1" x2="11" y2="6"/></svg>
       Activity Heatmap · Last 365 Days`,
      `<div class="cfd-heatmap-scroll" id="cfd-hmap-svg"></div>${legendHtml}`
    );
    wrap.querySelector('#cfd-hmap-svg').appendChild(svg);
    return wrap;
  }

  // ─── WIDGET 5 — Contest Rating Chart ───────────────────────────────────────
  function buildContestChart(data) {
    const { ratingHistory: RH, virtualPoints: VP } = data;

    const wrap = document.createElement('div');
    if (!RH.length) {
      wrap.innerHTML = makeCard(
        `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8"><polyline points="1,13 5,8 8,11 11,5 15,8"/></svg>
         Virtual vs Live Contest Analysis`,
        `<div class="cfd-empty"><div class="cfd-empty-icon">📈</div>No rated contest history found yet.</div>`
      );
      return wrap;
    }

    const W = 950, H = 250;
    const pad = { t: 16, r: 16, b: 36, l: 48 };
    const cW  = W - pad.l - pad.r;
    const cH  = H - pad.t - pad.b;

    const allR = RH.map(r => r.newRating).concat(VP.map(v => v.estimatedRating));
    const minR = Math.min(...allR) - 80;
    const maxR = Math.max(...allR) + 80;
    const minT = RH[0].ratingUpdateTimeSeconds * 1000;
    const maxT = Math.max(RH[RH.length - 1].ratingUpdateTimeSeconds * 1000, Date.now());

    const sx = t  => pad.l + ((t - minT) / (maxT - minT)) * cW;
    const sy = r  => pad.t + cH - ((r - minR) / (maxR - minR)) * cH;

    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
    svg.style.cssText = `width:100%;max-height:${H}px;display:block`;

    const defs  = svgNS('defs');
    const grad  = svgNS('linearGradient', { id: 'cfdAreaGrad', x1: '0', y1: '0', x2: '0', y2: '1' });
    const gs1   = svgNS('stop', { offset: '0%',   'stop-color': 'var(--cfd-accent)', 'stop-opacity': '0.4' });
    const gs2   = svgNS('stop', { offset: '100%', 'stop-color': 'var(--cfd-accent)', 'stop-opacity': '0' });
    grad.appendChild(gs1); grad.appendChild(gs2); defs.appendChild(grad);
    svg.appendChild(defs);

    const bands = [
      { min: 0,    max: 1200, color: '#80808008' },
      { min: 1200, max: 1400, color: '#00800008' },
      { min: 1400, max: 1600, color: '#03a89e08' },
      { min: 1600, max: 1900, color: '#0000ff08' },
      { min: 1900, max: 2100, color: '#aa00aa08' },
      { min: 2100, max: 2400, color: '#ff8c0008' },
      { min: 2400, max: 9999, color: '#ff333308' }
    ];

    bands.forEach(band => {
      const y1 = sy(Math.min(band.max, maxR));
      const y2 = sy(Math.max(band.min, minR));
      if (y2 > y1) {
        svg.appendChild(svgNS('rect', {
          x: pad.l, y: y1, width: cW, height: y2 - y1,
          fill: band.color
        }));
      }
    });

    for (let i = 0; i <= 5; i++) {
      const r = Math.round(minR + (i / 5) * (maxR - minR));
      const y = sy(r);
      svg.appendChild(svgNS('line', { class: 'cfd-grid-line', x1: pad.l, y1: y, x2: pad.l + cW, y2: y }));
      const t = svgNS('text', { class: 'cfd-axis-text', x: pad.l - 5, y: y + 3.5, 'text-anchor': 'end' });
      t.textContent = r;
      svg.appendChild(t);
    }

    const livePts = RH.map(r => `${sx(r.ratingUpdateTimeSeconds * 1000)},${sy(r.newRating)}`);
    const lastX   = sx(RH[RH.length - 1].ratingUpdateTimeSeconds * 1000);
    const areaD   = `M${livePts[0]} L${livePts.join(' L')} L${lastX},${pad.t + cH} L${pad.l},${pad.t + cH} Z`;
    svg.appendChild(svgNS('path', { class: 'cfd-rating-area', d: areaD }));

    const line = svgNS('polyline', { class: 'cfd-rating-line', points: livePts.join(' ') });
    svg.appendChild(line);

    RH.forEach(r => {
      const x = sx(r.ratingUpdateTimeSeconds * 1000);
      const y = sy(r.newRating);
      const delta = r.newRating - r.oldRating;
      const dot = svgNS('circle', {
        class: 'cfd-rdot-live', cx: x, cy: y, r: 4,
        fill: delta >= 0 ? 'var(--cfd-ok)' : 'var(--cfd-wa)',
        stroke: 'var(--cfd-card-bg)', 'stroke-width': 1.5
      });
      const cname = (r.contestName || 'Contest').replace(/"/g, "'");
      dot.addEventListener('mouseenter', e => {
        const sign = delta >= 0 ? '+' : '';
        showTip(e, `<b>${cname}</b><br>${r.oldRating} → <b style="color:${ratingColor(r.newRating)}">${r.newRating}</b> (<b>${sign}${delta}</b>)`);
      });
      dot.addEventListener('mousemove', moveTip);
      dot.addEventListener('mouseleave', hideTip);
      svg.appendChild(dot);
    });

    VP.forEach(v => {
      const x = sx(v.timestamp);
      const y = sy(v.estimatedRating);
      const dot = svgNS('circle', {
        class: 'cfd-rdot-virtual', cx: x, cy: y, r: 5,
        fill: 'var(--cfd-crash)', stroke: 'var(--cfd-card-bg)', 'stroke-width': 1.5
      });
      dot.addEventListener('mouseenter', e => showTip(e, `<b>Virtual Contest</b><br>Est. Rating: <b>${v.estimatedRating}</b>`));
      dot.addEventListener('mousemove', moveTip);
      dot.addEventListener('mouseleave', hideTip);
      svg.appendChild(dot);
    });

    svg.appendChild(svgNS('line', { class: 'cfd-grid-line', x1: pad.l, y1: pad.t, x2: pad.l, y2: pad.t + cH, 'stroke-width': 1.5 }));
    svg.appendChild(svgNS('line', { class: 'cfd-grid-line', x1: pad.l, y1: pad.t + cH, x2: pad.l + cW, y2: pad.t + cH, 'stroke-width': 1.5 }));

    wrap.innerHTML = makeCard(
      `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8"><polyline points="1,13 5,8 8,11 11,5 15,8"/></svg>
       Virtual vs Live Contest Analysis`,
      `<div id="cfd-ct-svg"></div>
       <div class="cfd-legend">
         <span style="display:flex;align-items:center;gap:5px"><span class="cfd-legend-dot" style="background:var(--cfd-accent)"></span>Live Rating</span>
         <span style="display:flex;align-items:center;gap:5px"><span class="cfd-legend-dot" style="background:var(--cfd-ok)"></span>Rating ↑</span>
         <span style="display:flex;align-items:center;gap:5px"><span class="cfd-legend-dot" style="background:var(--cfd-wa)"></span>Rating ↓</span>
         <span style="display:flex;align-items:center;gap:5px"><span class="cfd-legend-dot" style="background:var(--cfd-crash)"></span>Virtual (est.)</span>
       </div>`
    );
    wrap.querySelector('#cfd-ct-svg').appendChild(svg);
    return wrap;
  }

  // ─── WIDGET 6 — Weakness Recommender ───────────────────────────────────────
  function buildRecommender(data, problemset) {
    const { tagPower, userInfo } = data;
    const rating = userInfo?.rating || 1200;

    const weakTags = tagPower
      .filter(t => t.count >= 2 && t.avg < rating - 80)
      .sort((a, b) => a.avg - b.avg)
      .slice(0, 5)
      .map(t => t.tag);

    const used    = new Set();
    const recs    = [];
    const minR    = rating - 50, maxR = rating + 250;

    for (const tag of weakTags) {
      if (recs.length >= 3) break;
      const cands = (problemset || []).filter(p =>
        p.tags?.includes(tag) && p.rating >= minR && p.rating <= maxR && !used.has(`${p.contestId}_${p.index}`)
      );
      if (!cands.length) continue;
      cands.sort((a, b) => Math.abs(a.rating - (rating + 100)) - Math.abs(b.rating - (rating + 100)));
      const pick = cands[0];
      used.add(`${pick.contestId}_${pick.index}`);
      recs.push({ tag, problem: pick });
    }

    if (recs.length < 3 && problemset?.length) {
      const pool = problemset.filter(p => p.rating >= rating && p.rating <= rating + 200 && !used.has(`${p.contestId}_${p.index}`));
      pool.sort(() => Math.random() - 0.5);
      for (const p of pool) {
        if (recs.length >= 3) break;
        used.add(`${p.contestId}_${p.index}`);
        recs.push({ tag: (p.tags || ['general'])[0], problem: p });
      }
    }

    const recsHtml = recs.length ? `
      <div class="cfd-rec-cards">
        ${recs.map((rec, i) => `
          <a href="https://codeforces.com/problemset/problem/${rec.problem.contestId}/${rec.problem.index}" target="_blank" class="cfd-rec-card" rel="noopener">
            <div class="cfd-rec-card-head">
              <div class="cfd-rec-idx">${i + 1}</div>
              <div class="cfd-rec-tag-label">${rec.tag}</div>
            </div>
            <div class="cfd-rec-card-body">
              <div class="cfd-rec-pname">${rec.problem.name}</div>
              <div class="cfd-rec-detail" style="color:${ratingColor(rec.problem.rating)}">Rating ${rec.problem.rating} · ${rec.problem.contestId}${rec.problem.index}</div>
            </div>
          </a>`).join('')}
      </div>`
    : `<div class="cfd-empty"><div class="cfd-empty-icon">🎯</div>Not enough solve data yet — keep going!</div>`;

    const wrap = document.createElement('div');
    wrap.innerHTML = makeCard(
      `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="8" cy="8" r="7"/><circle cx="8" cy="8" r="3"/><line x1="8" y1="1" x2="8" y2="5"/></svg>
       Weakness Focus Recommender <span style="font-weight:400;font-size:11px;color:var(--cfd-text-muted);margin-left:6px">· target rating ${rating + 100}</span>`,
      recsHtml
    );
    return wrap;
  }

  // ─── WIDGET 7 — Stat Strip (4 Columns) ─────────────────────────────────────
  function buildStatStrip(data) {
    const { userInfo, uniqueSolved, totalSubmissions, heatmapStats } = data;
    const rating    = userInfo?.rating;
    const maxRating = userInfo?.maxRating;
    const rc        = ratingColor(rating);
    const rl        = ratingLabel(rating);

    const tiles = [
      {
        val:   `<span style="color:${rc}">${rating || '—'}</span>`,
        lbl:   `Rating · <span style="color:var(--cfd-text)">${rl}</span>`,
        sub:   `Peak: <b style="color:${ratingColor(maxRating)}">${maxRating || '—'}</b>`
      },
      {
        val:   uniqueSolved,
        lbl:   'Problems Solved',
        sub:   `of ${data.totalProblems} attempted`
      },
      {
        val:   heatmapStats.currentStreak + '<span style="font-size:14px;font-weight:400"> days</span>',
        lbl:   'Current Streak 🔥',
        sub:   `Max streak: <b>${heatmapStats.maxStreak}</b>`
      },
      {
        val:   totalSubmissions.toLocaleString(),
        lbl:   'Total Submissions',
        sub:   `${uniqueSolved} accepted`
      }
    ];

    return `<div class="cfd-stat-strip">
      ${tiles.map((t, i) => `
        <div class="cfd-stat-tile cfd-animate cfd-delay-${i+1}">
          <div class="cfd-stat-tile-val">${t.val}</div>
          <div class="cfd-stat-tile-lbl">${t.lbl}</div>
          <div class="cfd-stat-tile-sub">${t.sub}</div>
        </div>`).join('')}
    </div>`;
  }

  // ─── WIDGET 8 — Velocity Scatter Plot ──────────────────────────────────────
  function buildVelocityScatterPlot(workerResult) {
    if (!workerResult || !workerResult.scatterPoints || workerResult.scatterPoints.length === 0) {
      return makeCard(
        `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8"><line x1="1" y1="15" x2="15" y2="15"/><line x1="1" y1="1" x2="1" y2="15"/><circle cx="5" cy="5" r="4"/><circle cx="10" cy="10" r="4"/><path d="M4 12 l4-4 4 4"/></svg>
         Velocity & Penalty Time Analytics`,
        `<div class="cfd-empty"><div class="cfd-empty-icon">⏳</div>No contestant submissions found. Pacing analytics unlock once you participate in rated rounds!</div>`
      );
    }

    const points = workerResult.scatterPoints;
    const avgAgony = workerResult.avgAgony;
    const maxAgony = workerResult.maxAgony;

    const W = 950, H = 260;
    const pad = { t: 20, r: 20, b: 35, l: 40 };
    const cW = W - pad.l - pad.r;
    const cH = H - pad.t - pad.b;

    const cols = ['A', 'B', 'C', 'D', 'E', 'F', 'G'];
    const colWidth = cW / cols.length;

    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
    svg.setAttribute('class', 'cfd-chart-svg');
    svg.style.maxHeight = H + 'px';

    const timeBrackets = [
      { val: 60,  lbl: '1h' },
      { val: 120, lbl: '2h' },
      { val: 180, lbl: '3h' },
      { val: 240, lbl: '4h' }
    ];

    timeBrackets.forEach(tb => {
      const y = pad.t + cH - (tb.val / 300) * cH;
      const l = svgNS('line', { class: 'cfd-grid-line', x1: pad.l, y1: y, x2: pad.l + cW, y2: y, 'stroke-dasharray': '2,3' });
      const t = svgNS('text', { class: 'cfd-axis-text', x: pad.l - 6, y: y + 3.5, 'text-anchor': 'end' });
      t.textContent = tb.lbl;
      svg.appendChild(l);
      svg.appendChild(t);
    });

    const tMax = svgNS('text', { class: 'cfd-axis-text', x: pad.l - 6, y: pad.t + 3.5, 'text-anchor': 'end' });
    tMax.textContent = '5h';
    svg.appendChild(tMax);

    const axY = svgNS('line', { class: 'cfd-grid-line', x1: pad.l, y1: pad.t, x2: pad.l, y2: pad.t + cH, 'stroke-width': 1.5 });
    svg.appendChild(axY);

    cols.forEach((col, i) => {
      const cx = pad.l + i * colWidth + colWidth / 2;
      
      if (i > 0) {
        const lCol = svgNS('line', { class: 'cfd-grid-line', x1: pad.l + i * colWidth, y1: pad.t, x2: pad.l + i * colWidth, y2: pad.t + cH, 'stroke-opacity': 0.5 });
        svg.appendChild(lCol);
      }

      const tX = svgNS('text', {
        class: 'cfd-axis-text',
        x: cx, y: pad.t + cH + 16,
        'text-anchor': 'middle', 'font-size': '11', 'font-weight': '600'
      });
      tX.textContent = col;
      svg.appendChild(tX);
    });

    const axX = svgNS('line', { class: 'cfd-grid-line', x1: pad.l, y1: pad.t + cH, x2: pad.l + cW, y2: pad.t + cH, 'stroke-width': 1.5 });
    svg.appendChild(axX);

    points.forEach(pt => {
      const colIdx = cols.indexOf(pt.problem);
      if (colIdx < 0) return;

      const jitterRange = colWidth * 0.45;
      const seed = Math.sin(pt.minutes * 17) * 0.5;
      const cx = pad.l + colIdx * colWidth + colWidth / 2 + seed * jitterRange;
      const cy = pad.t + cH - (pt.minutes / 300) * cH;

      const dotColor = pt.isAC ? 'var(--cfd-ok)' : 'var(--cfd-wa)';
      const dotOpacity = pt.isAC ? '0.85' : '0.45';
      const dotRadius = pt.isAC ? '5' : '3.8';

      const dot = svgNS('circle', {
        class: 'cfd-scatter-dot',
        cx: cx, cy: cy, r: dotRadius,
        fill: dotColor, 'fill-opacity': dotOpacity,
        'data-title': pt.contestName,
        'data-prob': `${pt.problem}: ${pt.problemName}`,
        'data-mins': pt.minutes,
        'data-verdict': pt.isAC ? 'Accepted' : 'Incorrect Attempt'
      });

      dot.addEventListener('mouseenter', e => {
        const ds = e.target.dataset;
        showTip(e, `<b>${ds.title}</b><br>Problem <b>${ds.prob}</b><br>Verdict: <span style="color:${ds.verdict === 'Accepted' ? 'var(--cfd-ok)' : 'var(--cfd-wa)'}"><b>${ds.verdict}</b></span> at <b>${ds.mins} mins</b>`);
      });
      dot.addEventListener('mousemove', moveTip);
      dot.addEventListener('mouseleave', hideTip);

      svg.appendChild(dot);
    });

    let agonyInsight = "Your contest pace is balanced. Review incorrect submissions early in contests to save penalty minutes.";
    if (avgAgony > 35) {
      agonyInsight = `You solve problems quickly on initial tries. When hit with a WA, your average recovery of <b>${avgAgony} minutes</b> indicates frantic over-editing. Try dry-running base constraints locally before resubmitting.`;
    } else if (avgAgony > 0) {
      agonyInsight = `Outstanding debugging cycle! Your average WA recovery time of <b>${avgAgony} minutes</b> shows disciplined mental pivoting under pressure.`;
    }

    let agonyMetricHtml = '';
    if (avgAgony > 0) {
      agonyMetricHtml = `
        <div class="cfd-agony-strip">
          <div class="cfd-agony-metric-box">
            <span class="cfd-agony-val">${avgAgony}m</span>
            <span class="cfd-agony-lbl">Average Recovery (Agony)</span>
          </div>
          <div class="cfd-agony-metric-box">
            <span class="cfd-agony-val" style="color:var(--cfd-tle)">${maxAgony.minutes}m</span>
            <span class="cfd-agony-lbl">Worst Block (Problem ${maxAgony.problem})</span>
          </div>
          <div class="cfd-agony-metric-box" style="flex:2.2; background:rgba(var(--cfd-accent-rgb), 0.05); border-left:3px solid var(--cfd-accent)">
            <span style="font-size:11px; font-weight:700; color:var(--cfd-text-header); margin-bottom:2px">⚡ Mock Coach Pacing Insight</span>
            <span style="font-size:10.5px; line-height:1.35; color:var(--cfd-text)">${agonyInsight}</span>
          </div>
        </div>`;
    }

    const wrap = document.createElement('div');
    wrap.innerHTML = makeCard(
      `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8"><line x1="1" y1="15" x2="15" y2="15"/><line x1="1" y1="1" x2="1" y2="15"/><circle cx="5" cy="5" r="4"/><circle cx="10" cy="10" r="4"/><path d="M4 12 l4-4 4 4"/></svg>
       Velocity & Penalty Time Analytics`,
      `<div id="cfd-vel-svg"></div>
       <div class="cfd-legend" style="margin-top: 6px">
         <span style="display:flex;align-items:center;gap:5px"><span class="cfd-legend-dot" style="background:var(--cfd-ok)"></span>Accepted Pacing</span>
         <span style="display:flex;align-items:center;gap:5px"><span class="cfd-legend-dot" style="background:var(--cfd-wa)"></span>Failed Attempts</span>
       </div>
       ${agonyMetricHtml}`
    );
    wrap.querySelector('#cfd-vel-svg').appendChild(svg);
    return wrap;
  }

  // ─── WIDGET 9 — Mock Coach Strategic Retrospective ────────────────────────
  function buildMockCoachWidget(workerResult) {
    if (!workerResult || !workerResult.coachCards || workerResult.coachCards.length === 0) {
      return makeCard(
        `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 1H4C2.34315 1 1 2.34315 1 4V12C1 13.6569 2.34315 15 4 15H12C13.6569 15 15 13.6569 15 12V4C15 2.34315 13.6569 1 12 1Z"/><path d="M4 6h8M4 10h5"/></svg>
         Mock Coach Tactical Retrospective`,
        `<div class="cfd-empty"><div class="cfd-empty-icon">👨‍🏫</div>No recent round retrospectives. Complete mock virtual rounds to trigger coaches audits!</div>`
      );
    }

    const cardsHtml = workerResult.coachCards.map(c => {
      let issuesHtml = '';
      if (c.overSubmitter) {
        issuesHtml += `
          <div class="cfd-coach-issue">
            <span style="font-size:14px">⚠️</span>
            <div>
              <b style="color:var(--cfd-wa)">The Over-Submitter Habit:</b> You made 5+ rapid attempts on a single problem index during this round. 
              <i>Mock Coach tip:</i> Rushing code modifications yields massive penalties. Test extreme constraints locally first!
            </div>
          </div>`;
      }
      if (c.rabbitHole) {
        issuesHtml += `
          <div class="cfd-coach-issue">
            <span style="font-size:14px">⌛</span>
            <div>
              <b style="color:var(--cfd-tle)">The Rabbit Hole Trap:</b> You got locked on <b>Problem ${c.rabbitHole.problem}</b> for <b>${c.rabbitHole.minutes} minutes</b> straight.
              <i>Mock Coach tip:</i> Staying blocked for >45m without pivoting limits points. Pivot to alternate tasks and return with a fresh perspective later.
            </div>
          </div>`;
      }
      if (c.weakFinish && c.weakFinish.length > 0) {
        const probs = c.weakFinish.map(p => `<b>${p.index} (${p.rating || '?'})</b>`).join(', ');
        issuesHtml += `
          <div class="cfd-coach-issue">
            <span style="font-size:14px">🏹</span>
            <div>
              <b style="color:var(--cfd-accent)">Weak Finish (Upsolve Deficit):</b> You abandoned problem(s) ${probs} without eventual upsolving.
              <i>Mock Coach tip:</i> Attempting problems just +100 above your current tier is the absolute fastest way to trigger a rating spike. Upsolve them!
            </div>
          </div>`;
      }

      if (!issuesHtml) {
        issuesHtml = `
          <div class="cfd-coach-issue" style="color:var(--cfd-ok)">
            <span style="font-size:14px">🎉</span>
            <div><b>Flawless Round Execution!</b> Your submission pacing, problem swaps, and local dry-runs were perfect. Keep up this execution strategy!</div>
          </div>`;
      }

      return `
        <div class="cfd-coach-card">
          <div class="cfd-coach-card-title">${c.contestName}</div>
          ${issuesHtml}
        </div>`;
    }).join('');

    const wrap = document.createElement('div');
    wrap.innerHTML = makeCard(
      `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="8" cy="8" r="6"/><path d="M8 5v4M8 11h.01"/></svg>
       Mock Coach Tactical Retrospective`,
      `<div class="cfd-coach-grid">${cardsHtml}</div>`
    );
    return wrap;
  }

  // ─── WIDGET 10 — Language/System Diagnostics warning ───────────────────────
  function buildSystemDiagnosticWidget(diagnostics) {
    if (!diagnostics || !diagnostics.isHighOverhead) return null;

    const listHtml = diagnostics.dangerousRuns.map(r => 
      `<b>Problem ${r.problem}</b> (execution: ${r.time}ms / limit: ${r.limit}ms using ${r.lang})`
    ).join(' and ');

    const wrap = document.createElement('div');
    wrap.className = 'cfd-diag-banner cfd-animate cfd-delay-6';
    wrap.style.marginTop = '14px';
    wrap.innerHTML = `
      <div class="cfd-diag-warn-icon">🚀</div>
      <div>
        <b style="color:var(--cfd-tle)">Language Performance Overhead Alert:</b> 
        Your Solutions are clocking close to time-limit maximum boundaries in 
        ${listHtml}. Because Java/Python incur garbage collection and slow I/O runtime penalties relative to C++, 
        consider wrapping inputs in a custom <b>Fast I/O Scanner</b> buffer (Java) or writing 
        <b>sys.stdin.readline()</b> (Python) to secure your complex algorithm passes!
      </div>`;
    return wrap;
  }

  // ─── WIDGET 11 — Shadow Mode Deficit Practice Gap Table ────────────────────
  function buildPracticeGapWidget(gapAnalysis, shadowHandle) {
    let listHtml = '';
    if (!shadowHandle) {
      listHtml = `
        <div class="cfd-empty" style="padding: 12px 0">
          <div style="font-size:24px">👥</div>
          Enter a rival Codeforces handle to activate <b>Shadow Mode Deficits Mapping</b>.
        </div>`;
    } else if (!gapAnalysis || gapAnalysis.length === 0) {
      listHtml = `<div class="cfd-empty" style="padding: 12px 0"><div style="font-size:24px">🤝</div>Practice is fully optimized! No tag gaps found relative to <b>${shadowHandle}</b>.</div>`;
    } else {
      const rows = gapAnalysis.map(gap => `
        <tr>
          <td class="cfd-gap-td" style="font-weight:600">${gap.tag}</td>
          <td class="cfd-gap-td">${gap.level}</td>
          <td class="cfd-gap-td">${gap.userSolved}</td>
          <td class="cfd-gap-td">${gap.rivalSolved}</td>
          <td class="cfd-gap-td"><span class="cfd-gap-deficit-badge">-${gap.deficit}</span></td>
        </tr>
      `).join('');

      listHtml = `
        <table class="cfd-gap-table">
          <thead>
            <tr>
              <th class="cfd-gap-th">Topic Tag</th>
              <th class="cfd-gap-th">Rating</th>
              <th class="cfd-gap-th">You</th>
              <th class="cfd-gap-th">${shadowHandle}</th>
              <th class="cfd-gap-th">Deficit</th>
            </tr>
          </thead>
          <tbody>
            ${rows}
          </tbody>
        </table>`;
    }

    const wrap = document.createElement('div');
    wrap.innerHTML = makeCard(
      `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="1" y="1" width="6" height="6"/><rect x="9" y="1" width="6" height="6"/><rect x="1" y="9" width="6" height="6"/><rect x="9" y="9" width="6" height="6"/></svg>
       Shadow Mode Practice Gap Analysis`,
      listHtml
    );
    return wrap;
  }

  // ─── WIDGET 12 — Shadow Mode Comparison Inputs Settings ────────────────────
  function buildRivalSettingsWidget(shadowHandle, handle, root) {
    const shadowVal = shadowHandle || '';
    const btnText = shadowHandle ? 'Remove Comparison' : 'Compare Profile';
    
    const bodyHtml = `
      <div class="cfd-shadow-settings">
        <span style="font-size:11.5px; color:var(--cfd-text-muted); line-height:1.4">
          Overlay a peer or target tier's solved counts directly onto your efficiency bar chart to immediately identify practice deficits.
        </span>
        <div class="cfd-shadow-input-row" style="margin-top:6px">
          <input type="text" class="cfd-shadow-input" id="cfd-shadow-input-val" value="${shadowVal}" placeholder="Rival handle (e.g. tourist)" />
          <button class="cfd-shadow-btn" id="cfd-shadow-btn-save">${btnText}</button>
        </div>
      </div>`;

    const wrap = document.createElement('div');
    wrap.innerHTML = makeCard(
      `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14 14v-1a3 3 0 0 0-3-3H5a3 3 0 0 0-3 3v1"/><circle cx="8" cy="4" r="3"/></svg>
       Rival Benchmark Settings`,
      bodyHtml
    );

    wrap.querySelector('#cfd-shadow-btn-save').addEventListener('click', () => {
      const inputVal = wrap.querySelector('#cfd-shadow-input-val').value.trim();
      if (shadowHandle) {
        chrome.storage.local.remove('cfd_shadow_handle', () => {
          fetchAndRender(handle, root);
        });
      } else if (inputVal) {
        chrome.storage.local.set({ cfd_shadow_handle: inputVal }, () => {
          fetchAndRender(handle, root);
        });
      }
    });

    return wrap;
  }

  // ─── WIDGET 13 — Personalized Virtual Contest Matchmaker ──────────────────
  function buildVirtualMatchmaker(data, problemset) {
    const rating = data.userInfo?.rating || 1200;
    
    const participated = new Set();
    data.ratingHistory.forEach(r => participated.add(r.contestId));
    data.submissions.forEach(s => s.contestId && participated.add(s.contestId));

    const contestProbs = {};
    (problemset || []).forEach(p => {
      if (!p.contestId || !p.rating) return;
      if (!contestProbs[p.contestId]) contestProbs[p.contestId] = {};
      contestProbs[p.contestId][p.index] = p;
    });

    const candidates = [];
    Object.keys(contestProbs).forEach(cId => {
      const id = parseInt(cId, 10);
      if (participated.has(id)) return;

      const probs = contestProbs[cId];
      const probB = probs['B'];
      const probC = probs['C'];
      
      if (probB && probC && probB.rating && probC.rating) {
        const diffB = Math.abs(probB.rating - rating);
        const diffC = Math.abs(probC.rating - (rating + 200));
        if (diffB <= 100 && diffC <= 150) {
          candidates.push({
            contestId: id,
            bRating: probB.rating,
            cRating: probC.rating,
            score: diffB + diffC
          });
        }
      }
    });

    candidates.sort((a,b) => a.score - b.score);
    const match = candidates[0];

    let bodyHtml = '';
    if (match) {
      bodyHtml = `
        <div style="display:flex; flex-direction:column; gap:8px">
          <span style="font-size:12px; line-height:1.45; color:var(--cfd-text)">
            Mock Coach recommendation: We suggest simulating virtual contest round 
            <a href="https://codeforces.com/contest/${match.contestId}" target="_blank" style="font-weight:700; text-decoration:none" rel="noopener">Codeforces Round #${match.contestId}</a>.
            Its B and C problem difficulty slots perfectly line up with your target training thresholds:
          </span>
          <div style="display:flex; gap:12px; margin-top:4px">
            <div style="flex:1; background:var(--cfd-page-bg); padding:10px; border-radius:var(--cfd-radius)">
              <div style="font-size:10.5px; color:var(--cfd-text-muted)">Problem B target</div>
              <div style="font-size:15px; font-weight:700; color:${ratingColor(match.bRating)}">Rating ${match.bRating}</div>
            </div>
            <div style="flex:1; background:var(--cfd-page-bg); padding:10px; border-radius:var(--cfd-radius)">
              <div style="font-size:10.5px; color:var(--cfd-text-muted)">Problem C target</div>
              <div style="font-size:15px; font-weight:700; color:${ratingColor(match.cRating)}">Rating ${match.cRating}</div>
            </div>
            <div style="flex:1.5; background:rgba(var(--cfd-accent-rgb), 0.05); padding:10px; border-radius:var(--cfd-radius); border-left:3px solid var(--cfd-accent)">
              <div style="font-size:11px; font-weight:700; color:var(--cfd-text-header)">Target Growth Curve</div>
              <div style="font-size:10.5px; line-height:1.35; color:var(--cfd-text); margin-top:2px">Stretching your limits by +200 rating points is highly optimized for growth.</div>
            </div>
          </div>
        </div>`;
    } else {
      bodyHtml = `<div class="cfd-empty" style="padding: 10px 0"><div style="font-size:24px">🎯</div>Solve more problems to calibrate your training candidates!</div>`;
    }

    const wrap = document.createElement('div');
    wrap.innerHTML = makeCard(
      `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2" y="2" width="12" height="12" rx="2"/><circle cx="8" cy="8" r="3"/></svg>
       Personalized Virtual Contest Matchmaker`,
      bodyHtml
    );
    return wrap;
  }

  // ─── WIDGET 14 — Zen Practice & Anti-Spoil Intelligence Card ───────────────
  function buildZenIntelligenceCard(submissions, problemset) {
    let practiceLog = {};
    try {
      practiceLog = JSON.parse(localStorage.getItem('cfd-zen-practice-log') || '{}');
    } catch (e) {}

    // Track unique problems attempted
    const zenAttempted = new Set();
    const zenSolved = new Set();
    const normalAttempted = new Set();
    const normalSolved = new Set();

    submissions.forEach(s => {
      if (!s.problem || !s.problem.contestId || !s.problem.index) return;
      const rating = s.problem.rating || 0;
      if (rating < 1600) return; // Only track 1600+ rated problems

      const problemKey = `${s.problem.contestId}_${s.problem.index}`;
      const logEntry = practiceLog[problemKey];
      
      const isZen = logEntry && logEntry.zenActive;

      if (isZen) {
        zenAttempted.add(problemKey);
        if (s.verdict === 'OK') zenSolved.add(problemKey);
      } else {
        normalAttempted.add(problemKey);
        if (s.verdict === 'OK') normalSolved.add(problemKey);
      }
    });

    const zenAttemptsCount = zenAttempted.size;
    const zenSolvedCount = zenSolved.size;
    const normalAttemptsCount = normalAttempted.size;
    const normalSolvedCount = normalSolved.size;

    const zenRate = zenAttemptsCount > 0 ? (zenSolvedCount / zenAttemptsCount) * 100 : 0;
    const normalRate = normalAttemptsCount > 0 ? (normalSolvedCount / normalAttemptsCount) * 100 : 0;

    let insightText = '';
    
    if (zenAttemptsCount > 0 && normalAttempted.size > 0) {
      const diff = zenRate - normalRate;
      if (diff > 0) {
        insightText = `📊 <b>Cognitive Performance Spark:</b> In <b>Zen Mode</b>, your success rate on 1600+ rated problems increased by <b>${diff.toFixed(0)}%</b> (<b>${zenRate.toFixed(0)}%</b> vs <b>${normalRate.toFixed(0)}%</b>) because you tackled them rating-spoil-free!`;
      } else {
        insightText = `🧘 <b>Zen Practice Balance:</b> You have a <b>${zenRate.toFixed(0)}%</b> success rate on 1600+ problems in Zen Mode. Eliminating ratings helps build endurance and beats cognitive bias!`;
      }
    } else if (zenAttemptsCount > 0) {
      insightText = `🧘 <b>Zen Training Active:</b> You solved <b>${zenSolvedCount}/${zenAttemptsCount}</b> 1600+ problems (<b>${zenRate.toFixed(0)}%</b> success) under Zen Mode! Keep practicing to compare Zen vs. Normal mode stats.`;
    } else {
      insightText = `💡 <b>Psychological Edge Tip:</b> Entering <b>Zen Mode</b> masks problem tags and ratings across the site. This trains your brain to solve problems based on logic, not cognitive rating-bias!`;
    }

    // Read stopwatch history
    let stopwatchHistory = {};
    try {
      stopwatchHistory = JSON.parse(localStorage.getItem('cfd-stopwatch-history') || '{}');
    } catch(e) {}

    const stopwatchProblems = Object.keys(stopwatchHistory);
    let avgSolveTimeText = '';
    if (stopwatchProblems.length > 0) {
      let totalTimeMs = 0;
      stopwatchProblems.forEach(key => {
        totalTimeMs += stopwatchHistory[key].solveTimeMs || 0;
      });
      const avgMins = (totalTimeMs / stopwatchProblems.length) / 60000;
      avgSolveTimeText = `
        <div style="margin-top:10px; padding-top:10px; border-top:1px dashed var(--cfd-card-border); font-size:11px; color:var(--cfd-text-muted)">
          ⏱️ <b>Stopwatch Training Metric:</b> You solved <b>${stopwatchProblems.length}</b> problems using the Practice Stopwatch, averaging <b>${avgMins.toFixed(1)} minutes</b> per solve!
        </div>`;
    }

    const card = document.createElement('div');
    card.className = 'cfd-card cfd-animate cfd-zen-intel-card-wrapper';
    card.style.marginTop = '14px';
    card.innerHTML = `
      <div class="cfd-section-header">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:14px; height:14px"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
        <span>Zen Practice & Anti-Spoil Intelligence</span>
      </div>
      <div class="cfd-card-body">
        <div style="display:flex; gap:16px; align-items:stretch; flex-wrap:wrap">
          <div style="flex:1; min-width:240px; background:rgba(16, 185, 129, 0.04); border-left:4px solid var(--cfd-ok); padding:12px; border-radius:4px; font-size:12px; line-height:1.5; color:var(--cfd-text)">
            <div>${insightText}</div>
            ${avgSolveTimeText}
          </div>
          <div style="width:180px; border-left:1px dashed var(--cfd-card-border); padding-left:16px; display:flex; flex-direction:column; justify-content:center; gap:8px; font-size:11.5px; color:var(--cfd-text-muted)">
            <div>Zen Solves (1600+): <b>${zenSolvedCount}/${zenAttemptsCount}</b></div>
            <div style="background:var(--cfd-divider); height:4px; border-radius:2px; overflow:hidden">
              <div style="background:var(--cfd-ok); width:${zenRate}%; height:100%"></div>
            </div>
            <div>Normal Solves (1600+): <b>${normalSolvedCount}/${normalAttemptsCount}</b></div>
            <div style="background:var(--cfd-divider); height:4px; border-radius:2px; overflow:hidden">
              <div style="background:var(--cfd-tle); width:${normalRate}%; height:100%"></div>
            </div>
          </div>
        </div>
      </div>`;
    return card;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  SKELETON (Aligned to prevent shifts)
  // ═══════════════════════════════════════════════════════════════════════════
  function renderSkeleton(root) {
    root.classList.add('cfd-loading');
    root.innerHTML = `
      <div class="cfd-stat-strip">
        <div class="cfd-skeleton cfd-skeleton-h"></div>
        <div class="cfd-skeleton cfd-skeleton-h"></div>
        <div class="cfd-skeleton cfd-skeleton-h"></div>
        <div class="cfd-skeleton cfd-skeleton-h"></div>
      </div>
      <div class="cfd-skeleton cfd-skeleton-m" style="margin-top:14px"></div>
      <div class="cfd-skeleton cfd-skeleton-l" style="margin-top:14px"></div>
      <div class="cfd-skeleton cfd-skeleton-m" style="margin-top:14px"></div>
      <div class="cfd-skeleton cfd-skeleton-m" style="margin-top:14px"></div>
      <div class="cfd-two-col" style="margin-top:14px">
        <div class="cfd-skeleton cfd-skeleton-m"></div>
        <div class="cfd-skeleton cfd-skeleton-m"></div>
      </div>`;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  FULL PROFILE DASHBOARD RENDER
  // ═══════════════════════════════════════════════════════════════════════════
  function renderDashboard(root, handle, submissions, userInfo, ratingHistory, problemset, workerResult = null, shadowHandle = null, fallbackUsed = false, circuitBreaker = false) {
    currentSubmissions = submissions;
    currentProblemset = problemset;
    root.classList.remove('cfd-loading');
    applyTheme();

    const data = processData(submissions, userInfo, ratingHistory, payloadRivalCache);

    // Override statistics with official scraped profile counts if higher
    try {
      const officialSolved = parseProfileSolvedCount();
      if (officialSolved !== null && officialSolved > data.uniqueSolved) {
        data.uniqueSolved = officialSolved;
      }
      const officialStreaks = parseProfileStreaks();
      if (officialStreaks.currentStreak !== null) {
        data.heatmapStats.currentStreak = officialStreaks.currentStreak;
      }
      if (officialStreaks.maxStreak !== null && officialStreaks.maxStreak > data.heatmapStats.maxStreak) {
        data.heatmapStats.maxStreak = officialStreaks.maxStreak;
      }
    } catch (e) {
      console.warn('[CF Dashboard] Failed overriding data with official stats:', e);
    }

    let alertBadgeHtml = '';
    if (circuitBreaker) {
      alertBadgeHtml = `<span class="cfd-alert-badge cfd-breaker" title="Breaker Active: Codeforces API offline. Serving cache.">⚠️ Outage Safe-Mode</span>`;
    } else if (fallbackUsed) {
      alertBadgeHtml = `<span class="cfd-alert-badge cfd-cached" title="Using local cached submissions tail.">🕒 Cached Safe-Mode</span>`;
    }

    const isZen = localStorage.getItem('cfd-zen-mode') === 'true';
    const checkedAttr = isZen ? 'checked' : '';
    const switchBg = isZen ? 'var(--cfd-accent)' : '#ccc';
    const knobLeft = isZen ? '16px' : '2px';

    const topBar = document.createElement('div');
    topBar.style.cssText = 'display:flex;align-items:center;gap:10px;margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid var(--cfd-divider)';
    topBar.innerHTML = `
      <span style="font-weight:700;font-size:14px;color:var(--cfd-text)">Dashboard</span>
      <span style="font-size:12px;color:var(--cfd-text-muted)">for</span>
      <a href="https://codeforces.com/profile/${handle}" style="font-weight:700;color:${ratingColor(userInfo?.rating)};font-size:13px;text-decoration:none">${handle}</a>
      <span style="font-size:11px;padding:2px 8px;background:${ratingColor(userInfo?.rating)}1a;color:${ratingColor(userInfo?.rating)};border-radius:3px;font-weight:600">${ratingLabel(userInfo?.rating)}</span>
      ${alertBadgeHtml}
      
      <label style="margin-left:auto; display:flex; align-items:center; gap:6px; cursor:pointer; font-size:11px; font-weight:600; color:var(--cfd-text-muted); user-select:none" title="Hide ratings/tags to eliminate bias during training">
        <input type="checkbox" id="cfd-zen-toggle" ${checkedAttr} style="display:none">
        <span class="cfd-zen-switch" style="width:30px; height:16px; background:${switchBg}; border-radius:8px; display:inline-block; position:relative; transition:background 0.2s">
          <span class="cfd-zen-knob" style="width:12px; height:12px; background:#fff; border-radius:6px; position:absolute; top:2px; left:${knobLeft}; transition:left 0.2s"></span>
        </span>
        Enter Zen Mode
      </label>

      <button class="cfd-refresh-btn" id="cfd-refresh-btn" style="margin-left:14px" title="Clear cache and re-fetch">↻ Refresh</button>`;

    root.innerHTML = '';
    root.appendChild(topBar);

    // Bind Zen Toggle Listener
    const zenToggle = topBar.querySelector('#cfd-zen-toggle');
    if (zenToggle) {
      zenToggle.addEventListener('change', () => {
        const checked = zenToggle.checked;
        localStorage.setItem('cfd-zen-mode', checked ? 'true' : 'false');
        
        const zenSwitch = topBar.querySelector('.cfd-zen-switch');
        const zenKnob = topBar.querySelector('.cfd-zen-knob');
        if (zenSwitch && zenKnob) {
          zenSwitch.style.background = checked ? 'var(--cfd-accent)' : '#ccc';
          zenKnob.style.left = checked ? '16px' : '2px';
        }
        
        // Apply site-wide
        applyZenModeDOMChanges();

        // Sync with extension settings and broadcast
        currentSettings.zenEnabled = checked;
        chrome.storage.local.set({ zenEnabled: checked }, () => {
          chrome.runtime.sendMessage({
            type: 'CF_SYNC_STATE',
            payload: {
              action: 'SETTINGS_SYNC',
              settings: currentSettings
            }
          }).catch(() => {});
        });
        
        // Refresh Zen intel card dynamically
        const existingZenCard = root.querySelector('.cfd-zen-intel-card-wrapper');
        if (existingZenCard) {
          const newZenCard = buildZenIntelligenceCard(submissions, problemset);
          existingZenCard.replaceWith(newZenCard);
        }
      });
    }

    const statDiv = document.createElement('div');
    statDiv.innerHTML = buildStatStrip(data);
    root.appendChild(statDiv);

    const effWrap = buildEfficiency(data);
    effWrap.className = 'cfd-animate cfd-delay-3';
    effWrap.style.marginTop = '14px';
    root.appendChild(effWrap);

    const velWrap = buildVelocityScatterPlot(workerResult);
    velWrap.className = 'cfd-animate cfd-delay-4';
    velWrap.style.marginTop = '14px';
    root.appendChild(velWrap);

    const zenIntelWrap = buildZenIntelligenceCard(submissions, problemset);
    zenIntelWrap.className = 'cfd-card cfd-animate cfd-delay-4 cfd-zen-intel-card-wrapper';
    zenIntelWrap.style.marginTop = '14px';
    root.appendChild(zenIntelWrap);

    const recWrap = buildRecommender(data, problemset);
    recWrap.className = 'cfd-animate cfd-delay-5';
    recWrap.style.marginTop = '14px';
    root.appendChild(recWrap);

    const matchmakerWrap = buildVirtualMatchmaker(data, problemset);
    matchmakerWrap.className = 'cfd-animate cfd-delay-5';
    matchmakerWrap.style.marginTop = '14px';
    root.appendChild(matchmakerWrap);

    const coachWrap = buildMockCoachWidget(workerResult);
    coachWrap.className = 'cfd-animate cfd-delay-5';
    coachWrap.style.marginTop = '14px';
    root.appendChild(coachWrap);

    const diagWrap = buildSystemDiagnosticWidget(workerResult?.diagnostics);
    if (diagWrap) {
      root.appendChild(diagWrap);
    }

    const hmWrap = buildHeatmap(data);
    hmWrap.className = 'cfd-animate cfd-delay-6';
    hmWrap.style.marginTop = '14px';
    root.appendChild(hmWrap);

    const ctWrap = buildContestChart(data);
    ctWrap.className = 'cfd-animate cfd-delay-7';
    ctWrap.style.marginTop = '14px';
    root.appendChild(ctWrap);

    const row5 = document.createElement('div');
    row5.className = 'cfd-two-col';
    row5.style.marginTop = '14px';
    const tagWrap = buildTagPower(data);
    tagWrap.className = 'cfd-animate cfd-delay-8';
    const upWrap = buildUpsolving(data);
    upWrap.className = 'cfd-animate cfd-delay-8';
    row5.appendChild(tagWrap);
    row5.appendChild(upWrap);
    root.appendChild(row5);

    const row6 = document.createElement('div');
    row6.className = 'cfd-two-col';
    row6.style.marginTop = '14px';
    const gapWrap = buildPracticeGapWidget(workerResult?.gapAnalysis, shadowHandle);
    gapWrap.className = 'cfd-animate cfd-delay-8';
    const settingsWrap = buildRivalSettingsWidget(shadowHandle, handle, root);
    settingsWrap.className = 'cfd-animate cfd-delay-8';
    row6.appendChild(gapWrap);
    row6.appendChild(settingsWrap);
    root.appendChild(row6);

    root.querySelector('#cfd-refresh-btn').addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'CF_CLEAR_CACHE', handle }, () => {
        fetchAndRender(handle, root);
      });
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  DATA FETCH + LAZY MULTI-PASS COMPILING
  // ═══════════════════════════════════════════════════════════════════════════
  let payloadRivalCache = null;

  function fetchAndRender(handle, root) {
    renderSkeleton(root);

    chrome.runtime.sendMessage({ type: 'CF_FETCH_PROFILE', handle }, async response => {
      if (!response || !response.ok) {
        root.classList.remove('cfd-loading');
        root.innerHTML = `
          <div class="cfd-error-banner">
            ⚠️ Failed to load data for <b>${handle}</b>: ${response?.error || 'Unknown error'}.
            Check your connection or try refreshing.
          </div>
          <button class="cfd-refresh-btn" id="cfd-retry" style="margin-top:6px">↻ Retry</button>`;
        root.querySelector('#cfd-retry')?.addEventListener('click', () => fetchAndRender(handle, root));
        return;
      }

      const shadowHandle = await new Promise(r => chrome.storage.local.get('cfd_shadow_handle', data => r(data.cfd_shadow_handle)));
      payloadRivalCache = null;

      if (shadowHandle) {
        const rRes = await new Promise(r => chrome.runtime.sendMessage({ type: 'CF_FETCH_PROFILE', handle: shadowHandle }, r));
        if (rRes && rRes.ok) {
          payloadRivalCache = rRes.submissions || [];
        }
      }

      const payload = {
        submissions: response.submissions || [],
        ratingHistory: response.ratingHistory || [],
        contestMap: response.contestMap || {},
        rivalSubmissions: payloadRivalCache,
        userRating: response.userInfo?.rating || 1200
      };

      try {
        const workerResult = await crunchAnalyticsAsync(payload);
        renderDashboard(
          root,
          handle,
          response.submissions || [],
          response.userInfo,
          response.ratingHistory || [],
          response.problemset   || [],
          workerResult,
          shadowHandle,
          response.fallbackUsed,
          response.circuitBreaker
        );
      } catch (err) {
        console.error('[CF Dashboard] Worker analytics extraction failed:', err);
        renderDashboard(
          root,
          handle,
          response.submissions || [],
          response.userInfo,
          response.ratingHistory || [],
          response.problemset   || []
        );
      }
    });
  }

  // ─── Listen for background lazy synced tail complete and re-render ────────
  chrome.runtime.onMessage.addListener(async (message) => {
    if (message.type === 'CF_LAZY_SYNC_COMPLETE') {
      const handle = getHandle();
      if (message.handle.toLowerCase() === handle?.toLowerCase() && loaded && dashRoot) {
        chrome.storage.local.get([`cf_info_${handle.toLowerCase()}`, `cf_rating_${handle.toLowerCase()}`, `cf_problemset`], async cache => {
          const userInfo = cache[`cf_info_${handle.toLowerCase()}`]?.data;
          const ratingHistory = cache[`cf_rating_${handle.toLowerCase()}`]?.data;
          const problemset = cache[`cf_problemset`]?.problems || [];
          
          const contestCache = await new Promise(resolve => chrome.storage.local.get('cf_contests', data => resolve(data.cf_contests)));
          const contestMap = contestCache?.contestMap || {};

          const shadowHandle = await new Promise(r => chrome.storage.local.get('cfd_shadow_handle', data => r(data.cfd_shadow_handle)));
          payloadRivalCache = null;

          if (shadowHandle) {
            const rivalCache = await new Promise(r => chrome.storage.local.get(`cf_subs_${shadowHandle.toLowerCase()}`, data => r(data[`cf_subs_${shadowHandle.toLowerCase()}`])));
            if (rivalCache) payloadRivalCache = rivalCache.submissions;
          }

          const payload = {
            submissions: message.submissions,
            ratingHistory,
            contestMap,
            rivalSubmissions: payloadRivalCache,
            userRating: userInfo?.rating || 1200
          };

          try {
            const workerResult = await crunchAnalyticsAsync(payload);
            renderDashboard(
              dashRoot,
              handle,
              message.submissions,
              userInfo,
              ratingHistory,
              problemset,
              workerResult,
              shadowHandle
            );
          } catch (e) {
            console.error('Lazy synced analytics failed:', e);
          }
        });
      }
    }
  });

  let tabObserver = null;

  function injectDashboardTab() {
    const ul = document.querySelector('.second-level-menu ul') ||
               document.querySelector('.tabs-box ul');
    if (!ul) return;

    let a = ul.querySelector('.cf-dashboard-tab');
    let li = a ? a.closest('li') : null;

    if (!li) {
      li = document.createElement('li');
      li.className = 'cf-dashboard-tab-li';
      a  = document.createElement('a');
      a.href = '#dashboard';
      a.className   = 'second-level-menu-tab-link cf-dashboard-tab';
      a.textContent = 'Dashboard';
      li.appendChild(a);
    }

    const nativeChildren = Array.from(ul.children).filter(el => {
      if (el === li) return false;
      if (el.tagName !== 'LI') return false;
      if (el.style.display === 'none') return false;
      if (!el.textContent.trim()) return false;
      return true;
    });

    if (nativeChildren.length > 0) {
      const firstNative = nativeChildren[0];
      if (firstNative.nextElementSibling !== li) {
        ul.insertBefore(li, firstNative.nextElementSibling);
      }
    } else {
      if (ul.firstElementChild !== li) {
        ul.appendChild(li);
      }
    }
  }

  function syncTabStates() {
    const ul = document.querySelector('.second-level-menu ul') ||
               document.querySelector('.tabs-box ul');
    if (!ul) return;

    const isDashboardActive = window.location.hash === '#dashboard';
    
    if (isDashboardActive) {
      ul.querySelectorAll('a').forEach(a => {
        if (a.classList.contains('cf-dashboard-tab')) {
          a.classList.add('cfd-tab-active', 'active', 'current');
          if (a.parentElement) a.parentElement.classList.add('active', 'current');
        } else {
          const parent = a.parentElement;
          const isSelfActive = a.classList.contains('active') || a.classList.contains('current');
          const isParentActive = parent && (parent.classList.contains('active') || parent.classList.contains('current'));
          
          if (isSelfActive || isParentActive) {
            if (isSelfActive) {
              a.setAttribute('data-cfd-was-active-self', 'true');
              if (a.classList.contains('active')) a.setAttribute('data-cfd-had-active-class', 'true');
              if (a.classList.contains('current')) a.setAttribute('data-cfd-had-current-class', 'true');
            }
            if (isParentActive) {
              a.setAttribute('data-cfd-was-active-parent', 'true');
              if (parent.classList.contains('active')) a.setAttribute('data-cfd-parent-had-active-class', 'true');
              if (parent.classList.contains('current')) a.setAttribute('data-cfd-parent-had-current-class', 'true');
            }
            a.classList.remove('active', 'current');
            if (parent) parent.classList.remove('active', 'current');
          }
        }
      });
    } else {
      const ourTab = ul.querySelector('.cf-dashboard-tab');
      if (ourTab) {
        ourTab.classList.remove('cfd-tab-active', 'active', 'current');
        if (ourTab.parentElement) ourTab.parentElement.classList.remove('active', 'current');
      }
    }
  }

  function observeMenu() {
    const menuContainer = document.querySelector('.second-level-menu') ||
                          document.querySelector('.tabs-box');
    if (!menuContainer) return;

    if (tabObserver) return;

    tabObserver = new MutationObserver(() => {
      tabObserver.disconnect();
      try {
        injectDashboardTab();
        syncTabStates();
      } catch (e) {
        console.warn('[CF Dashboard] tabObserver mutation handling error:', e);
      } finally {
        tabObserver.observe(menuContainer, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
      }
    });

    tabObserver.observe(menuContainer, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
  }

  let dashRoot  = null;
  let loaded    = false;

  function showDashboard(handle) {
    try {
      if (!dashRoot) {
        dashRoot = document.createElement('div');
        dashRoot.id = 'cf-dashboard-root';

        const pageContent = document.querySelector('#pageContent');
        const menu = pageContent ? pageContent.querySelector('.second-level-menu') : null;
        if (menu) {
          menu.insertAdjacentElement('afterend', dashRoot);
        } else if (pageContent) {
          pageContent.appendChild(dashRoot);
        } else {
          const tabBar = document.querySelector('.second-level-menu');
          if (tabBar) tabBar.insertAdjacentElement('afterend', dashRoot);
          else document.body.appendChild(dashRoot);
        }
      }

      dashRoot.style.display = '';

      const pageContent = document.querySelector('#pageContent');
      if (pageContent) {
        pageContent.classList.add('cfd-show-dashboard');
      }

      syncTabStates();

      if (!loaded) {
        loaded = true;
        fetchAndRender(handle, dashRoot);
      }
    } catch (e) {
      console.warn('[CF Dashboard] showDashboard error:', e);
    }
  }

  function hideDashboard() {
    try {
      if (dashRoot) dashRoot.style.display = 'none';

      const pageContent = document.querySelector('#pageContent');
      if (pageContent) {
        pageContent.classList.remove('cfd-show-dashboard');
      }

      // Restore original active state
      document.querySelectorAll('.second-level-menu a, .tabs-box a').forEach(a => {
        a.classList.remove('cfd-tab-active');
        a.classList.remove('active', 'current');
        if (a.parentElement) a.parentElement.classList.remove('active', 'current');
        
        if (a.getAttribute('data-cfd-was-active-self') === 'true') {
          if (a.getAttribute('data-cfd-had-active-class') === 'true') a.classList.add('active');
          if (a.getAttribute('data-cfd-had-current-class') === 'true') a.classList.add('current');
          a.removeAttribute('data-cfd-was-active-self');
          a.removeAttribute('data-cfd-had-active-class');
          a.removeAttribute('data-cfd-had-current-class');
        }
        if (a.getAttribute('data-cfd-was-active-parent') === 'true') {
          if (a.parentElement) {
            if (a.getAttribute('data-cfd-parent-had-active-class') === 'true') a.parentElement.classList.add('active');
            if (a.getAttribute('data-cfd-parent-had-current-class') === 'true') a.parentElement.classList.add('current');
          }
          a.removeAttribute('data-cfd-was-active-parent');
          a.removeAttribute('data-cfd-parent-had-active-class');
          a.removeAttribute('data-cfd-parent-had-current-class');
        }
      });
    } catch (e) {
      console.warn('[CF Dashboard] hideDashboard error:', e);
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  LIVE CONTEST MODE BOOTSTRAP (Live Contest Strategy Optimizer)
  // ═══════════════════════════════════════════════════════════════════════════
  // Helper to inject sideboxes in the correct layout order
  function injectSidebox(box, type) {
    const sidebar = $('#sidebar');
    if (!sidebar) return;
    
    // Remove existing element to avoid duplicates
    const existing = sidebar.querySelector(`.cfd-${type}-sidebox`);
    if (existing) existing.remove();

    const firstChild = sidebar.firstElementChild;
    
    if (type === 'stopwatch') {
      if (firstChild) {
        firstChild.insertAdjacentElement('afterend', box);
      } else {
        sidebar.insertAdjacentElement('afterbegin', box);
      }
    } else if (type === 'friends') {
      const stopwatchBox = sidebar.querySelector('.cfd-stopwatch-sidebox');
      if (stopwatchBox) {
        stopwatchBox.insertAdjacentElement('afterend', box);
      } else if (firstChild) {
        firstChild.insertAdjacentElement('afterend', box);
      } else {
        sidebar.insertAdjacentElement('afterbegin', box);
      }
    } else if (type === 'live') {
      const friendsBox = sidebar.querySelector('.cfd-friends-sidebox');
      const stopwatchBox = sidebar.querySelector('.cfd-stopwatch-sidebox');
      if (friendsBox) {
        friendsBox.insertAdjacentElement('afterend', box);
      } else if (stopwatchBox) {
        stopwatchBox.insertAdjacentElement('afterend', box);
      } else if (firstChild) {
        firstChild.insertAdjacentElement('afterend', box);
      } else {
        sidebar.insertAdjacentElement('afterbegin', box);
      }
    }
  }

  function setupLiveContestStrategy(contestId, enabled) {
    if (!enabled) {
      if (liveStrategyIntervalId) {
        clearInterval(liveStrategyIntervalId);
        liveStrategyIntervalId = null;
      }
      const existing = document.querySelector('.cfd-live-sidebox');
      if (existing) existing.remove();
      return;
    }

    if (document.querySelector('.cfd-live-sidebox')) {
      return;
    }

    const sidebar = $('#sidebar');
    if (!sidebar) return;

    const sidebox = document.createElement('div');
    sidebox.className = 'roundbox sidebox cfd-live-sidebox cfd-animate';
    sidebox.style.marginTop = '15px';
    sidebox.style.overflow = 'hidden';
    
    // Create header element
    const header = document.createElement('div');
    header.className = 'caption titled';
    header.style.borderBottom = '1px solid var(--cfd-card-border)';
    header.style.paddingBottom = '4px';
    header.style.cursor = 'pointer';
    header.style.display = 'flex';
    header.style.justifyContent = 'space-between';
    header.style.alignItems = 'center';
    header.style.userSelect = 'none';
    
    const titleSpan = document.createElement('span');
    titleSpan.innerText = '→ Live Strategy Optimizer';
    
    const toggleSpan = document.createElement('span');
    toggleSpan.className = 'cfd-toggle-btn';
    toggleSpan.style.display = 'inline-block';
    toggleSpan.style.width = '6px';
    toggleSpan.style.height = '6px';
    toggleSpan.style.borderRight = '1.5px solid var(--cfd-text-muted)';
    toggleSpan.style.borderBottom = '1.5px solid var(--cfd-text-muted)';
    toggleSpan.style.marginRight = '6px';
    toggleSpan.style.cursor = 'pointer';
    toggleSpan.style.transition = 'transform 0.2s ease, border-color 0.2s';
    
    header.appendChild(titleSpan);
    header.appendChild(toggleSpan);
    sidebox.appendChild(header);
    
    // Create body element
    const body = document.createElement('div');
    body.className = 'body';
    body.style.padding = '10px';
    sidebox.appendChild(body);

    // Read initial collapse state from localStorage
    let isCollapsed = localStorage.getItem('cfd-live-collapsed') === 'true';
    
    function applyCollapseState() {
      if (isCollapsed) {
        body.style.display = 'none';
        header.style.borderBottom = 'none';
        header.style.borderBottomLeftRadius = '4px';
        header.style.borderBottomRightRadius = '4px';
        toggleSpan.style.transform = 'rotate(-45deg)';
        toggleSpan.style.borderColor = 'var(--cfd-text-muted)';
      } else {
        body.style.display = 'block';
        header.style.borderBottom = '1px solid var(--cfd-card-border)';
        header.style.borderBottomLeftRadius = '0';
        header.style.borderBottomRightRadius = '0';
        toggleSpan.style.transform = 'rotate(45deg)';
        toggleSpan.style.borderColor = 'var(--cfd-accent)';
      }
    }
    
    // Initial apply
    applyCollapseState();
    
    // Header click handler
    header.addEventListener('click', () => {
      isCollapsed = !isCollapsed;
      localStorage.setItem('cfd-live-collapsed', isCollapsed ? 'true' : 'false');
      applyCollapseState();
    });

    injectSidebox(sidebox, 'live');

    function updateVelocity() {
      if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.id) {
        if (liveStrategyIntervalId) clearInterval(liveStrategyIntervalId);
        return;
      }

      try {
        chrome.runtime.sendMessage({ type: 'CF_FETCH_LIVE_CONTEST', contestId }, response => {
          if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.id || chrome.runtime.lastError) {
            console.warn('[CF Dashboard] Extension context invalidated during live update. Clearing interval.');
            if (liveStrategyIntervalId) clearInterval(liveStrategyIntervalId);
            return;
          }

          if (!response || !response.ok || !response.submissions || response.submissions.length === 0) {
            body.innerHTML = `
              <div style="padding:12px; font-size:11px; color:var(--cfd-text-muted)">
                Calculating live global solves speed and strategy recommendations...
              </div>`;
            return;
          }

          const subs = response.submissions;
          const solves = {};
          const totalAttempts = {};
          
          subs.forEach(s => {
            if (!s.problem || !s.problem.index) return;
            const idx = s.problem.index.charAt(0);
            if (!solves[idx]) solves[idx] = 0;
            if (!totalAttempts[idx]) totalAttempts[idx] = 0;
            
            totalAttempts[idx]++;
            if (s.verdict === 'OK') solves[idx]++;
          });

          const times = subs.map(s => s.creationTimeSeconds).sort((a,b) => a-b);
          const oldest = times[0];
          const latest = times[times.length - 1];
          const spanMins = Math.max((latest - oldest) / 60, 1.0);

          const problems = ['A', 'B', 'C', 'D'];
          const velocities = {};
          
          problems.forEach(p => {
            const sCount = solves[p] || 0;
            velocities[p] = sCount / spanMins;
          });

          let adviceHtml = '';
          if (velocities['C'] > velocities['B'] * 1.5 && velocities['C'] > 0.5) {
            adviceHtml = `
              <div class="cfd-coach-issue" style="margin-top:12px; background:rgba(0, 120, 193, 0.05); padding:8px; border-left:3px solid var(--cfd-accent); border-radius:3px; font-size:11px; line-height:1.4">
                <span style="font-size:14px; flex-shrink:0">⚠️</span>
                <div>
                  <b>Mock Coach Pivot Alert:</b> Problem <b>C</b> solve rate (<b>${velocities['C'].toFixed(1)}/m</b>) is 1.5x faster than Problem <b>B</b> (<b>${velocities['B'].toFixed(1)}/m</b>) globally. Consider reading C now!
                </div>
              </div>`;
          } else if (velocities['D'] > velocities['C'] * 1.5 && velocities['D'] > 0.3) {
            adviceHtml = `
              <div class="cfd-coach-issue" style="margin-top:12px; background:rgba(0, 120, 193, 0.05); padding:8px; border-left:3px solid var(--cfd-accent); border-radius:3px; font-size:11px; line-height:1.4">
                <span style="font-size:14px; flex-shrink:0">⚠️</span>
                <div>
                  <b>Mock Coach Pivot Alert:</b> Problem <b>D</b> solve velocity (<b>${velocities['D'].toFixed(1)}/m</b>) is outstripping Problem <b>C</b> globally. Check D early!
                </div>
              </div>`;
          } else {
            adviceHtml = `
              <div style="margin-top:10px; font-size:10.5px; color:var(--cfd-text-muted); text-align:center">
                Solve velocities are stable. Maintain your current round checklist!
              </div>`;
          }

          const maxVel = Math.max(...problems.map(p => velocities[p]), 1.0);
          const gaugesHtml = problems.map(p => {
            const vel = velocities[p] || 0;
            const ratio = Math.min((vel / maxVel) * 100, 100);
            const solvedCount = solves[p] || 0;
            return `
              <div style="margin-bottom:8px">
                <div style="display:flex; justify-content:space-between; font-size:11px; margin-bottom:2px">
                  <b>Problem ${p}</b>
                  <span style="color:var(--cfd-text-muted)">${vel.toFixed(1)} solves/min (${solvedCount} AC)</span>
                </div>
                <div style="background:var(--cfd-divider); height:6px; border-radius:3px; overflow:hidden">
                  <div style="background:var(--cfd-bar-solved); width:${ratio}%; height:100%; border-radius:3px; transition:width 0.5s"></div>
                </div>
              </div>`;
          }).join('');

          body.innerHTML = `
            ${gaugesHtml}
            ${adviceHtml}
            <div style="font-size:9.5px; color:var(--cfd-text-muted); text-align:right; margin-top:8px">
              Auto-updating · Last 500 status logs
            </div>`;
        });
      } catch (e) {
        console.warn('[CF Dashboard] Extension context invalidated during transmission. Clearing interval.', e);
        if (liveStrategyIntervalId) clearInterval(liveStrategyIntervalId);
      }
    }

    updateVelocity();
    liveStrategyIntervalId = setInterval(updateVelocity, 45 * 1000);
    window.addEventListener('pagehide', () => { if (liveStrategyIntervalId) clearInterval(liveStrategyIntervalId); });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  PROBLEM PAGE FEATURES (Inline Stopwatch & Friends Solutions Drawer)
  // ═══════════════════════════════════════════════════════════════════════════
  function getLoggedInUser() {
    const profileLink = document.querySelector('.header-bell + a, a[href^="/profile/"]');
    if (profileLink) {
      const href = profileLink.getAttribute('href');
      const m = href.match(/\/profile\/([^/]+)/);
      return m ? m[1] : null;
    }
    return null;
  }

  function showCodeOverlay(friend, code, language) {
    const existing = document.querySelector('.cfd-code-overlay');
    if (existing) existing.remove();

    const overlay = document.createElement('div');
    overlay.className = 'cfd-code-overlay cfd-animate';
    overlay.style.cssText = 'position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.65); z-index:999999; display:flex; justify-content:center; align-items:center; backdrop-filter:blur(4px); font-family:var(--cfd-font)';
    
    const escapedCode = code
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");

    const lines = escapedCode.split('\n');
    const numberedCode = lines.map((line, idx) => {
      return `<div style="display:flex; line-height:1.5"><span style="width:35px; text-align:right; color:var(--cfd-text-muted); margin-right:12px; user-select:none; font-family:monospace">${idx + 1}</span><span style="font-family:monospace; white-space:pre-wrap; word-break:break-all">${line || ' '}</span></div>`;
    }).join('');

    overlay.innerHTML = `
      <div class="cfd-card" style="width:85%; max-width:900px; height:85%; display:flex; flex-direction:column; padding:20px; position:relative; animation:cfd-fade-up 0.28s ease">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; border-bottom:1px solid var(--cfd-divider); padding-bottom:8px">
          <div>
            <h3 style="margin:0; font-size:14px; color:var(--cfd-text)">🧑‍💻 ${friend}'s Solution</h3>
            <span style="font-size:11px; color:var(--cfd-text-muted)">Language: ${language}</span>
          </div>
          <div style="display:flex; gap:10px">
            <button class="cfd-btn cfd-copy-code" style="padding:4px 12px; font-size:11px; cursor:pointer">Copy Code</button>
            <button class="cfd-btn cfd-close-code" style="padding:4px 12px; font-size:11px; background:var(--cfd-tle); cursor:pointer">Close</button>
          </div>
        </div>
        <div style="flex:1; overflow-y:auto; background:var(--cfd-card-bg); border:1px solid var(--cfd-card-border); border-radius:4px; padding:12px; font-size:12px; line-height:1.5; color:var(--cfd-text)">
          <pre style="margin:0; font-family:monospace">${numberedCode}</pre>
        </div>
      </div>`;

    document.body.appendChild(overlay);
    document.body.style.overflow = 'hidden';

    const close = () => {
      overlay.remove();
      document.body.style.overflow = '';
    };

    overlay.querySelector('.cfd-close-code').addEventListener('click', close);
    overlay.addEventListener('click', e => {
      if (e.target === overlay) close();
    });

    overlay.querySelector('.cfd-copy-code').addEventListener('click', () => {
      navigator.clipboard.writeText(code).then(() => {
        const btn = overlay.querySelector('.cfd-copy-code');
        btn.textContent = 'Copied!';
        setTimeout(() => btn.textContent = 'Copy Code', 2000);
      });
    });
  }

  function handleFetchCodeTab() {
    const checkElement = () => {
      const codeElement = document.querySelector('#program-source-text, pre.program-source, pre.program-source-text, pre.prettyprint');
      const bodyText = document.body ? document.body.textContent : '';
      const hasLoginForm = !!document.querySelector('form[action*="/enter"], form[action*="/login"]');
      const currentUrl = window.location.href;
      
      if (codeElement) {
        const rawCode = codeElement.textContent;
        let language = 'Code';
        const cellThs = [...document.querySelectorAll('th, td')];
        for (let i = 0; i < cellThs.length; i++) {
          if (cellThs[i].textContent.includes('Language') && cellThs[i+1]) {
            language = cellThs[i+1].textContent.trim();
            break;
          }
        }
        chrome.runtime.sendMessage({
          type: 'CF_SUBMISSION_CODE_LOADED',
          url: currentUrl,
          rawCode,
          language
        });
        return true;
      }
      
      if (currentUrl.includes('/problem/') || !currentUrl.includes('/submission/')) {
        chrome.runtime.sendMessage({
          type: 'CF_SUBMISSION_CODE_LOADED',
          url: currentUrl,
          error: 'CODEFORCES_ACCESS_DENIED'
        });
        return true;
      }
      if (hasLoginForm || bodyText.includes('Login to Codeforces') || bodyText.includes('enter your handle') || bodyText.includes('authorized')) {
        chrome.runtime.sendMessage({
          type: 'CF_SUBMISSION_CODE_LOADED',
          url: currentUrl,
          error: 'NOT_LOGGED_IN'
        });
        return true;
      }
      if (bodyText.includes('You are not allowed to view this submission') || 
          bodyText.includes('solved the problem') || 
          bodyText.includes('allowed to view') || 
          bodyText.includes('trusted participant') ||
          bodyText.includes('not allowed')) {
        chrome.runtime.sendMessage({
          type: 'CF_SUBMISSION_CODE_LOADED',
          url: currentUrl,
          error: 'CODEFORCES_ACCESS_DENIED'
        });
        return true;
      }
      
      return false;
    };
    
    // Poll up to 10 seconds (20 checks * 500ms)
    let checks = 0;
    const interval = setInterval(() => {
      checks++;
      const done = checkElement();
      if (done || checks >= 20) {
        clearInterval(interval);
        if (!done) {
          chrome.runtime.sendMessage({
            type: 'CF_SUBMISSION_CODE_LOADED',
            url: window.location.href,
            error: 'TIMEOUT'
          });
        }
      }
    }, 500);
  }

  function viewFriendCode(contestId, submissionId, friend) {
    const overlay = document.createElement('div');
    overlay.className = 'cfd-fetching-overlay';
    overlay.style.cssText = 'position:fixed; top:10px; right:10px; background:rgba(0,0,0,0.8); color:#fff; padding:8px 12px; border-radius:4px; font-size:11px; z-index:9999999';
    overlay.textContent = 'Fetching solution...';
    document.body.appendChild(overlay);

    const origin = window.location.origin;
    const currentPath = window.location.pathname;
    let submissionUrl = '';
    
    if (currentPath.includes('/group/')) {
      const groupMatch = currentPath.match(/\/group\/([^\/]+)/);
      const groupId = groupMatch ? groupMatch[1] : '';
      submissionUrl = `${origin}/group/${groupId}/contest/${contestId}/submission/${submissionId}`;
    } else if (currentPath.includes('/gym/')) {
      submissionUrl = `${origin}/gym/${contestId}/submission/${submissionId}`;
    } else {
      submissionUrl = `${origin}/contest/${contestId}/submission/${submissionId}`;
    }

    function handleTabFallback() {
      overlay.textContent = 'Fetching solution (resolving browser challenge)...';
      chrome.runtime.sendMessage({
        type: 'CF_OPEN_CODE_TAB',
        url: submissionUrl + '#cfd-fetch-code',
        friend
      });
    }

    fetch(submissionUrl)
      .then(res => {
        const wasRedirectedToProblem = res.redirected && (res.url.includes('/problem/') || !res.url.includes('/submission/'));
        return res.text().then(html => ({ html, wasRedirectedToProblem, resUrl: res.url }));
      })
      .then(({ html, wasRedirectedToProblem, resUrl }) => {
        if (wasRedirectedToProblem) {
          overlay.remove();
          console.warn('[CF Dashboard] viewFriendCode redirected to problem page. Access Denied:', resUrl);
          alert('Could not retrieve code. Codeforces does not allow viewing other users\' submissions for this problem until you have solved it yourself or the contest has ended.');
          return;
        }

        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        const codeElement = doc.querySelector('#program-source-text, pre.program-source, pre.program-source-text, pre.prettyprint');
        if (!codeElement) {
          const bodyText = doc.body ? doc.body.textContent : '';
          
          if (bodyText.includes('Your browser is being checked') || (bodyText.includes('Please wait') && bodyText.includes('_0x'))) {
            handleTabFallback();
            return;
          }

          overlay.remove();
          const pageTitle = doc.title || '';
          const hasLoginForm = !!doc.querySelector('form[action*="/enter"], form[action*="/login"]');
          
          console.warn('[CF Dashboard] viewFriendCode parse failure diagnostics:\n' + JSON.stringify({
            fetchUrl: submissionUrl,
            resUrl: resUrl,
            pageTitle: pageTitle,
            hasLoginForm: hasLoginForm,
            bodySnippet: bodyText.slice(0, 500).replace(/\s+/g, ' ')
          }, null, 2));

          if (hasLoginForm || bodyText.includes('Login to Codeforces') || bodyText.includes('enter your handle') || bodyText.includes('authorized')) {
            alert('Could not retrieve code. You are not logged into Codeforces.');
          } else if (bodyText.includes('You are not allowed to view this submission') || 
                     bodyText.includes('solved the problem') || 
                     bodyText.includes('allowed to view') || 
                     bodyText.includes('trusted participant') ||
                     bodyText.includes('not allowed')) {
            alert('Could not retrieve code. Codeforces does not allow viewing other users\' submissions for this problem until you have solved it yourself or the contest has ended.');
          } else {
            alert('Could not retrieve code. Make sure you are logged in and have permission to view submissions for this problem.');
          }
          return;
        }

        overlay.remove();
        const rawCode = codeElement.textContent;
        let language = 'Code';
        const cellThs = [...doc.querySelectorAll('th, td')];
        for (let i = 0; i < cellThs.length; i++) {
          if (cellThs[i].textContent.includes('Language') && cellThs[i+1]) {
            language = cellThs[i+1].textContent.trim();
            break;
          }
        }

        showCodeOverlay(friend, rawCode, language);
      })
      .catch(err => {
        handleTabFallback();
      });
  }

  function setupStopwatch(contestId, problemIndex, enabled) {
    const problemKey = `${contestId}_${problemIndex}`;
    stopwatchStateKey = `cfd-stopwatch-${problemKey}`;

    if (!enabled) {
      if (stopwatchIntervalId) {
        clearInterval(stopwatchIntervalId);
        stopwatchIntervalId = null;
      }
      const existing = document.querySelector('.cfd-stopwatch-sidebox');
      if (existing) {
        // Save the elapsed time if running
        let state = null;
        try {
          const saved = localStorage.getItem(stopwatchStateKey);
          if (saved) state = JSON.parse(saved);
        } catch (e) {}
        if (state && state.running && !state.solved) {
          const delta = Date.now() - state.startTime;
          state.elapsed += delta;
          state.startTime = Date.now();
          localStorage.setItem(stopwatchStateKey, JSON.stringify(state));
        }
        existing.remove();
      }
      return;
    }

    if (document.querySelector('.cfd-stopwatch-sidebox')) {
      return;
    }

    const sidebar = $('#sidebar');
    if (!sidebar) return;

    const stopwatchBox = document.createElement('div');
    stopwatchBox.className = 'roundbox sidebox cfd-stopwatch-sidebox cfd-animate';
    stopwatchBox.style.marginTop = '15px';
    stopwatchBox.style.overflow = 'hidden';

    const swHeader = document.createElement('div');
    swHeader.className = 'caption titled';
    swHeader.style.borderBottom = '1px solid var(--cfd-card-border)';
    swHeader.style.paddingBottom = '4px';
    swHeader.style.display = 'flex';
    swHeader.style.justifyContent = 'space-between';
    swHeader.style.alignItems = 'center';
    
    const swTitle = document.createElement('span');
    swTitle.innerText = '→ Practice Stopwatch';
    const swStatus = document.createElement('span');
    swStatus.className = 'cfd-stopwatch-status';
    swStatus.style.fontSize = '10px';
    swStatus.style.fontWeight = 'normal';
    swStatus.style.color = 'var(--cfd-text-muted)';
    swStatus.innerText = '⏱️ Running';

    swHeader.appendChild(swTitle);
    swHeader.appendChild(swStatus);
    stopwatchBox.appendChild(swHeader);

    const swBody = document.createElement('div');
    swBody.className = 'body';
    swBody.style.padding = '12px';
    swBody.style.textAlign = 'center';
    swBody.innerHTML = `
      <div class="cfd-stopwatch-time" style="font-size:26px; font-weight:700; font-family:monospace; color:var(--cfd-text)">00:00</div>
      <div class="cfd-stopwatch-controls" style="display:flex; gap:8px; justify-content:center; margin-top:10px">
        <button class="cfd-refresh-btn cfd-stopwatch-toggle" style="padding:4px 10px; font-size:11px; margin:0; cursor:pointer">Pause</button>
        <button class="cfd-refresh-btn cfd-stopwatch-reset" style="padding:4px 10px; font-size:11px; margin:0; background:rgba(224, 112, 0, 0.15); color:var(--cfd-tle); border-color:rgba(224, 112, 0, 0.25); cursor:pointer">Reset</button>
      </div>`;
    stopwatchBox.appendChild(swBody);

    injectSidebox(stopwatchBox, 'stopwatch');

    const timeDiv = stopwatchBox.querySelector('.cfd-stopwatch-time');
    const statusSpan = stopwatchBox.querySelector('.cfd-stopwatch-status');
    const toggleBtn = stopwatchBox.querySelector('.cfd-stopwatch-toggle');
    const resetBtn = stopwatchBox.querySelector('.cfd-stopwatch-reset');

    stopwatchState = {
      startTime: Date.now(),
      elapsed: 0,
      running: true,
      solved: false,
      solveTime: null
    };

    try {
      const saved = localStorage.getItem(stopwatchStateKey);
      if (saved) stopwatchState = JSON.parse(saved);
    } catch (e) {}

    if (stopwatchState.running && !stopwatchState.solved) {
      const delta = Date.now() - stopwatchState.startTime;
      stopwatchState.elapsed += delta;
      stopwatchState.startTime = Date.now();
      localStorage.setItem(stopwatchStateKey, JSON.stringify(stopwatchState));
    }

    function formatTime(ms) {
      const totalSecs = Math.floor(ms / 1000);
      const hrs = Math.floor(totalSecs / 3600);
      const mins = Math.floor((totalSecs % 3600) / 60);
      const secs = totalSecs % 60;
      const pad = n => String(n).padStart(2, '0');
      if (hrs > 0) {
        return `${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
      }
      return `${pad(mins)}:${pad(secs)}`;
    }

    function syncStopwatchUI() {
      if (!timeDiv) return;
      timeDiv.textContent = formatTime(stopwatchState.elapsed);
      
      if (stopwatchState.solved) {
        statusSpan.innerHTML = '🎉 Solved';
        statusSpan.style.color = 'var(--cfd-ok)';
        timeDiv.style.color = 'var(--cfd-ok)';
        timeDiv.textContent = formatTime(stopwatchState.solveTime);
        const controls = stopwatchBox.querySelector('.cfd-stopwatch-controls');
        if (controls) controls.style.display = 'none';
        if (stopwatchIntervalId) {
          clearInterval(stopwatchIntervalId);
          stopwatchIntervalId = null;
        }
        return;
      }

      if (stopwatchState.running) {
        statusSpan.innerHTML = '⏱️ Running';
        statusSpan.style.color = 'var(--cfd-accent)';
        toggleBtn.textContent = 'Pause';
        toggleBtn.style.background = '';
        if (!stopwatchIntervalId) {
          stopwatchState.startTime = Date.now();
          stopwatchIntervalId = setInterval(() => {
            const now = Date.now();
            const delta = now - stopwatchState.startTime;
            stopwatchState.elapsed += delta;
            stopwatchState.startTime = now;
            timeDiv.textContent = formatTime(stopwatchState.elapsed);
            localStorage.setItem(stopwatchStateKey, JSON.stringify(stopwatchState));
          }, 1000);
        }
      } else {
        statusSpan.innerHTML = '⏸️ Paused';
        statusSpan.style.color = 'var(--cfd-text-muted)';
        toggleBtn.textContent = 'Resume';
        toggleBtn.style.background = 'rgba(16, 185, 129, 0.15)';
        if (stopwatchIntervalId) {
          clearInterval(stopwatchIntervalId);
          stopwatchIntervalId = null;
        }
        localStorage.setItem(stopwatchStateKey, JSON.stringify(stopwatchState));
      }
    }

    toggleBtn.addEventListener('click', () => {
      stopwatchState.running = !stopwatchState.running;
      stopwatchState.startTime = Date.now();
      syncStopwatchUI();
      broadcastStopwatchState();
    });

    resetBtn.addEventListener('click', () => {
      if (confirm('Are you sure you want to reset the stopwatch for this problem?')) {
        stopwatchState.elapsed = 0;
        stopwatchState.startTime = Date.now();
        stopwatchState.running = true;
        stopwatchState.solved = false;
        stopwatchState.solveTime = null;
        syncStopwatchUI();
        broadcastStopwatchState();
      }
    });

    function broadcastStopwatchState() {
      if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.id) return;
      try {
        chrome.runtime.sendMessage({
          type: 'CF_SYNC_STATE',
          payload: {
            action: 'STOPWATCH_SYNC',
            problemKey,
            state: stopwatchState
          }
        });
      } catch (e) {
        console.warn('[CF Dashboard] broadcastStopwatchState extension context invalidated.');
      }
    }

    function runAutoStopCheck() {
      if (stopwatchState.solved) return;

      const handle = getLoggedInUser();
      if (!handle) return;

      const jitter = 1500 + Math.random() * 1500;
      setTimeout(() => {
        if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.id) return;
        try {
          chrome.runtime.sendMessage({
            type: 'CF_CHECK_SUBMISSION',
            handle,
            contestId,
            problemIndex
          }, response => {
            if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.id || chrome.runtime.lastError) {
              return;
            }
            if (response && response.ok && response.solved) {
              stopwatchState.solved = true;
              stopwatchState.running = false;
              stopwatchState.solveTime = stopwatchState.elapsed;
              localStorage.setItem(stopwatchStateKey, JSON.stringify(stopwatchState));
              
              let stopwatchHistory = {};
              try {
                stopwatchHistory = JSON.parse(localStorage.getItem('cfd-stopwatch-history') || '{}');
              } catch(e) {}
              stopwatchHistory[problemKey] = {
                solveTimeMs: stopwatchState.elapsed,
                timestamp: Date.now()
              };
              localStorage.setItem('cfd-stopwatch-history', JSON.stringify(stopwatchHistory));

              syncStopwatchUI();
              broadcastStopwatchState();
            }
          });
        } catch (e) {
          console.warn('[CF Dashboard] runAutoStopCheck extension context invalidated.');
        }
      }, jitter);
    }

    runAutoStopCheck();

    if (!setupStopwatch.hasVisibilityListener) {
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible' && currentSettings.stopwatchEnabled && stopwatchState) {
          if (stopwatchState.running && !stopwatchState.solved) {
            const delta = Date.now() - stopwatchState.startTime;
            stopwatchState.elapsed += delta;
            stopwatchState.startTime = Date.now();
          }
          const activeStopwatchBox = document.querySelector('.cfd-stopwatch-sidebox');
          if (activeStopwatchBox) {
            const activeTimeDiv = activeStopwatchBox.querySelector('.cfd-stopwatch-time');
            if (activeTimeDiv) activeTimeDiv.textContent = formatTime(stopwatchState.elapsed);
          }
          runAutoStopCheck();
        }
      });
      setupStopwatch.hasVisibilityListener = true;
    }

    syncStopwatchUI();
  }

  function setupFriendsSolutions(contestId, problemIndex, enabled) {
    if (!enabled) {
      const existing = document.querySelector('.cfd-friends-sidebox');
      if (existing) existing.remove();
      return;
    }

    if (document.querySelector('.cfd-friends-sidebox')) {
      return;
    }

    const sidebar = $('#sidebar');
    if (!sidebar) return;

    const friendsBox = document.createElement('div');
    friendsBox.className = 'roundbox sidebox cfd-friends-sidebox cfd-animate';
    friendsBox.style.marginTop = '15px';
    friendsBox.style.overflow = 'hidden';

    const frHeader = document.createElement('div');
    frHeader.className = 'caption titled';
    frHeader.style.borderBottom = '1px solid var(--cfd-card-border)';
    frHeader.style.paddingBottom = '4px';
    frHeader.style.cursor = 'pointer';
    frHeader.style.display = 'flex';
    frHeader.style.justifyContent = 'space-between';
    frHeader.style.alignItems = 'center';
    frHeader.style.userSelect = 'none';

    const frTitle = document.createElement('span');
    frTitle.innerText = '→ Friends\' Solutions';

    const frToggleSpan = document.createElement('span');
    frToggleSpan.className = 'cfd-friends-toggle-btn';
    frToggleSpan.style.display = 'inline-block';
    frToggleSpan.style.width = '6px';
    frToggleSpan.style.height = '6px';
    frToggleSpan.style.borderRight = '1.5px solid var(--cfd-text-muted)';
    frToggleSpan.style.borderBottom = '1.5px solid var(--cfd-text-muted)';
    frToggleSpan.style.marginRight = '6px';
    frToggleSpan.style.cursor = 'pointer';
    frToggleSpan.style.transition = 'transform 0.2s ease, border-color 0.2s';

    frHeader.appendChild(frTitle);
    frHeader.appendChild(frToggleSpan);
    friendsBox.appendChild(frHeader);

    const frBody = document.createElement('div');
    frBody.className = 'body';
    frBody.style.padding = '10px';
    frBody.style.maxHeight = '220px';
    frBody.style.overflowY = 'auto';
    frBody.innerHTML = `
      <div class="cfd-friends-status" style="font-size:11px; color:var(--cfd-text-muted); text-align:center; padding:10px">
        Checking for friends' submissions...
      </div>`;
    friendsBox.appendChild(frBody);

    let frCollapsed = localStorage.getItem('cfd-friends-collapsed') === 'true';

    function applyFriendsCollapseState() {
      if (frCollapsed) {
        frBody.style.display = 'none';
        frHeader.style.borderBottom = 'none';
        frHeader.style.borderBottomLeftRadius = '4px';
        frHeader.style.borderBottomRightRadius = '4px';
        frToggleSpan.style.transform = 'rotate(-45deg)';
        frToggleSpan.style.borderColor = 'var(--cfd-text-muted)';
      } else {
        frBody.style.display = 'block';
        frHeader.style.borderBottom = '1px solid var(--cfd-card-border)';
        frHeader.style.borderBottomLeftRadius = '0';
        frHeader.style.borderBottomRightRadius = '0';
        frToggleSpan.style.transform = 'rotate(45deg)';
        frToggleSpan.style.borderColor = 'var(--cfd-accent)';
      }
    }

    applyFriendsCollapseState();

    frHeader.addEventListener('click', () => {
      frCollapsed = !frCollapsed;
      localStorage.setItem('cfd-friends-collapsed', frCollapsed ? 'true' : 'false');
      applyFriendsCollapseState();
    });

    injectSidebox(friendsBox, 'friends');

    let friendsStatusUrl = '';
    const currentPath = window.location.pathname;
    
    if (currentPath.includes('/gym/')) {
      friendsStatusUrl = `https://codeforces.com/gym/${contestId}/status?problemIndex=${problemIndex}&friends=on`;
    } else if (currentPath.includes('/problemset/')) {
      friendsStatusUrl = `https://codeforces.com/problemset/status?contestId=${contestId}&problemIndex=${problemIndex}&friends=on`;
    } else {
      friendsStatusUrl = `https://codeforces.com/contest/${contestId}/status?problemIndex=${problemIndex}&friends=on`;
    }

    fetch(friendsStatusUrl)
      .then(res => res.text())
      .then(html => {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        const rows = doc.querySelectorAll('tr[data-submission-id]');
        
        const successMap = {};
        rows.forEach(row => {
          const verdictCell = row.querySelector('.status-verdict-cell') || row.querySelector('.status-verdict') || row.querySelector('span.submissionVerdict');
          if (verdictCell) {
            const txt = verdictCell.textContent.toLowerCase();
            if (txt.includes('accepted') || txt.includes('ok') || verdictCell.querySelector('.verdict-accepted') || verdictCell.querySelector('.submission-verdict-accepted')) {
              const subId = row.getAttribute('data-submission-id');
              const userLink = row.querySelector('a[href^="/profile/"]');
              if (userLink) {
                const friend = userLink.textContent.trim();
                if (!successMap[friend] || parseInt(subId, 10) > parseInt(successMap[friend].submissionId, 10)) {
                  successMap[friend] = { submissionId: subId };
                }
              }
            }
          }
        });

        const friendsList = Object.keys(successMap);
        if (friendsList.length === 0) {
          frBody.innerHTML = `
            <div style="font-size:11px; color:var(--cfd-text-muted); text-align:center; padding:10px">
              No solutions found from friends for this problem.
            </div>`;
          return;
        }

        frBody.innerHTML = `
          <div style="display:flex; flex-direction:column; gap:8px">
            ${friendsList.map(friend => {
              return `
                <div style="display:flex; align-items:center; justify-content:space-between; font-size:11px; background:rgba(0,120,193,0.03); padding:6px; border-radius:4px; border:1px solid var(--cfd-card-border)">
                  <a href="/profile/${friend}" style="font-weight:700; color:var(--cfd-accent); text-decoration:none">${friend}</a>
                  <button class="cfd-btn cfd-view-code-btn" data-sub-id="${successMap[friend].submissionId}" data-friend="${friend}" style="padding:2px 8px; font-size:10px; margin:0; cursor:pointer">View Code</button>
                </div>`;
            }).join('')}
          </div>`;

        frBody.querySelectorAll('.cfd-view-code-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const subId = btn.getAttribute('data-sub-id');
            const friend = btn.getAttribute('data-friend');
            viewFriendCode(contestId, subId, friend);
          });
        });
      })
      .catch(err => {
        frBody.innerHTML = `
          <div style="font-size:11px; color:var(--cfd-text-muted); text-align:center; padding:10px">
            Error loading friends' solutions.
          </div>`;
      });
  }

  function triggerMathJax(element) {
    if (!element) return;
    if (!element.id) {
      element.id = 'cfd-mathjax-temp-' + Math.floor(Math.random() * 1e9);
    }
    document.dispatchEvent(new CustomEvent('CFD_TYPESET_MATH', {
      detail: { id: element.id }
    }));
  }

  function setupAICoach(contestId, problemIndex, enabled) {
    if (!enabled) {
      const existing = document.querySelector('.cfd-coach-sidebox');
      if (existing) existing.remove();
      return;
    }

    if (document.querySelector('.cfd-coach-sidebox')) {
      return;
    }

    const problemStatement = document.querySelector('.problem-statement');
    if (!problemStatement) return;
    const indexHolder = problemStatement.closest('.problemindexholder') || problemStatement;

    const hintStateKey = `cfd-hints-${contestId}_${problemIndex}`;
    let hintState = { currentStep: 0, hint1: "", hint2: "", hint3: "" };
    try {
      const saved = localStorage.getItem(hintStateKey);
      if (saved) hintState = JSON.parse(saved);
    } catch (e) {}

    const coachBox = document.createElement('div');
    coachBox.className = 'roundbox cfd-coach-sidebox cfd-animate';
    coachBox.style.marginTop = '15px';
    coachBox.style.overflow = 'hidden';

    const coHeader = document.createElement('div');
    coHeader.className = 'caption titled';
    coHeader.style.borderBottom = '1px solid var(--cfd-card-border)';
    coHeader.style.paddingBottom = '4px';
    coHeader.style.cursor = 'pointer';
    coHeader.style.display = 'flex';
    coHeader.style.justifyContent = 'space-between';
    coHeader.style.alignItems = 'center';
    coHeader.style.userSelect = 'none';

    const coTitle = document.createElement('span');
    coTitle.innerText = '→ Anti-Spoiler AI Coach';

    const coToggleSpan = document.createElement('span');
    coToggleSpan.className = 'cfd-coach-toggle-btn';
    coToggleSpan.style.display = 'inline-block';
    coToggleSpan.style.width = '6px';
    coToggleSpan.style.height = '6px';
    coToggleSpan.style.borderRight = '1.5px solid var(--cfd-text-muted)';
    coToggleSpan.style.borderBottom = '1.5px solid var(--cfd-text-muted)';
    coToggleSpan.style.marginRight = '6px';
    coToggleSpan.style.cursor = 'pointer';
    coToggleSpan.style.transition = 'transform 0.2s ease, border-color 0.2s';

    coHeader.appendChild(coTitle);
    coHeader.appendChild(coToggleSpan);
    coachBox.appendChild(coHeader);

    const coBody = document.createElement('div');
    coBody.className = 'body';
    coBody.style.padding = '12px';
    coachBox.appendChild(coBody);

    let coCollapsed = localStorage.getItem('cfd-coach-collapsed') === 'true';

    function applyCoachCollapseState() {
      if (coCollapsed) {
        coBody.style.display = 'none';
        coHeader.style.borderBottom = 'none';
        coHeader.style.borderBottomLeftRadius = '4px';
        coHeader.style.borderBottomRightRadius = '4px';
        coToggleSpan.style.transform = 'rotate(-45deg)';
        coToggleSpan.style.borderColor = 'var(--cfd-text-muted)';
      } else {
        coBody.style.display = 'block';
        coHeader.style.borderBottom = '1px solid var(--cfd-card-border)';
        coHeader.style.borderBottomLeftRadius = '0';
        coHeader.style.borderBottomRightRadius = '0';
        coToggleSpan.style.transform = 'rotate(45deg)';
        coToggleSpan.style.borderColor = 'var(--cfd-accent)';
      }
    }

    applyCoachCollapseState();

    coHeader.addEventListener('click', () => {
      coCollapsed = !coCollapsed;
      localStorage.setItem('cfd-coach-collapsed', coCollapsed ? 'true' : 'false');
      applyCoachCollapseState();
    });

    indexHolder.insertAdjacentElement('afterend', coachBox);

    function renderHints() {
      coBody.innerHTML = '';

      const container = document.createElement('div');
      container.className = 'cfd-coach-container';
      container.style.fontSize = '13px';
      container.style.lineHeight = '1.5';

      if (hintState.currentStep === 0) {
        const intro = document.createElement('div');
        intro.style.color = 'var(--cfd-text-muted)';
        intro.style.marginBottom = '10px';
        intro.style.textAlign = 'center';
        intro.innerText = 'Stuck on this problem? Ask the Socratic Coach for guided hints instead of spoiling the editorial.';
        container.appendChild(intro);
      }

      if (hintState.currentStep >= 1) {
        const h1Div = document.createElement('div');
        h1Div.className = 'cfd-hint-bubble cfd-hint-h1';
        h1Div.style.marginBottom = '12px';
        h1Div.style.padding = '8px';
        h1Div.style.background = 'rgba(0, 120, 193, 0.03)';
        h1Div.style.borderLeft = '2.5px solid var(--cfd-accent)';
        h1Div.style.borderRadius = '3px';
        h1Div.innerHTML = `<div style="font-weight:700; font-size:11px; color:var(--cfd-accent); text-transform:uppercase; margin-bottom:4px; letter-spacing:0.5px">Hint 1: The Observation</div><div>${hintState.hint1}</div>`;
        container.appendChild(h1Div);
      }

      if (hintState.currentStep >= 2) {
        const h2Div = document.createElement('div');
        h2Div.className = 'cfd-hint-bubble cfd-hint-h2';
        h2Div.style.marginBottom = '12px';
        h2Div.style.padding = '8px';
        h2Div.style.background = 'rgba(16, 185, 129, 0.03)';
        h2Div.style.borderLeft = '2.5px solid var(--cfd-ok)';
        h2Div.style.borderRadius = '3px';
        h2Div.innerHTML = `<div style="font-weight:700; font-size:11px; color:var(--cfd-ok); text-transform:uppercase; margin-bottom:4px; letter-spacing:0.5px">Hint 2: Reducibility</div><div>${hintState.hint2}</div>`;
        container.appendChild(h2Div);
      }

      if (hintState.currentStep >= 3) {
        const h3Div = document.createElement('div');
        h3Div.className = 'cfd-hint-bubble cfd-hint-h3';
        h3Div.style.marginBottom = '12px';
        h3Div.style.padding = '8px';
        h3Div.style.background = 'rgba(224, 112, 0, 0.05)';
        h3Div.style.borderLeft = '2.5px solid var(--cfd-tle)';
        h3Div.style.borderRadius = '3px';
        h3Div.innerHTML = `<div style="font-weight:700; font-size:11px; color:var(--cfd-tle); text-transform:uppercase; margin-bottom:4px; letter-spacing:0.5px">Hint 3: Complexity & Constraints</div><div>${hintState.hint3}</div>`;
        container.appendChild(h3Div);
      }

      coBody.appendChild(container);
      triggerMathJax(container);

      const btnArea = document.createElement('div');
      btnArea.style.display = 'flex';
      btnArea.style.flexDirection = 'column';
      btnArea.style.gap = '8px';
      btnArea.style.marginTop = '10px';

      if (hintState.currentStep < 3) {
        const actionBtn = document.createElement('button');
        actionBtn.className = 'cfd-refresh-btn';
        actionBtn.style.width = '100%';
        actionBtn.style.margin = '0';
        actionBtn.style.cursor = 'pointer';
        actionBtn.style.display = 'flex';
        actionBtn.style.justifyContent = 'center';
        actionBtn.style.alignItems = 'center';
        actionBtn.style.gap = '4px';

        const stepNames = [
          'Get Hint 1: Observation',
          'Get Hint 2: Paradigm & Approach',
          'Get Hint 3: Complexity & Constraints'
        ];
        actionBtn.innerText = stepNames[hintState.currentStep];

        actionBtn.addEventListener('click', () => {
          getHintFromAI(actionBtn);
        });
        btnArea.appendChild(actionBtn);
      }

      if (hintState.currentStep > 0) {
        const resetBtn = document.createElement('button');
        resetBtn.className = 'cfd-refresh-btn';
        resetBtn.style.width = '100%';
        resetBtn.style.margin = '0';
        resetBtn.style.cursor = 'pointer';
        resetBtn.style.background = 'rgba(220, 38, 38, 0.08)';
        resetBtn.style.borderColor = 'rgba(220, 38, 38, 0.15)';
        resetBtn.style.color = '#ef4444';
        resetBtn.innerText = 'Reset Hints';
        resetBtn.addEventListener('click', () => {
          if (confirm('Are you sure you want to reset hints for this problem?')) {
            hintState = { currentStep: 0, hint1: "", hint2: "", hint3: "" };
            localStorage.setItem(hintStateKey, JSON.stringify(hintState));
            renderHints();
          }
        });
        btnArea.appendChild(resetBtn);
      }

      coBody.appendChild(btnArea);
    }

    function getHintFromAI(button) {
      const statementEl = document.querySelector('.problem-statement');
      if (!statementEl) {
        alert('Could not locate the problem statement on this page.');
        return;
      }

      const clone = statementEl.cloneNode(true);
      const sampleTests = clone.querySelector('.sample-tests');
      if (sampleTests) sampleTests.remove();
      const problemText = clone.innerText;

      button.disabled = true;
      button.innerText = '⏳ Thinking...';

      const nextStep = hintState.currentStep + 1;

      chrome.runtime.sendMessage({
        type: 'CF_GET_AI_HINT',
        step: nextStep,
        problemText: problemText,
        previousHints: {
          hint1: hintState.hint1,
          hint2: hintState.hint2
        }
      }, response => {
        button.disabled = false;
        if (response && response.ok) {
          hintState.currentStep = nextStep;
          if (nextStep === 1) hintState.hint1 = response.hint;
          else if (nextStep === 2) hintState.hint2 = response.hint;
          else if (nextStep === 3) hintState.hint3 = response.hint;

          localStorage.setItem(hintStateKey, JSON.stringify(hintState));
          renderHints();
        } else {
          alert('AI Hint Error: ' + (response?.error || 'Failed to fetch hint. Please check your API keys settings in the extension popup.'));
          renderHints();
        }
      });
    }

    renderHints();
  }

  function setupAICases(contestId, problemIndex, enabled) {
    if (!enabled) {
      const existing = document.querySelector('.cfd-ai-test-cases-container');
      if (existing) existing.remove();
      return;
    }

    if (document.querySelector('.cfd-ai-test-cases-container')) {
      return;
    }

    const problemStatement = document.querySelector('.problem-statement');
    if (!problemStatement) return;
    const indexHolder = problemStatement.closest('.problemindexholder') || problemStatement;

    const casesStateKey = `cfd-ai-cases-${contestId}_${problemIndex}`;
    let casesData = null;
    try {
      const saved = localStorage.getItem(casesStateKey);
      if (saved) casesData = JSON.parse(saved);
    } catch (e) {}

    const container = document.createElement('div');
    container.className = 'roundbox sample-tests cfd-ai-test-cases-container cfd-animate';
    container.style.marginTop = '15px';
    container.style.overflow = 'hidden';

    const header = document.createElement('div');
    header.className = 'caption titled';
    header.style.borderBottom = '1px solid var(--cfd-card-border)';
    header.style.paddingBottom = '4px';
    header.style.cursor = 'pointer';
    header.style.display = 'flex';
    header.style.justifyContent = 'space-between';
    header.style.alignItems = 'center';
    header.style.userSelect = 'none';

    const titleSpan = document.createElement('span');
    titleSpan.innerText = '→ AI Edge Case Generator';

    const toggleSpan = document.createElement('span');
    toggleSpan.className = 'cfd-ai-cases-toggle-btn';
    toggleSpan.style.display = 'inline-block';
    toggleSpan.style.width = '6px';
    toggleSpan.style.height = '6px';
    toggleSpan.style.borderRight = '1.5px solid var(--cfd-text-muted)';
    toggleSpan.style.borderBottom = '1.5px solid var(--cfd-text-muted)';
    toggleSpan.style.marginRight = '6px';
    toggleSpan.style.cursor = 'pointer';
    toggleSpan.style.transition = 'transform 0.2s ease, border-color 0.2s';
    
    header.appendChild(titleSpan);
    header.appendChild(toggleSpan);
    container.appendChild(header);

    const body = document.createElement('div');
    body.className = 'cfd-ai-cases-body';
    body.style.padding = '12px';
    container.appendChild(body);

    let isCollapsed = localStorage.getItem('cfd-ai-cases-collapsed') === 'true';

    function applyCollapseState() {
      if (isCollapsed) {
        body.style.display = 'none';
        header.style.borderBottom = 'none';
        header.style.borderBottomLeftRadius = '4px';
        header.style.borderBottomRightRadius = '4px';
        toggleSpan.style.transform = 'rotate(-45deg)';
        toggleSpan.style.borderColor = 'var(--cfd-text-muted)';
      } else {
        body.style.display = 'block';
        header.style.borderBottom = '1px solid var(--cfd-card-border)';
        header.style.borderBottomLeftRadius = '0';
        header.style.borderBottomRightRadius = '0';
        toggleSpan.style.transform = 'rotate(45deg)';
        toggleSpan.style.borderColor = 'var(--cfd-accent)';
      }
    }

    applyCollapseState();

    header.addEventListener('click', () => {
      isCollapsed = !isCollapsed;
      localStorage.setItem('cfd-ai-cases-collapsed', isCollapsed ? 'true' : 'false');
      applyCollapseState();
    });

    indexHolder.insertAdjacentElement('afterend', container);

    function renderCases() {
      body.innerHTML = '';

      const contentDiv = document.createElement('div');
      contentDiv.className = 'cfd-ai-cases-content';
      contentDiv.style.fontSize = '13px';
      contentDiv.style.lineHeight = '1.5';

      if (!casesData || casesData.length === 0) {
        const intro = document.createElement('div');
        intro.style.color = 'var(--cfd-text-muted)';
        intro.style.textAlign = 'center';
        intro.style.padding = '15px';
        intro.innerText = 'Click below to generate critical edge cases, boundary conditions, and potential failure points for this problem.';
        contentDiv.appendChild(intro);
      } else {
        casesData.forEach(c => {
          const caseEl = document.createElement('div');
          caseEl.style.marginBottom = '16px';
          caseEl.style.paddingBottom = '14px';
          caseEl.style.borderBottom = '1px dashed var(--cfd-card-border)';
          
          if (c === casesData[casesData.length - 1]) {
            caseEl.style.borderBottom = 'none';
            caseEl.style.paddingBottom = '0';
            caseEl.style.marginBottom = '0';
          }

          caseEl.innerHTML = `
            <div style="font-weight: 700; color: var(--cfd-accent); font-size: 13px; margin-bottom: 4px;">🎯 ${escapeHtml(c.scenario)}</div>
            <div style="font-style: italic; color: var(--cfd-text-muted); font-size: 13px; margin-bottom: 8px; line-height: 1.5;">
              💡 <b>Why it fails:</b> ${escapeHtml(c.explanation)}
            </div>
            <div class="sample-test">
              <div class="input">
                <div class="title">
                  Input
                  <div class="input-output-copy cfd-copy-input-btn" style="cursor: pointer; user-select: none;">Copy</div>
                </div>
                <pre>${escapeHtml(c.input)}</pre>
              </div>
              <div class="output">
                <div class="title">
                  Output
                  <div class="input-output-copy cfd-copy-output-btn" style="cursor: pointer; user-select: none;">Copy</div>
                </div>
                <pre>${escapeHtml(c.output)}</pre>
              </div>
            </div>`;

          const copyInputBtn = caseEl.querySelector('.cfd-copy-input-btn');
          if (copyInputBtn) {
            copyInputBtn.addEventListener('click', () => {
              navigator.clipboard.writeText(c.input).then(() => {
                copyInputBtn.innerText = 'Copied!';
                setTimeout(() => { copyInputBtn.innerText = 'Copy'; }, 1500);
              }).catch(err => {
                console.error('Failed to copy input: ', err);
              });
            });
          }

          const copyOutputBtn = caseEl.querySelector('.cfd-copy-output-btn');
          if (copyOutputBtn) {
            copyOutputBtn.addEventListener('click', () => {
              navigator.clipboard.writeText(c.output).then(() => {
                copyOutputBtn.innerText = 'Copied!';
                setTimeout(() => { copyOutputBtn.innerText = 'Copy'; }, 1500);
              }).catch(err => {
                console.error('Failed to copy output: ', err);
              });
            });
          }

          contentDiv.appendChild(caseEl);
        });
      }

      body.appendChild(contentDiv);
      triggerMathJax(contentDiv);

      // Controls
      const controlsDiv = document.createElement('div');
      controlsDiv.className = 'cfd-ai-cases-controls';
      controlsDiv.style.display = 'flex';
      controlsDiv.style.flexDirection = 'column';
      controlsDiv.style.gap = '8px';
      controlsDiv.style.marginTop = '12px';

      const generateBtn = document.createElement('button');
      generateBtn.className = 'cfd-refresh-btn';
      generateBtn.style.width = '100%';
      generateBtn.style.margin = '0';
      generateBtn.style.cursor = 'pointer';
      
      if (!casesData || casesData.length === 0) {
        generateBtn.innerText = 'Generate Edge Cases (AI)';
      } else {
        generateBtn.innerText = 'Regenerate Edge Cases (AI)';
      }

      generateBtn.addEventListener('click', () => {
        generateCasesFromAI(generateBtn);
      });
      controlsDiv.appendChild(generateBtn);

      if (casesData && casesData.length > 0) {
        const clearBtn = document.createElement('button');
        clearBtn.className = 'cfd-refresh-btn';
        clearBtn.style.width = '100%';
        clearBtn.style.margin = '0';
        clearBtn.style.cursor = 'pointer';
        clearBtn.style.background = 'rgba(220, 38, 38, 0.08)';
        clearBtn.style.borderColor = 'rgba(220, 38, 38, 0.15)';
        clearBtn.style.color = '#ef4444';
        clearBtn.innerText = 'Clear Cases';
        clearBtn.addEventListener('click', () => {
          if (confirm('Are you sure you want to clear AI edge cases?')) {
            casesData = null;
            localStorage.removeItem(casesStateKey);
            renderCases();
          }
        });
        controlsDiv.appendChild(clearBtn);
      }

      body.appendChild(controlsDiv);
    }

    function generateCasesFromAI(button) {
      if (!problemStatement) return;

      const clone = problemStatement.cloneNode(true);
      const sampleTestsEl = clone.querySelector('.sample-tests');
      if (sampleTestsEl) sampleTestsEl.remove();
      const problemText = clone.innerText;

      button.disabled = true;
      button.innerText = '⏳ Analyzing problem & generating cases...';

      chrome.runtime.sendMessage({
        type: 'CF_GET_AI_EDGE_CASES',
        problemText: problemText
      }, response => {
        button.disabled = false;
        if (response && response.ok) {
          try {
            let cleanJson = response.data.trim();
            
            // Clean markdown blocks
            if (cleanJson.startsWith('```')) {
              const lines = cleanJson.split('\n');
              if (lines[0].startsWith('```')) lines.shift();
              if (lines[lines.length - 1].startsWith('```')) lines.pop();
              cleanJson = lines.join('\n').trim();
            }

            const parsed = JSON.parse(cleanJson);
            if (Array.isArray(parsed)) {
              casesData = parsed;
              localStorage.setItem(casesStateKey, JSON.stringify(casesData));
              renderCases();
            } else {
              throw new Error("Response was not a JSON array.");
            }
          } catch (e) {
            console.error("JSON parse error:", e, response.data);
            alert("AI Error: Failed to parse generated test cases. Please try again. Raw output was: " + response.data.slice(0, 200) + "...");
            renderCases();
          }
        } else {
          alert('AI Error: ' + (response?.error || 'Failed to fetch edge cases. Please configure API keys settings in the extension popup.'));
          renderCases();
        }
      });
    }

    function escapeHtml(str) {
      if (!str) return '';
      return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
    }

    renderCases();
  }

  // ═══════════════════════════════════════════════════════════════════════════

  // ═══════════════════════════════════════════════════════════════════════════
  //  ZEN PRACTICE MODE (ANTI-SPOIL GUARD)
  // ═══════════════════════════════════════════════════════════════════════════
  let zenObserver = null;

  function applyZenModeDOMChanges() {
    if (zenObserver) {
      zenObserver.disconnect();
    }

    try {
      const isZen = localStorage.getItem('cfd-zen-mode') === 'true';
      if (!isZen) {
        document.documentElement.classList.remove('cfd-zen-active');
        document.querySelectorAll('.cfd-blurred-node').forEach(el => {
          el.style.filter = 'none';
          el.style.pointerEvents = 'auto';
          el.style.userSelect = 'auto';
          el.classList.remove('cfd-blurred-node');
        });
        return;
      }
      
      document.documentElement.classList.add('cfd-zen-active');

      // Deep text node scanner for dynamic ratings (e.g. *1600)
      const walker = document.createTreeWalker(
        document.body || document.documentElement,
        NodeFilter.SHOW_TEXT,
        null,
        false
      );

      let node;
      const toBlur = [];
      while (node = walker.nextNode()) {
        const txt = node.nodeValue;
        if (/\b\*\d{3,4}\b/.test(txt)) {
          toBlur.push(node.parentElement);
        }
      }

      toBlur.forEach(parent => {
        if (parent && !parent.classList.contains('cfd-blurred-node') && !parent.closest('#cf-dashboard-root')) {
          parent.classList.add('cfd-blurred-node');
          parent.style.filter = 'blur(6px)';
          parent.style.pointerEvents = 'none';
          parent.style.userSelect = 'none';
        }
      });
    } catch (e) {
      console.warn('[CF Dashboard] applyZenModeDOMChanges error:', e);
    } finally {
      if (zenObserver) {
        zenObserver.observe(document.body || document.documentElement, {
          childList: true,
          subtree: true
        });
      }
    }
  }

  function logZenProblemVisit() {
    const isZen = localStorage.getItem('cfd-zen-mode') === 'true';
    const path = window.location.pathname;
    const contestMatch = path.match(/\/(?:contest|gym)\/(\d+)\/problem\/([A-Z0-9]+)/i) || 
                         path.match(/\/problemset\/problem\/(\d+)\/([A-Z0-9]+)/i);
    if (contestMatch) {
      const contestId = contestMatch[1];
      const problemIndex = contestMatch[2].toUpperCase();
      const problemKey = `${contestId}_${problemIndex}`;
      
      let practiceLog = {};
      try {
        practiceLog = JSON.parse(localStorage.getItem('cfd-zen-practice-log') || '{}');
      } catch (e) {}

      if (!practiceLog[problemKey] || isZen) {
        practiceLog[problemKey] = {
          zenActive: isZen,
          timestamp: Date.now()
        };
        localStorage.setItem('cfd-zen-practice-log', JSON.stringify(practiceLog));
      }
    }
  }

  function watchZenMode() {
    if (zenObserver) {
      zenObserver.disconnect();
    }

    zenObserver = new MutationObserver(() => {
      applyZenModeDOMChanges();
    });

    applyZenModeDOMChanges();
    logZenProblemVisit();
  }

  let themeObserver = null;

  function watchTheme() {
    if (themeObserver) {
      themeObserver.disconnect();
    }

    themeObserver = new MutationObserver(() => {
      applyTheme();
    });

    applyTheme();

    const darkQuery = window.matchMedia('(prefers-color-scheme: dark)');
    try {
      darkQuery.removeEventListener('change', applyTheme);
    } catch (e) {}
    darkQuery.addEventListener('change', applyTheme);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  ENTRY POINT
  // ═══════════════════════════════════════════════════════════════════════════
  function applySettings(settings) {
    localStorage.setItem('cfd-zen-mode', settings.zenEnabled ? 'true' : 'false');
    applyZenModeDOMChanges();
    
    const toggle = document.querySelector('#cfd-zen-toggle');
    if (toggle) {
      toggle.checked = settings.zenEnabled;
      const switchBg = settings.zenEnabled ? 'var(--cfd-accent)' : '#ccc';
      const knobLeft = settings.zenEnabled ? '16px' : '2px';
      const zenSwitch = document.querySelector('.cfd-zen-switch');
      const zenKnob = document.querySelector('.cfd-zen-knob');
      if (zenSwitch && zenKnob) {
        zenSwitch.style.background = switchBg;
        zenKnob.style.left = knobLeft;
      }
      
      const existingZenCard = document.querySelector('.cfd-zen-intel-card-wrapper');
      if (existingZenCard && currentSubmissions && currentProblemset) {
        const newZenCard = buildZenIntelligenceCard(currentSubmissions, currentProblemset);
        existingZenCard.replaceWith(newZenCard);
      }
    }

    const hasKeys = (settings.openaiKey && settings.openaiKey.trim() !== '') || 
                    (settings.googleKey && settings.googleKey.trim() !== '');
    const showAI = settings.aiEnabled && hasKeys;

    if (currentContestId && currentProblemIndex) {
      setupStopwatch(currentContestId, currentProblemIndex, settings.stopwatchEnabled);
      setupFriendsSolutions(currentContestId, currentProblemIndex, settings.friendsEnabled);
      setupAICoach(currentContestId, currentProblemIndex, showAI);
      setupAICases(currentContestId, currentProblemIndex, showAI);
    }

    if (currentContestId) {
      setupLiveContestStrategy(currentContestId, settings.strategyEnabled);
    }
  }

  function init() {
    const target = document.body || document.documentElement;
    if (target && !document.getElementById('cfd-mathjax-helper')) {
      const script = document.createElement('script');
      script.id = 'cfd-mathjax-helper';
      script.src = chrome.runtime.getURL('mathjax-helper.js');
      target.appendChild(script);
    }

    chrome.storage.local.get({
      stopwatchEnabled: true,
      strategyEnabled: true,
      friendsEnabled: true,
      zenEnabled: true,
      aiEnabled: false,
      openaiKey: '',
      googleKey: ''
    }, (settings) => {
      currentSettings = settings;

      try {
        watchZenMode();
      } catch (e) {
        console.warn('[CF Dashboard] watchZenMode error:', e);
      }

      try {
        watchTheme();
      } catch (e) {
        console.warn('[CF Dashboard] watchTheme error:', e);
      }

      const path = window.location.pathname;
      const problemMatch = path.match(/\/(?:contest|gym)\/(\d+)\/problem\/([A-Z0-9]+)/i) || 
                           path.match(/\/problemset\/problem\/(\d+)\/([A-Z0-9]+)/i);
      if (problemMatch) {
        currentContestId = problemMatch[1];
        currentProblemIndex = problemMatch[2].toUpperCase();
      }

      const contestMatch = window.location.pathname.match(/^\/contest\/(\d+)/);
      if (contestMatch) {
        currentContestId = contestMatch[1];
      }

      applySettings(currentSettings);

      try {
        chrome.runtime.onMessage.addListener((message) => {
          if (message.type === 'CF_SYNC_STATE') {
            if (message.payload?.action === 'SETTINGS_SYNC') {
              currentSettings = message.payload.settings;
              applySettings(currentSettings);
            } else if (message.payload?.action === 'ZEN_MODE_SYNC') {
              const isZen = localStorage.getItem('cfd-zen-mode') === 'true';
              currentSettings.zenEnabled = isZen;
              chrome.storage.local.set({ zenEnabled: isZen }, () => {
                chrome.runtime.sendMessage({
                  type: 'CF_SYNC_STATE',
                  payload: {
                    action: 'SETTINGS_SYNC',
                    settings: currentSettings
                  }
                }).catch(() => {});
              });
              applySettings(currentSettings);
            }
          }

          if (message.type === 'CF_SUBMISSION_CODE_RESULT') {
            const overlay = document.querySelector('.cfd-fetching-overlay');
            if (overlay) overlay.remove();
            
            if (message.error) {
              if (message.error === 'NOT_LOGGED_IN') {
                alert('Could not retrieve code. You are not logged into Codeforces.');
              } else if (message.error === 'CODEFORCES_ACCESS_DENIED') {
                alert('Could not retrieve code. Codeforces does not allow viewing other users\' submissions for this problem until you have solved it yourself or the contest has ended.');
              } else {
                alert('Could not retrieve code. Make sure you are logged in and have permission to view submissions for this problem.');
              }
            } else {
              showCodeOverlay(message.friend, message.rawCode, message.language);
            }
          }
        });
      } catch (e) {}
    });

    const handle = getHandle();
    if (!handle) return;

    initTooltip();
    applyTheme();

    function tryInject() {
      const ul = document.querySelector('.second-level-menu ul') ||
                 document.querySelector('.tabs-box ul');
      if (ul) {
        injectDashboardTab();
        observeMenu();

        function route() {
          if (window.location.hash === '#dashboard') {
            showDashboard(handle);
          } else {
            hideDashboard();
          }
        }

        window.addEventListener('hashchange', route);

        if (window.location.hash === '#dashboard') {
          showDashboard(handle);
        }
      } else {
        setTimeout(tryInject, 200);
      }
    }

    tryInject();

    document.addEventListener('click', e => {
      const link = e.target.closest('.second-level-menu a, .tabs-box a');
      if (!link) return;
      if (link.classList.contains('cf-dashboard-tab')) return;
      hideDashboard();
    }, true);
  }

  if (window.location.hash.includes('cfd-fetch-code')) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', handleFetchCodeTab);
    } else {
      handleFetchCodeTab();
    }
  } else {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
    } else {
      init();
    }
  }

})();

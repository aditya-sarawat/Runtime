import { trackInstall, trackPing, setupUninstallURL } from './telemetry.js';

// Initialize uninstall URL handler
setupUninstallURL();


// ─── Constants ──────────────────────────────────────────────────────────────
const CF_API     = 'https://codeforces.com/api';
const REQ_DELAY  = 220;           // ms between requests (≈ 4.5/sec, safe margin)
const CACHE_TTL  = 10 * 60 * 1000; // 10 min — don't re-fetch if within this window
const PROB_TTL   = 24 * 60 * 60 * 1000; // 24h problemset cache
const CONTEST_TTL = 7 * 24 * 60 * 60 * 1000; // 7 days contest list cache
const MAX_SUBS   = 5000;          // Safe historic tail size

const pendingRequests = {};

// ─── Request Queue & Circuit Breaker ─────────────────────────────────────────
let queue         = [];
let isProcessing  = false;

let consecutiveFailures = 0;
const FAILURE_THRESHOLD = 3;
let breakerTrippedUntil = 0;

function checkCircuitBreaker() {
  return Date.now() < breakerTrippedUntil;
}

function recordSuccess() {
  consecutiveFailures = 0;
}

function recordFailure() {
  consecutiveFailures++;
  if (consecutiveFailures >= FAILURE_THRESHOLD) {
    breakerTrippedUntil = Date.now() + 3 * 60 * 1000; // Trip for 3 minutes
  }
}

async function enqueue(url) {
  return new Promise((resolve, reject) => {
    queue.push({ url, resolve, reject });
    if (!isProcessing) processQueue();
  });
}

async function processQueue() {
  isProcessing = true;
  while (queue.length > 0) {
    const { url, resolve, reject } = queue.shift();

    if (checkCircuitBreaker()) {
      reject(new Error('CIRCUIT_BREAKER_ACTIVE'));
      continue;
    }

    try {
      const res  = await fetch(url);
      const json = await res.json();
      if (json.status === 'FAILED') {
        recordFailure();
        reject(new Error(json.comment || 'CF API error'));
      } else {
        recordSuccess();
        resolve(json.result);
      }
    } catch (e) {
      recordFailure();
      reject(e);
    }
    if (queue.length > 0) await sleep(REQ_DELAY);
  }
  isProcessing = false;
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ─── Storage Helpers ─────────────────────────────────────────────────────────
async function storageGet(key) {
  return new Promise(resolve => {
    chrome.storage.local.get(key, data => resolve(data[key] ?? null));
  });
}

async function storageSet(key, value) {
  return new Promise(resolve => {
    chrome.storage.local.set({ [key]: value }, resolve);
  });
}

// ─── Contest Sync ────────────────────────────────────────────────────────────
async function syncContests() {
  const cacheKey = 'cf_contests';
  const cached   = await storageGet(cacheKey);
  const now      = Date.now();
  if (cached && (now - cached.lastUpdate) < CONTEST_TTL) {
    return cached.contestMap;
  }

  const url = `${CF_API}/contest.list?gym=false`;
  try {
    const list = await enqueue(url);
    const contestMap = {};
    for (const c of list) {
      if (c.startTimeSeconds) {
        contestMap[c.id] = c.startTimeSeconds;
      }
    }
    await storageSet(cacheKey, { contestMap, lastUpdate: now });
    return contestMap;
  } catch (e) {
    return cached ? cached.contestMap : {};
  }
}

// ─── Smart Submission Sync ───────────────────────────────────────────────────
/**
 * Fetches submissions for `handle`, merging with cached data.
 * pass = 1: Fetch first 200 submissions (immediate display)
 * pass = 2: Fetch remainder in background (lazy load)
 */
async function syncSubmissions(handle, pass = 1) {
  const cacheKey = `cf_subs_${handle.toLowerCase()}`;
  let cached = await storageGet(cacheKey);
  const now  = Date.now();

  if (cached && (now - cached.lastUpdate) < CACHE_TTL) {
    return cached.submissions;
  }

  const latestKnownId = cached ? cached.latestId : 0;
  let newSubs = [];
  let from    = 1;
  const count = 100;
  let done    = false;
  const maxPages = pass === 1 ? 2 : 50;
  let pagesFetched = 0;

  while (!done && pagesFetched < maxPages) {
    const url  = `${CF_API}/user.status?handle=${encodeURIComponent(handle)}&from=${from}&count=${count}`;
    let page;
    try {
      page = await enqueue(url);
      pagesFetched++;
    } catch (e) {
      throw e;
    }

    if (!page || page.length === 0) break;

    for (const sub of page) {
      if (sub.id <= latestKnownId) { done = true; break; }
      newSubs.push(sub);
    }

    if (page.length < count) break;
    if (done) break;
    from += count;
    await sleep(REQ_DELAY);
  }

  const merged = [...newSubs, ...(cached ? cached.submissions : [])];
  const trimmed = merged.slice(0, MAX_SUBS);

  const updated = {
    handle,
    lastUpdate: now,
    latestId:   trimmed.length > 0 ? trimmed[0].id : latestKnownId,
    submissions: trimmed
  };
  await storageSet(cacheKey, updated);
  return trimmed;
}

// ─── User Info ───────────────────────────────────────────────────────────────
async function fetchUserInfo(handle) {
  const cacheKey = `cf_info_${handle.toLowerCase()}`;
  const cached   = await storageGet(cacheKey);
  const now      = Date.now();
  if (cached && (now - cached.lastUpdate) < CACHE_TTL) return cached.data;

  const url  = `${CF_API}/user.info?handles=${encodeURIComponent(handle)}`;
  const result = await enqueue(url);
  const data   = result[0];
  await storageSet(cacheKey, { data, lastUpdate: now });
  return data;
}

// ─── User Rating History ─────────────────────────────────────────────────────
async function fetchRatingHistory(handle) {
  const cacheKey = `cf_rating_${handle.toLowerCase()}`;
  const cached   = await storageGet(cacheKey);
  const now      = Date.now();
  if (cached && (now - cached.lastUpdate) < CACHE_TTL) return cached.data;

  const url  = `${CF_API}/user.rating?handle=${encodeURIComponent(handle)}`;
  const data = await enqueue(url);
  await storageSet(cacheKey, { data, lastUpdate: now });
  return data;
}

// ─── Problemset Cache ─────────────────────────────────────────────────────────
async function fetchProblemset() {
  const cacheKey = 'cf_problemset';
  const cached   = await storageGet(cacheKey);
  const now      = Date.now();
  if (cached && (now - cached.lastUpdate) < PROB_TTL) return cached.problems;

  const url  = `${CF_API}/problemset.problems`;
  const result = await enqueue(url);
  const problems = result.problems || [];
  await storageSet(cacheKey, { problems, lastUpdate: now });
  return problems;
}

// ─── Multi-Pass Fetch Pipeline ───────────────────────────────────────────────
async function handleProfileFetch(handle, tabId, sendResponse) {
  try {
    const isOffline = checkCircuitBreaker();
    const userInfoPromise = fetchUserInfo(handle).catch(() => null);
    const ratingHistoryPromise = fetchRatingHistory(handle).catch(() => null);
    const problemsetPromise = fetchProblemset().catch(() => []);
    const contestsPromise = syncContests().catch(() => ({}));

    let submissions;
    let fallbackUsed = false;
    let cbActive = isOffline;

    try {
      submissions = await syncSubmissions(handle, 1);
    } catch (e) {
      const cacheKey = `cf_subs_${handle.toLowerCase()}`;
      const cached = await storageGet(cacheKey);
      if (cached) {
        submissions = cached.submissions;
        fallbackUsed = true;
        if (e.message === 'CIRCUIT_BREAKER_ACTIVE') cbActive = true;
      } else {
        throw new Error(e.message === 'CIRCUIT_BREAKER_ACTIVE'
          ? 'Codeforces servers are under heavy load and no cached data is available.'
          : e.message);
      }
    }

    const [userInfo, ratingHistory, problemset, contestMap] = await Promise.all([
      userInfoPromise,
      ratingHistoryPromise,
      problemsetPromise,
      contestsPromise
    ]);

    sendResponse({
      ok: true,
      submissions,
      userInfo,
      ratingHistory,
      problemset,
      contestMap,
      fallbackUsed,
      circuitBreaker: cbActive
    });

    // Launch Lazy Pass 2 Sync if healthy
    const cacheKey = `cf_subs_${handle.toLowerCase()}`;
    const cached = await storageGet(cacheKey);
    const now = Date.now();
    const isFresh = cached && (now - cached.lastUpdate) < CACHE_TTL;

    if (!isOffline && !fallbackUsed && !isFresh && tabId) {
      setTimeout(async () => {
        try {
          const fullSubs = await syncSubmissions(handle, 2);
          chrome.tabs.sendMessage(tabId, {
            type: 'CF_LAZY_SYNC_COMPLETE',
            handle,
            submissions: fullSubs
          });
        } catch (err) {
          console.warn('Lazy sync background tail failed:', err);
        }
      }, 1000);
    }

  } catch (err) {
    sendResponse({ ok: false, error: err.message });
  }
}

// ─── Live Contest Caching Sync ────────────────────────────────────────────────
const LIVE_CONTEST_TTL = 30 * 1000; // 30 seconds cache for active in-contest global status

async function fetchLiveContestStatus(contestId) {
  const cacheKey = `cf_live_status_${contestId}`;
  const cached   = await storageGet(cacheKey);
  const now      = Date.now();
  if (cached && (now - cached.lastUpdate) < LIVE_CONTEST_TTL) {
    return cached.submissions;
  }

  const url = `${CF_API}/contest.status?contestId=${encodeURIComponent(contestId)}&from=1&count=500`;
  try {
    const list = await enqueue(url);
    await storageSet(cacheKey, { submissions: list, lastUpdate: now });
    return list;
  } catch (e) {
    return cached ? cached.submissions : [];
  }
}

async function callOpenAI(openaiKey, systemPrompt, userPrompt) {
  const url = "https://api.openai.com/v1/chat/completions";
  let lastError = null;

  for (let attempt = 0; attempt <= 2; attempt++) {
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${openaiKey}`
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt }
          ]
        })
      });

      if (!response.ok) {
        const errText = await response.text();
        let errMsg = `OpenAI API returned status ${response.status}`;
        try {
          const errJson = JSON.parse(errText);
          if (errJson.error && errJson.error.message) errMsg = errJson.error.message;
        } catch (e) {}
        throw new Error(errMsg);
      }

      const data = await response.json();
      const text = data?.choices?.[0]?.message?.content || "";
      if (!text) throw new Error("Received empty response from OpenAI.");
      return text.trim();
    } catch (e) {
      lastError = e;
      console.warn(`OpenAI call attempt ${attempt + 1} failed:`, e);
      if (e.message.toLowerCase().includes('api key not valid') || e.message.toLowerCase().includes('key is invalid') || e.message.toLowerCase().includes('incorrect api key')) {
        throw e;
      }
      if (attempt < 2) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
  }

  throw lastError || new Error("OpenAI call failed after retries.");
}

async function callGemini(googleKey, systemPrompt, userPrompt) {
  const models = ['gemini-3.5-flash', 'gemini-2.5-flash', 'gemini-2.0-flash', 'gemini-3.5-pro', 'gemini-2.5-pro'];
  let lastError = null;

  for (const model of models) {
    for (let attempt = 0; attempt <= 2; attempt++) {
      try {
        const url = `https://generativelanguage.googleapis.com/v1/models/${model}:generateContent?key=${encodeURIComponent(googleKey)}`;
        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: `${systemPrompt}\n\nUser request:\n${userPrompt}`
                  }
                ]
              }
            ]
          })
        });

        if (response.ok) {
          const data = await response.json();
          const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || "";
          if (text) {
            return text.trim();
          }
          throw new Error("Received empty response from Gemini.");
        } else {
          const errText = await response.text();
          let errMsg = `Google API returned status ${response.status}`;
          try {
            const errJson = JSON.parse(errText);
            if (errJson.error && errJson.error.message) errMsg = errJson.error.message;
          } catch (e) {}

          // Abort immediately only if credentials are fundamentally invalid
          if (errMsg.toLowerCase().includes('api key not valid') || errMsg.toLowerCase().includes('key is invalid') || (response.status === 400 && errMsg.toLowerCase().includes('key'))) {
            throw new Error(errMsg);
          }

          throw new Error(errMsg);
        }
      } catch (e) {
        lastError = e;
        console.warn(`Gemini model ${model} attempt ${attempt + 1} failed:`, e);
        if (e.message.toLowerCase().includes('api key not valid') || e.message.toLowerCase().includes('key is invalid')) {
          throw e;
        }
        if (attempt < 2) {
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      }
    }
  }

  throw lastError || new Error("Failed all Gemini candidate models.");
}

// ─── Message Handler ─────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'CF_GET_AI_EDGE_CASES') {
    const { problemText } = message;

    chrome.storage.local.get({
      aiEnabled: false,
      openaiKey: '',
      googleKey: ''
    }, (items) => {
      if (!items.aiEnabled) {
        sendResponse({ ok: false, error: 'AI Assistant features are disabled. Please enable them in the extension settings.' });
        return;
      }

      const openaiKey = items.openaiKey || '';
      const googleKey = items.googleKey || '';

      if (!openaiKey && !googleKey) {
        sendResponse({ ok: false, error: 'No API keys set. Please configure OpenAI or Google Gemini API key in the extension popup.' });
        return;
      }

      const systemPrompt = "You are an expert Competitive Programming Coach. You help students find edge cases for problems. You MUST respond with a valid raw JSON array containing 3 to 4 edge case objects. Do not include any markdown wrappers (like ```json or ```), just the raw JSON text. You MUST format all mathematical expressions, constraints, variables (like $N$, $K$, $X$, $A_i$), and complexities (like $O(N)$) using standard inline LaTeX wrapped in single dollar signs (e.g., $N = 1$ or $A_i \\le 10^9$). Never write mathematical terms or variables as plain text.";
      const userPrompt = `Analyze this competitive programming problem and identify 3-4 critical edge cases or boundary conditions (e.g. minimum/maximum limits, negative bounds, duplicate values, large scales, prime values, overflow states, empty cases) where simple or standard solutions might fail.

Here is the problem statement:
<PROBLEM_STATEMENT>
${problemText}
</PROBLEM_STATEMENT>

You MUST respond strictly in the following JSON array format, and nothing else:
[
  {
    "scenario": "Short description of the case (e.g., Scenario 1: Minimum Constraints (N = 1, values are equal))",
    "explanation": "Brief explanation of why standard solutions might fail (e.g. integer overflow, array index out of bounds, slow sort).",
    "input": "The exact input string representing this case. Use '\\n' for newlines.",
    "output": "The expected output string representing this case."
  }
]`;

      const runFetch = async () => {
        try {
          let responseText = "";

          if (openaiKey && googleKey) {
            try {
              responseText = await callOpenAI(openaiKey, systemPrompt, userPrompt);
            } catch (err) {
              console.warn("OpenAI call failed, falling back to Gemini:", err);
              responseText = await callGemini(googleKey, systemPrompt, userPrompt);
            }
          } else if (openaiKey) {
            responseText = await callOpenAI(openaiKey, systemPrompt, userPrompt);
          } else if (googleKey) {
            responseText = await callGemini(googleKey, systemPrompt, userPrompt);
          } else {
            throw new Error("No API keys configured.");
          }

          sendResponse({ ok: true, data: responseText });
        } catch (err) {
          sendResponse({ ok: false, error: err.message });
        }
      };

      runFetch();
    });

    return true; // Keep message channel open for async response
  }

  if (message.type === 'CF_GET_AI_HINT') {
    const { step, problemText, previousHints } = message;

    chrome.storage.local.get({
      aiEnabled: false,
      openaiKey: '',
      googleKey: ''
    }, (items) => {
      if (!items.aiEnabled) {
        sendResponse({ ok: false, error: 'AI Assistant features are disabled. Please enable them in the extension settings.' });
        return;
      }

      const openaiKey = items.openaiKey || '';
      const googleKey = items.googleKey || '';

      if (!openaiKey && !googleKey) {
        sendResponse({ ok: false, error: 'No API keys set. Please configure OpenAI or Google Gemini API key in the extension popup.' });
        return;
      }

      let systemPrompt = "You are an expert Competitive Programming Coach. You guide students using the Socratic method without ever revealing the final solution or code. Keep your responses concise (2-4 sentences max). You MUST format all mathematical expressions, variables (like $N$, $K$, $X$, $A_i$), formulas, and time/space complexities (like $O(N \\log N)$ or $O(N)$) using standard inline LaTeX wrapped in single dollar signs (e.g., $O(N \\log N)$ or $X$). Never write variables, formulas, or complexities as plain text.";
      let userPrompt = "";

      if (step === 1) {
        userPrompt = `Here is the Codeforces problem statement:\n\n<PROBLEM_STATEMENT>\n${problemText}\n</PROBLEM_STATEMENT>\n\nThe student is stuck. This is Click 1 (The Observation Hint). Point out a core mathematical, logical, or structural property of the input or the constraints. Ask a guiding question at the end to get them thinking. DO NOT give the algorithm, solution, or any code.`;
      } else if (step === 2) {
        userPrompt = `Here is the Codeforces problem statement:\n\n<PROBLEM_STATEMENT>\n${problemText}\n</PROBLEM_STATEMENT>\n\nHere was Hint 1 (Observation):\n"${previousHints.hint1}"\n\nThe student is still stuck. This is Click 2 (The Reducibility/Paradigm Hint). Suggest a programming paradigm or reduction (e.g. greedy, dynamic programming, binary search on the answer, two pointers, graphs) that fits this problem. DO NOT give details of the transitions or transitions formulas, and DO NOT give code. Ask a guiding question to help them investigate this paradigm.`;
      } else if (step === 3) {
        userPrompt = `Here is the Codeforces problem statement:\n\n<PROBLEM_STATEMENT>\n${problemText}\n</PROBLEM_STATEMENT>\n\nHere was Hint 1 (Observation):\n"${previousHints.hint1}"\n\nHere was Hint 2 (Paradigm):\n"${previousHints.hint2}"\n\nThe student is still stuck. This is Click 3 (Complexity & Constraints Hint). Analyze the constraints and upper-bound limits, explaining how they constrain the needed time complexity (e.g. $O(N)$ or $O(N \\log N)$). Connect the constraints to the paradigm suggested in Hint 2. DO NOT write code or give the direct algorithm.`;
      } else {
        sendResponse({ ok: false, error: 'Invalid step requested.' });
        return;
      }

      const runFetch = async () => {
        try {
          let responseText = "";

          if (openaiKey && googleKey) {
            try {
              responseText = await callOpenAI(openaiKey, systemPrompt, userPrompt);
            } catch (err) {
              console.warn("OpenAI call failed, falling back to Gemini:", err);
              responseText = await callGemini(googleKey, systemPrompt, userPrompt);
            }
          } else if (openaiKey) {
            responseText = await callOpenAI(openaiKey, systemPrompt, userPrompt);
          } else if (googleKey) {
            responseText = await callGemini(googleKey, systemPrompt, userPrompt);
          } else {
            throw new Error("No API keys configured.");
          }

          sendResponse({ ok: true, hint: responseText });
        } catch (err) {
          sendResponse({ ok: false, error: err.message });
        }
      };

      runFetch();
    });

    return true; // Keep message channel open for async response
  }

  if (message.type === 'CF_TEST_OPENAI') {
    const { key } = message;
    fetch('https://api.openai.com/v1/models', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${key}`
      }
    })
    .then(async (res) => {
      if (res.ok) {
        sendResponse({ ok: true });
      } else {
        const text = await res.text();
        let errMsg = `HTTP ${res.status}`;
        try {
          const json = JSON.parse(text);
          if (json.error && json.error.message) errMsg = json.error.message;
        } catch(e) {}
        sendResponse({ ok: false, error: errMsg });
      }
    })
    .catch((err) => {
      sendResponse({ ok: false, error: err.message });
    });
    return true; // async response
  }

  if (message.type === 'CF_TEST_GOOGLE') {
    const { key } = message;
    fetch(`https://generativelanguage.googleapis.com/v1/models?key=${encodeURIComponent(key)}`, {
      method: 'GET'
    })
    .then(async (res) => {
      if (res.ok) {
        sendResponse({ ok: true });
      } else {
        const text = await res.text();
        let errMsg = `HTTP ${res.status}`;
        try {
          const json = JSON.parse(text);
          if (json.error && json.error.message) errMsg = json.error.message;
        } catch(e) {}
        sendResponse({ ok: false, error: errMsg });
      }
    })
    .catch((err) => {
      sendResponse({ ok: false, error: err.message });
    });
    return true; // async response
  }

  if (message.type === 'CF_FETCH_PROFILE') {
    const { handle } = message;
    const tabId = sender.tab?.id;
    handleProfileFetch(handle, tabId, sendResponse);
    return true; // keep channel open
  }

  if (message.type === 'CF_FETCH_LIVE_CONTEST') {
    const { contestId } = message;
    fetchLiveContestStatus(contestId).then(submissions => {
      sendResponse({ ok: true, submissions });
    }).catch(err => {
      sendResponse({ ok: false, error: err.message });
    });
    return true; // keep channel open
  }

  if (message.type === 'CF_CLEAR_CACHE') {
    const { handle } = message;
    const keys = [
      `cf_subs_${handle.toLowerCase()}`,
      `cf_info_${handle.toLowerCase()}`,
      `cf_rating_${handle.toLowerCase()}`
    ];
    chrome.storage.local.remove(keys, () => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === 'CF_CHECK_SUBMISSION') {
    const { handle, contestId, problemIndex } = message;
    const url = `${CF_API}/user.status?handle=${encodeURIComponent(handle)}&from=1&count=20`;
    enqueue(url).then(subs => {
      if (!subs || subs.length === 0) {
        sendResponse({ ok: true, solved: false });
        return;
      }
      
      const acSub = subs.find(s => 
        s.problem && 
        s.problem.contestId === parseInt(contestId, 10) && 
        s.problem.index.toUpperCase() === problemIndex.toUpperCase() && 
        s.verdict === 'OK'
      );
      
      if (acSub) {
        sendResponse({ ok: true, solved: true, solveTimeSeconds: acSub.creationTimeSeconds });
      } else {
        sendResponse({ ok: true, solved: false });
      }
    }).catch(err => {
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }

  if (message.type === 'CF_SYNC_STATE') {
    chrome.tabs.query({}, tabs => {
      for (const tab of tabs) {
        if (tab.id !== sender.tab?.id) {
          chrome.tabs.sendMessage(tab.id, message).catch(() => {});
        }
      }
    });
    sendResponse({ ok: true });
    return true;
  }

  if (message.type === 'CF_OPEN_CODE_TAB') {
    const { url, friend } = message;
    pendingRequests[url] = { parentTabId: sender.tab?.id, friend };
    chrome.tabs.create({ url, active: false });
    sendResponse({ ok: true });
    return true;
  }

  if (message.type === 'CF_SUBMISSION_CODE_LOADED') {
    const { url, rawCode, language, error } = message;
    const req = pendingRequests[url];
    if (req) {
      chrome.tabs.sendMessage(req.parentTabId, {
        type: 'CF_SUBMISSION_CODE_RESULT',
        rawCode,
        language,
        error,
        friend: req.friend
      }).catch(() => {});
      delete pendingRequests[url];
    }
    if (sender.tab?.id) {
      chrome.tabs.remove(sender.tab.id);
    }
    sendResponse({ ok: true });
    return true;
  }
});

// ─── Installation & Telemetry Handlers ─────────────────────────────────────
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install' || details.reason === 'update') {
    trackInstall(details.reason);
  }
  if (details.reason === 'install') {
    chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html') });
  }
});

// Daily Ping Heartbeat (using chrome.alarms)
chrome.alarms.create('daily_telemetry_ping', { periodInMinutes: 1440 });

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'daily_telemetry_ping') {
    trackPing();
  }
});

// Ping on Startup
chrome.runtime.onStartup.addListener(() => {
  setupUninstallURL();
  trackPing();
});


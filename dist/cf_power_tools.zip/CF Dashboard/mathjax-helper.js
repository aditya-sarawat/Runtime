// MathJax typesetting helper for Codeforces Dashboard
// This script runs in the page context to access window.MathJax and avoid CSP violations
document.addEventListener('CFD_TYPESET_MATH', (e) => {
  const id = e.detail?.id;
  if (!id) return;
  const el = document.getElementById(id);
  if (el && window.MathJax) {
    try {
      if (window.MathJax.Hub && window.MathJax.Hub.Queue) {
        window.MathJax.Hub.Queue(["Typeset", window.MathJax.Hub, el]);
      } else if (window.MathJax.typesetPromise) {
        window.MathJax.typesetPromise([el]);
      }
    } catch (err) {
      console.warn('[CF MathJax Helper] Typeset failed:', err);
    }
  }
});

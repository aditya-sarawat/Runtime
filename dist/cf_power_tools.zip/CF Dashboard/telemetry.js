/**
 * Extension Telemetry Tracker Module
 * Connects to https://runtimeextensionstracker.vercel.app with http://localhost:5001 fallback for local dev.
 */

const TELEMETRY_CONFIG = {
  baseUrl: 'https://runtimeextensionstracker.vercel.app/api/v1/telemetry',
  localUrl: 'http://localhost:5001/api/v1/telemetry',
  extensionId: 'cf-power-tools',
  apiKey: '',
};

// Utility to generate UUID v4 if crypto.randomUUID is not available
function generateUUID() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

// Helper to get or create persistent Installation ID
async function getInstallationId() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['telemetry_installation_id'], (result) => {
      if (result.telemetry_installation_id) {
        resolve(result.telemetry_installation_id);
      } else {
        const newId = generateUUID();
        chrome.storage.local.set({ telemetry_installation_id: newId }, () => {
          resolve(newId);
        });
      }
    });
  });
}

// Detect Browser & OS details
function getBrowserInfo() {
  const ua = navigator.userAgent;
  let browser = 'Chrome';
  if (ua.includes('Edg/')) browser = 'Edge';
  else if (ua.includes('Firefox/')) browser = 'Firefox';
  else if (ua.includes('Brave')) browser = 'Brave';

  let os = 'Unknown';
  if (ua.includes('Mac OS')) os = 'macOS';
  else if (ua.includes('Windows')) os = 'Windows';
  else if (ua.includes('Linux')) os = 'Linux';
  else if (ua.includes('Android')) os = 'Android';

  return { browser, os, locale: navigator.language || 'en-US' };
}

// Core HTTP request wrapper with fallback to local server
async function sendTelemetry(endpoint, payload) {
  const headers = {
    'Content-Type': 'application/json',
  };
  if (TELEMETRY_CONFIG.apiKey) {
    headers['X-Extension-Key'] = TELEMETRY_CONFIG.apiKey;
  }

  // Try production endpoint first; fallback to local development endpoint if production fails
  const urlsToTry = [
    `${TELEMETRY_CONFIG.baseUrl}${endpoint}`,
    `${TELEMETRY_CONFIG.localUrl}${endpoint}`
  ];

  for (const url of urlsToTry) {
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers,
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        const data = await response.json();
        console.log(`[Telemetry Success] Sent to ${url}:`, data);
        return data;
      } else {
        console.warn(`[Telemetry HTTP ${response.status}] ${url}`);
      }
    } catch (error) {
      console.warn(`[Telemetry Fetch Failed] ${url}:`, error.message);
    }
  }

  return null;
}

/**
 * 1. Track Install / Update
 */
export async function trackInstall(reason = 'install') {
  const installationId = await getInstallationId();
  const manifest = chrome.runtime.getManifest();
  const { browser, os, locale } = getBrowserInfo();

  const data = await sendTelemetry('/install', {
    installationId,
    extensionId: TELEMETRY_CONFIG.extensionId,
    version: manifest.version,
    browser,
    os,
    locale,
    metadata: { reason },
  });

  await setupUninstallURL();
  return data;
}

/**
 * Configure Chrome Uninstall URL
 */
export async function setupUninstallURL() {
  try {
    const installationId = await getInstallationId();
    const uninstallUrl = `${TELEMETRY_CONFIG.baseUrl}/uninstall?installationId=${installationId}&extensionId=${TELEMETRY_CONFIG.extensionId}`;
    if (chrome.runtime.setUninstallURL) {
      chrome.runtime.setUninstallURL(uninstallUrl, () => {
        if (chrome.runtime.lastError) {
          console.warn('[Telemetry] Error setting uninstall URL:', chrome.runtime.lastError.message);
        } else {
          console.log('[Telemetry] Uninstall URL configured:', uninstallUrl);
        }
      });
    }
  } catch (err) {
    console.warn('[Telemetry] Failed to set uninstall URL:', err);
  }
}

/**
 * 2. Track Daily Active User (Ping)
 */
export async function trackPing() {
  const installationId = await getInstallationId();
  const manifest = chrome.runtime.getManifest();

  return await sendTelemetry('/ping', {
    installationId,
    extensionId: TELEMETRY_CONFIG.extensionId,
    version: manifest.version,
  });
}

